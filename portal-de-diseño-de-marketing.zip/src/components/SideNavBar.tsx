import React from 'react';
import { ScreenType, TransitionType, UserRole, PortalSettings } from '../types';
import { CafiLogo } from './CafiLogo';

interface SideNavBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  currentUserRole?: UserRole;
  settings?: PortalSettings;
  onLogout?: () => void;
}

export const SideNavBar: React.FC<SideNavBarProps> = ({
  currentScreen,
  onNavigate,
  currentUserRole = 'admin',
  settings,
  onLogout
}) => {
  const isAdmin = currentUserRole === 'admin';
  const showKpis = isAdmin || (settings ? settings.permissions.showKpis : true);
  const showEquipo = isAdmin || (settings ? settings.permissions.showEquipo : true);
  const showDetalle = isAdmin || (settings ? settings.permissions.showDetalle : true);

  return (
    <nav className="bg-surface dark:bg-inverse-surface hidden md:flex flex-col sticky top-0 h-screen w-64 flex-shrink-0 border-r border-quiet dark:border-outline-variant flat no shadows">
      {/* Brand Header */}
      <div className="p-md pb-xs border-b border-quiet/60">
        <div className="py-2 px-1 cursor-pointer" onClick={() => onNavigate('asesor', 'push_back')}>
          <CafiLogo
            variant={settings?.logoVariant || 'full'}
            logoStyle={settings?.logoStyle || 'default'}
            logoPosition={settings?.logoPosition || 'left'}
            size="md"
            customLogoUrl={settings?.logoUrl}
          />
        </div>
        <div className="flex items-center justify-between px-1 mt-1">
          <p className="text-[11px] font-semibold text-primary/80 uppercase tracking-wider">
            Portal de Marketing
          </p>
          <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${isAdmin ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'}`}>
            {isAdmin ? 'Admin' : 'Usuario'}
          </span>
        </div>
      </div>

      {/* Primary Action Button */}
      <div className="p-md">
        <button
          onClick={() => onNavigate('formulario', 'slide_up')}
          className="w-full bg-secondary hover:bg-secondary-hover text-on-secondary text-title-sm font-bold py-2.5 px-md rounded-xl flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer shadow-sm hover:shadow"
        >
          <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
            add_circle
          </span>
          Nueva Solicitud
        </button>
      </div>

      {/* Nav Items */}
      <div className="flex-1 overflow-y-auto px-md space-y-base">
        {/* Tablero / Panel de Control */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('asesor', 'push_back');
          }}
          className={`flex items-center gap-sm px-md py-sm rounded-lg transition-colors duration-200 ${
            currentScreen === 'asesor'
              ? 'text-primary dark:text-primary-fixed-dim font-bold border-r-4 border-primary bg-surface-container'
              : 'text-on-surface-variant dark:text-outline-variant hover:text-primary dark:hover:text-primary-fixed-dim hover:bg-surface-container'
          }`}
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className="text-label-md font-label-md">Panel de Control</span>
        </a>

        {/* Panel de KPIs / Analíticas (Condicional) */}
        {showKpis && (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('kpis', 'push');
            }}
            className={`flex items-center gap-sm px-md py-sm rounded-lg transition-colors duration-200 ${
              currentScreen === 'kpis'
                ? 'text-primary dark:text-primary-fixed-dim font-bold border-r-4 border-primary bg-surface-container'
                : 'text-on-surface-variant dark:text-outline-variant hover:text-primary dark:hover:text-primary-fixed-dim hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined">analytics</span>
            <span className="text-label-md font-label-md">Panel de KPIs</span>
          </a>
        )}

        {/* Todas las Solicitudes (Condicional) */}
        {showDetalle && (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('detalle', 'push');
            }}
            className={`flex items-center gap-sm px-md py-sm rounded-lg transition-colors duration-200 ${
              currentScreen === 'detalle'
                ? 'text-primary dark:text-primary-fixed-dim font-bold border-r-4 border-primary bg-surface-container'
                : 'text-on-surface-variant dark:text-outline-variant hover:text-primary dark:hover:text-primary-fixed-dim hover:bg-surface-container'
            }`}
          >
            <span
              className="material-symbols-outlined"
              style={{ fontVariationSettings: currentScreen === 'detalle' ? "'FILL' 1" : undefined }}
            >
              list_alt
            </span>
            <span className="text-label-md font-label-md">Todas las Solicitudes</span>
          </a>
        )}

        {/* Gestión de Equipo (Condicional) */}
        {showEquipo && (
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('equipo', 'push');
            }}
            className={`flex items-center gap-sm px-md py-sm rounded-lg transition-colors duration-200 ${
              currentScreen === 'equipo'
                ? 'text-primary dark:text-primary-fixed-dim font-bold border-r-4 border-primary bg-surface-container'
                : 'text-on-surface-variant dark:text-outline-variant hover:text-primary dark:hover:text-primary-fixed-dim hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined">group</span>
            <span className="text-label-md font-label-md">Gestión de Equipo</span>
          </a>
        )}

        {/* Ajustes / Configuración */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('configuracion', 'push');
          }}
          className={`flex items-center gap-sm px-md py-sm rounded-lg transition-colors duration-200 ${
            currentScreen === 'configuracion'
              ? 'text-primary dark:text-primary-fixed-dim font-bold border-r-4 border-primary bg-surface-container'
              : 'text-on-surface-variant dark:text-outline-variant hover:text-primary dark:hover:text-primary-fixed-dim hover:bg-surface-container'
          }`}
        >
          <span className="material-symbols-outlined">settings</span>
          <span className="text-label-md font-label-md">Configuración</span>
        </a>
      </div>

      {/* Footer */}
      <div className="p-md border-t border-quiet dark:border-outline-variant space-y-xs">
        {onLogout && (
          <button
            type="button"
            onClick={onLogout}
            className="w-full flex items-center gap-sm px-md py-sm rounded-lg text-rose-600 hover:bg-rose-50 transition-colors duration-200 cursor-pointer text-left font-bold"
          >
            <span className="material-symbols-outlined text-[20px]">logout</span>
            <span className="text-label-md">Cerrar Sesión</span>
          </button>
        )}
      </div>
    </nav>
  );
};
