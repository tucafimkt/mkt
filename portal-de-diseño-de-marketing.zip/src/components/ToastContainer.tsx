import React from 'react';
import { AnimatePresence, motion } from 'motion/react';

export interface ToastMessage {
  id: string;
  type?: 'success' | 'info' | 'warning' | 'error';
  title?: string;
  message: string;
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed top-5 right-5 z-[100] flex flex-col gap-2.5 max-w-sm w-full pointer-events-none px-sm">
      <AnimatePresence>
        {toasts.map((toast) => {
          const isSuccess = toast.type === 'success' || !toast.type;
          const isError = toast.type === 'error';
          const isWarning = toast.type === 'warning';

          const bgClass = isSuccess
            ? 'bg-slate-900/95 border-emerald-500/40 text-white'
            : isError
            ? 'bg-slate-900/95 border-rose-500/40 text-white'
            : isWarning
            ? 'bg-slate-900/95 border-amber-500/40 text-white'
            : 'bg-slate-900/95 border-sky-500/40 text-white';

          const icon = isSuccess
            ? 'check_circle'
            : isError
            ? 'error'
            : isWarning
            ? 'warning'
            : 'info';

          const iconColor = isSuccess
            ? 'text-emerald-400'
            : isError
            ? 'text-rose-400'
            : isWarning
            ? 'text-amber-400'
            : 'text-sky-400';

          const badgeBg = isSuccess
            ? 'bg-emerald-500/20 text-emerald-300'
            : isError
            ? 'bg-rose-500/20 text-rose-300'
            : isWarning
            ? 'bg-amber-500/20 text-amber-300'
            : 'bg-sky-500/20 text-sky-300';

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -25, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -15, scale: 0.85, transition: { duration: 0.2 } }}
              transition={{ type: 'spring', stiffness: 450, damping: 28 }}
              className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-2xl border shadow-2xl backdrop-blur-md ${bgClass}`}
            >
              <div className={`p-1.5 rounded-xl flex items-center justify-center shrink-0 ${badgeBg}`}>
                <span className={`material-symbols-outlined text-[20px] ${iconColor}`}>
                  {icon}
                </span>
              </div>

              <div className="flex-1 min-w-0 pr-1 py-0.5">
                {toast.title && (
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-secondary mb-0.5">
                    {toast.title}
                  </h4>
                )}
                <p className="text-xs font-semibold leading-snug text-slate-100 break-words">
                  {toast.message}
                </p>
              </div>

              <button
                onClick={() => onDismiss(toast.id)}
                className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg shrink-0 cursor-pointer"
                title="Cerrar notificación"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
