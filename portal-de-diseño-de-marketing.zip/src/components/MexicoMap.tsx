import React, { useState } from 'react';

export interface StateData {
  state: string;
  region: string;
  count: number;
  inProcess: number;
  completed: number;
  pending: number;
  code: string;
  x: number; // Percentage X position on map canvas
  y: number; // Percentage Y position on map canvas
}

interface MexicoMapProps {
  stateData: StateData[];
  onSelectState?: (stateName: string) => void;
  selectedState?: string | null;
}

export const STATE_REGION_MAP: Record<string, string> = {
  // Región Chiapas
  'Chiapas': 'Región Chiapas',

  // Centro
  'Puebla': 'Centro',
  'Hidalgo': 'Centro',
  'Cuernavaca': 'Centro',
  'Toluca': 'Centro',
  'Ciudad de México': 'Centro',
  'Estado de México': 'Centro',

  // Golfo
  'Veracruz': 'Golfo',
  'Tampico': 'Golfo',
  'Oaxaca': 'Golfo',

  // Península
  'Yucatán': 'Península',
  'Cancún': 'Península',
  'Tabasco': 'Península',
  'Campeche': 'Península',
  'Quintana Roo': 'Península',

  // Bajío
  'Querétaro': 'Bajío',
  'Aguascalientes': 'Bajío',
  'San Luis Potosí': 'Bajío',
  'Guanajuato': 'Bajío',
  'Zacatecas': 'Bajío',
  'Guadalajara': 'Bajío',
  'Morelia': 'Bajío',
  'Jalisco': 'Bajío',
  'Michoacán': 'Bajío',

  // Norte
  'Monterrey': 'Norte',
  'Saltillo': 'Norte',
  'Durango': 'Norte',
  'Torreón': 'Norte',
  'Nuevo León': 'Norte',
  'Coahuila': 'Norte',

  // Noroeste
  'Baja California Sur': 'Noroeste',
  'Baja California Norte': 'Noroeste',
  'Baja California': 'Noroeste',
  'Sonora': 'Noroeste',
  'Chihuahua': 'Noroeste',
};

// Complete list of Mexican states & cities with coordinates for map pin placement
export const MEXICAN_STATES_COORDS: Record<string, { code: string; region: string; x: number; y: number }> = {
  // Región Chiapas
  'Chiapas': { code: 'CHIS', region: 'Región Chiapas', x: 77, y: 85 },

  // Centro
  'Puebla': { code: 'PUE', region: 'Centro', x: 63, y: 71 },
  'Hidalgo': { code: 'HGO', region: 'Centro', x: 59, y: 64 },
  'Cuernavaca': { code: 'MOR', region: 'Centro', x: 58, y: 73 },
  'Toluca': { code: 'TOL', region: 'Centro', x: 55, y: 68 },
  'Ciudad de México': { code: 'CDMX', region: 'Centro', x: 58, y: 70 },
  'Estado de México': { code: 'MEX', region: 'Centro', x: 55, y: 68 },

  // Golfo
  'Veracruz': { code: 'VER', region: 'Golfo', x: 68, y: 67 },
  'Tampico': { code: 'TAMP', region: 'Golfo', x: 62, y: 46 },
  'Oaxaca': { code: 'OAX', region: 'Golfo', x: 64, y: 81 },

  // Península
  'Yucatán': { code: 'YUC', region: 'Península', x: 88, y: 66 },
  'Cancún': { code: 'CUN', region: 'Península', x: 92, y: 72 },
  'Tabasco': { code: 'TAB', region: 'Península', x: 76, y: 78 },
  'Campeche': { code: 'CAMP', region: 'Península', x: 83, y: 75 },
  'Quintana Roo': { code: 'QROO', region: 'Península', x: 92, y: 72 },

  // Bajío
  'Querétaro': { code: 'QRO', region: 'Bajío', x: 56, y: 62 },
  'Aguascalientes': { code: 'AGS', region: 'Bajío', x: 48, y: 56 },
  'San Luis Potosí': { code: 'SLP', region: 'Bajío', x: 55, y: 52 },
  'Guanajuato': { code: 'GTO', region: 'Bajío', x: 52, y: 59 },
  'Zacatecas': { code: 'ZAC', region: 'Bajío', x: 49, y: 50 },
  'Guadalajara': { code: 'GDL', region: 'Bajío', x: 42, y: 62 },
  'Morelia': { code: 'MOR', region: 'Bajío', x: 48, y: 68 },
  'Jalisco': { code: 'JAL', region: 'Bajío', x: 42, y: 62 },
  'Michoacán': { code: 'MICH', region: 'Bajío', x: 48, y: 68 },

  // Norte
  'Monterrey': { code: 'MTY', region: 'Norte', x: 58, y: 38 },
  'Saltillo': { code: 'SLT', region: 'Norte', x: 50, y: 32 },
  'Durango': { code: 'DUR', region: 'Norte', x: 42, y: 44 },
  'Torreón': { code: 'TOR', region: 'Norte', x: 46, y: 35 },
  'Nuevo León': { code: 'NL', region: 'Norte', x: 58, y: 38 },
  'Coahuila': { code: 'COAH', region: 'Norte', x: 50, y: 32 },

  // Noroeste
  'Baja California Sur': { code: 'BCS', region: 'Noroeste', x: 20, y: 35 },
  'Baja California Norte': { code: 'BCN', region: 'Noroeste', x: 12, y: 18 },
  'Baja California': { code: 'BC', region: 'Noroeste', x: 12, y: 18 },
  'Sonora': { code: 'SON', region: 'Noroeste', x: 25, y: 22 },
  'Chihuahua': { code: 'CHIH', region: 'Noroeste', x: 38, y: 25 }
};

export const MexicoMap: React.FC<MexicoMapProps> = ({
  stateData,
  onSelectState,
  selectedState
}) => {
  const [hoveredState, setHoveredState] = useState<StateData | null>(null);

  // Calculate max count for density scaling
  const maxCount = Math.max(...stateData.map((s) => s.count), 1);

  // Map state name to stateData
  const stateMap = new Map<string, StateData>();
  stateData.forEach((s) => stateMap.set(s.state, s));

  return (
    <div className="relative w-full bg-slate-900 rounded-2xl p-md md:p-lg border border-slate-700 shadow-lg text-white overflow-hidden min-h-[380px] flex flex-col justify-between select-none">
      {/* Background Graphic Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none"></div>

      {/* Header */}
      <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-secondary text-[22px]">map</span>
            <h4 className="text-title-md font-bold text-white tracking-wide">
              Mapa de Solicitudes — República Mexicana
            </h4>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Concentración geográfica de proyectos por estado y densidad de actividad.
          </p>
        </div>

        {/* Heatmap Legend */}
        <div className="flex items-center gap-3 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700 text-[11px]">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Densidad:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600 inline-block"></span>
            <span className="text-slate-300">Baja</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
            <span className="text-slate-300">Media</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-secondary inline-block animate-pulse"></span>
            <span className="text-secondary font-bold">Alta / Mayor Demanda</span>
          </div>
        </div>
      </div>

      {/* Map Canvas SVG Area */}
      <div className="relative w-full h-[280px] sm:h-[340px] my-auto">
        {/* Stylized Mexico Silhouette SVG Path */}
        <svg
          viewBox="0 0 1000 600"
          className="w-full h-full object-contain opacity-25 filter drop-shadow-[0_0_12px_rgba(255,85,0,0.15)]"
          style={{ maxHeight: '340px' }}
        >
          {/* Main Mexico Geographic Polygon Path approximation */}
          <path
            d="M 120 100 L 170 140 L 220 180 L 250 200 L 300 130 L 370 140 L 480 180 L 580 200 L 610 260 L 630 330 L 600 370 L 530 370 L 480 400 L 430 360 L 390 320 L 340 250 L 200 200 Z"
            fill="#1e293b"
            stroke="#ff5500"
            strokeWidth="2"
            strokeDasharray="4 4"
          />
          {/* Baja California peninsula path */}
          <path
            d="M 100 80 L 130 160 L 180 240 L 210 270 L 190 280 L 140 200 L 110 120 Z"
            fill="#1e293b"
            stroke="#3b82f6"
            strokeWidth="1.5"
            strokeDasharray="2 2"
          />
          {/* Yucatan peninsula path */}
          <path
            d="M 720 400 L 800 380 L 900 380 L 920 440 L 850 480 L 760 460 Z"
            fill="#1e293b"
            stroke="#ff5500"
            strokeWidth="1.5"
          />
          {/* Connecting mainland contours */}
          <path
            d="M 400 320 Q 520 380 620 400 Q 720 420 780 480 L 740 520 L 620 480 L 520 450 L 430 390 Z"
            fill="#0f172a"
            stroke="#475569"
            strokeWidth="1"
          />
        </svg>

        {/* State Map Pins Overlay */}
        {Object.entries(MEXICAN_STATES_COORDS).map(([stName, meta]) => {
          const stData = stateMap.get(stName);
          const count = stData ? stData.count : 0;
          const isSelected = selectedState === stName;
          const isHighDensity = count > 0 && count === maxCount;

          // Determine pin size and color based on request count
          let pinBg = 'bg-slate-700/60 border-slate-600 text-slate-400';
          let glowClass = '';
          let pinSize = 'w-5 h-5 text-[10px]';

          if (count >= 3) {
            pinBg = 'bg-secondary text-white font-black border-2 border-white shadow-md scale-125 z-20';
            glowClass = 'ring-4 ring-orange-500/40 animate-pulse';
            pinSize = 'w-7 h-7 text-xs';
          } else if (count === 2) {
            pinBg = 'bg-blue-600 text-white font-bold border border-blue-200 z-10';
            pinSize = 'w-6 h-6 text-[11px]';
          } else if (count === 1) {
            pinBg = 'bg-emerald-600 text-white font-bold border border-emerald-300 z-10';
            pinSize = 'w-5 h-5 text-[10px]';
          }

          if (isSelected) {
            pinBg = 'bg-white text-slate-900 border-2 border-secondary font-black z-30 ring-4 ring-white/50 scale-125';
          }

          return (
            <div
              key={stName}
              style={{ left: `${meta.x}%`, top: `${meta.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-300 cursor-pointer group"
              onClick={() => onSelectState && onSelectState(stName)}
              onMouseEnter={() =>
                setHoveredState(
                  stData || {
                    state: stName,
                    region: meta.region,
                    count: 0,
                    inProcess: 0,
                    completed: 0,
                    pending: 0,
                    code: meta.code,
                    x: meta.x,
                    y: meta.y
                  }
                )
              }
              onMouseLeave={() => setHoveredState(null)}
            >
              {/* Pin Circle with Badge Count */}
              <div
                className={`rounded-full flex items-center justify-center cursor-pointer transition-transform duration-200 hover:scale-125 ${pinBg} ${glowClass}`}
              >
                {count > 0 ? count : ''}
              </div>

              {/* State Label Abbreviation */}
              <span className={`block text-[9px] font-mono uppercase text-center mt-0.5 tracking-tighter ${
                count > 0 ? 'text-white font-bold' : 'text-slate-500 font-medium'
              }`}>
                {meta.code}
              </span>

              {/* Hover Tooltip Card */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:flex flex-col bg-slate-900 border border-slate-700 text-white p-2.5 rounded-xl shadow-xl w-44 z-50 text-xs pointer-events-none animate-fadeIn">
                <div className="flex justify-between items-center border-b border-slate-800 pb-1 mb-1">
                  <span className="font-bold text-secondary">{stName}</span>
                  <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-mono">
                    {meta.region}
                  </span>
                </div>
                {count > 0 ? (
                  <div className="space-y-0.5 text-[11px]">
                    <div className="flex justify-between text-slate-200 font-bold">
                      <span>Total Solicitudes:</span>
                      <span className="text-white">{count}</span>
                    </div>
                    <div className="flex justify-between text-blue-400">
                      <span>En Proceso:</span>
                      <span>{stData?.inProcess || 0}</span>
                    </div>
                    <div className="flex justify-between text-emerald-400">
                      <span>Completadas:</span>
                      <span>{stData?.completed || 0}</span>
                    </div>
                    <div className="flex justify-between text-amber-400">
                      <span>Pendientes:</span>
                      <span>{stData?.pending || 0}</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-[10px] text-slate-400 italic">Sin solicitudes registradas aún en este estado.</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected / Hovered State Status Detail Banner */}
      <div className="relative z-10 bg-slate-800/90 border border-slate-700/80 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        {hoveredState || selectedState ? (
          (() => {
            const current = hoveredState || stateMap.get(selectedState || '') || {
              state: selectedState || '',
              region: MEXICAN_STATES_COORDS[selectedState || '']?.region || 'México',
              count: 0,
              inProcess: 0,
              completed: 0,
              pending: 0,
              code: MEXICAN_STATES_COORDS[selectedState || '']?.code || 'MX',
              x: 0,
              y: 0
            };
            return (
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-secondary text-white font-bold flex items-center justify-center text-xs">
                    {current.code || 'MX'}
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-sm flex items-center gap-2">
                      {current.state}
                      <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-mono">
                        Región {current.region}
                      </span>
                    </h5>
                    <p className="text-slate-400 text-[11px]">
                      {current.count > 0
                        ? `${current.count} solicitud(es) registrada(s) en este estado.`
                        : 'Estado en monitoreo activo sin pedidos en este periodo.'}
                    </p>
                  </div>
                </div>

                {current.count > 0 && (
                  <div className="flex items-center gap-3 font-mono font-bold text-xs">
                    <span className="text-amber-400 bg-amber-950/60 px-2 py-1 rounded border border-amber-800/50">
                      ⏳ {current.pending} Pend.
                    </span>
                    <span className="text-blue-400 bg-blue-950/60 px-2 py-1 rounded border border-blue-800/50">
                      🎨 {current.inProcess} Proc.
                    </span>
                    <span className="text-emerald-400 bg-emerald-950/60 px-2 py-1 rounded border border-emerald-800/50">
                      ✅ {current.completed} Comp.
                    </span>
                  </div>
                )}
              </div>
            );
          })()
        ) : (
          <div className="flex items-center justify-between w-full text-slate-300">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary text-[20px]">touch_app</span>
              <span>Pasa el cursor o haz clic en cualquier estado de la República para ver el desglose detallado de solicitudes.</span>
            </div>
            <span className="text-[11px] text-slate-400 font-bold hidden md:inline">32 Estados Cobertura Nacional</span>
          </div>
        )}
      </div>
    </div>
  );
};
