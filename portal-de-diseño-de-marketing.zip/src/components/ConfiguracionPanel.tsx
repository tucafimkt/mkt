import React, { useState, useEffect } from 'react';
import { ScreenType, TransitionType, PortalSettings, UserRole, UserProfile } from '../types';
import { CafiLogo } from './CafiLogo';

interface ConfiguracionPanelProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  currentUserRole: UserRole;
  currentUser?: UserProfile | null;
  onUpdateUserProfile?: (updated: Partial<UserProfile>) => void;
  onToggleUserRole?: (role: UserRole) => void;
  settings: PortalSettings;
  onUpdateSettings: (newSettings: PortalSettings) => void;
}

export const ConfiguracionPanel: React.FC<ConfiguracionPanelProps> = ({
  onNavigate,
  currentUserRole,
  currentUser,
  onUpdateUserProfile,
  onToggleUserRole,
  settings,
  onUpdateSettings
}) => {
  const isAdmin = currentUserRole === 'admin';

  // Profile local state
  const [profileName, setProfileName] = useState(currentUser?.name || '');
  const [profileAvatar, setProfileAvatar] = useState(currentUser?.avatarUrl || '');
  const [profilePhone, setProfilePhone] = useState(currentUser?.phone || '');
  const [profileRegion, setProfileRegion] = useState(currentUser?.region || 'Bajío');
  const [showProfileSuccess, setShowProfileSuccess] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setProfileName(currentUser.name || '');
      setProfileAvatar(currentUser.avatarUrl || '');
      setProfilePhone(currentUser.phone || '');
      setProfileRegion(currentUser.region || 'Bajío');
    }
  }, [currentUser]);

  // Settings local state
  const [localSettings, setLocalSettings] = useState<PortalSettings>(settings);
  const [customUrlInput, setCustomUrlInput] = useState(settings.logoUrl || '');
  const [showSavedToast, setShowSavedToast] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  // Profile image file upload
  const handleProfileImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Por favor selecciona un archivo de imagen válido (PNG, JPG, WebP).');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setProfileAvatar(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) return;

    if (onUpdateUserProfile) {
      onUpdateUserProfile({
        name: profileName.trim(),
        avatarUrl: profileAvatar.trim() || undefined,
        phone: profilePhone.trim() || undefined,
        region: profileRegion
      });
      setShowProfileSuccess(true);
      setTimeout(() => setShowProfileSuccess(false), 3000);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAdmin) return;
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Por favor selecciona un archivo de imagen (PNG, JPG, SVG, WebP, etc.)');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          const updated = {
            ...localSettings,
            logoUrl: result
          };
          setLocalSettings(updated);
          setCustomUrlInput(`[Archivo Local] ${file.name}`);
          setUploadedFileName(file.name);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTogglePermission = (key: keyof PortalSettings['permissions']) => {
    if (!isAdmin) return;
    const updated = {
      ...localSettings,
      permissions: {
        ...localSettings.permissions,
        [key]: !localSettings.permissions[key]
      }
    };
    setLocalSettings(updated);
  };

  const handleApplyLogoUrl = (url: string | null) => {
    if (!isAdmin) return;
    const updated = {
      ...localSettings,
      logoUrl: url
    };
    setLocalSettings(updated);
    setCustomUrlInput(url || '');
  };

  const handleSaveAll = () => {
    onUpdateSettings(localSettings);
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 3000);
  };

  const handleResetLogo = () => {
    const updated: PortalSettings = {
      ...localSettings,
      logoUrl: null,
      logoVariant: 'full',
      logoPosition: 'left',
      logoStyle: 'default'
    };
    setLocalSettings(updated);
    setCustomUrlInput('');
    setUploadedFileName(null);
  };

  return (
    <main className="flex-1 overflow-y-auto p-md md:p-lg lg:px-xl bg-surface-subtle">
      <div className="max-w-container-max mx-auto space-y-lg pb-24">
        {/* Save Toast Notification */}
        {showSavedToast && (
          <div className="fixed top-20 right-6 z-50 bg-emerald-700 text-white font-bold px-md py-sm rounded-xl shadow-xl flex items-center gap-2 animate-bounce">
            <span className="material-symbols-outlined">check_circle</span>
            ¡Configuración guardada correctamente!
          </div>
        )}

        {/* Page Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-md bg-surface-container-lowest p-md md:p-lg rounded-2xl border border-quiet shadow-xs">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-7 rounded-full bg-secondary inline-block"></span>
              <h2 className="text-headline-md font-bold text-primary">
                Configuración y Mi Perfil
              </h2>
            </div>
            <p className="text-body-md text-on-surface-variant mt-1">
              Personaliza tu información personal, foto de perfil y gestiona los ajustes del portal CAFI.
            </p>
          </div>

          {/* Role Indicator / Simulator (ONLY FOR ADMIN USERS) */}
          {isAdmin && onToggleUserRole && (
            <div className="bg-surface-subtle border border-quiet p-1.5 rounded-xl flex items-center gap-1 w-full md:w-auto">
              <span className="text-xs font-semibold text-on-surface-variant px-2 hidden sm:inline">
                Simular Vista:
              </span>
              <button
                onClick={() => onToggleUserRole('admin')}
                className="px-md py-1.5 rounded-lg text-xs font-bold bg-primary text-on-primary shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1"
              >
                <span className="material-symbols-outlined text-[16px]">admin_panel_settings</span>
                Administrador
              </button>
              <button
                onClick={() => onToggleUserRole('usuario')}
                className="px-md py-1.5 rounded-lg text-xs font-bold text-on-surface-variant hover:text-on-surface transition-all cursor-pointer flex items-center justify-center gap-1"
              >
                <span className="material-symbols-outlined text-[16px]">person</span>
                Ver como Asesor
              </button>
            </div>
          )}
        </div>

        {/* SECTION 0: MI PERFIL DE USUARIO (EDITABLE BY ALL, INCLUDING ASESOR) */}
        <section className="bg-surface-container-lowest border-2 border-secondary/30 rounded-2xl shadow-xs p-md md:p-lg space-y-md">
          <div className="border-b border-quiet pb-sm flex justify-between items-center">
            <div>
              <h3 className="text-title-md font-bold text-primary flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary">account_circle</span>
                Mi Perfil Personal
              </h3>
              <p className="text-label-md text-on-surface-variant">
                Actualiza tu nombre visible y tu foto de perfil de asesor en la plataforma.
              </p>
            </div>
            {showProfileSuccess && (
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1 animate-fadeIn">
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                Perfil guardado
              </span>
            )}
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-md">
            <div className="flex flex-col sm:flex-row items-center gap-md">
              {/* Profile Avatar Display */}
              <div className="relative group shrink-0">
                <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-secondary/30 bg-surface-subtle shadow-inner flex items-center justify-center font-bold text-2xl text-secondary">
                  {profileAvatar ? (
                    <img src={profileAvatar} alt={profileName} className="w-full h-full object-cover" />
                  ) : (
                    <span>
                      {profileName
                        ? profileName.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()
                        : 'AS'}
                    </span>
                  )}
                </div>
                <label className="absolute bottom-0 right-0 bg-secondary hover:bg-secondary-hover text-on-secondary p-2 rounded-full cursor-pointer shadow-md transition-transform group-hover:scale-105">
                  <span className="material-symbols-outlined text-[18px]">photo_camera</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="flex-1 space-y-sm w-full">
                <div>
                  <label className="block text-xs font-bold text-on-surface uppercase tracking-wider mb-1">
                    Tu Nombre Completo
                  </label>
                  <input
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="Ej: Alexander Wright"
                    required
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md font-bold text-on-surface focus:outline-none focus:border-primary"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-sm">
                  <div>
                    <label className="block text-xs font-bold text-on-surface uppercase tracking-wider mb-1">
                      O pegar Enlace / URL de Foto
                    </label>
                    <input
                      type="text"
                      value={profileAvatar}
                      onChange={(e) => setProfileAvatar(e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2 text-body-md text-on-surface focus:outline-none focus:border-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-on-surface uppercase tracking-wider mb-1">
                      Teléfono de Contacto
                    </label>
                    <input
                      type="text"
                      value={profilePhone}
                      onChange={(e) => setProfilePhone(e.target.value)}
                      placeholder="+52 (55) 1234-5678"
                      className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2 text-body-md text-on-surface focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Read-Only Role & Info Badge */}
            <div className="p-sm bg-surface-subtle rounded-xl border border-quiet flex flex-col sm:flex-row items-start sm:items-center justify-between gap-sm text-xs">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary">badge</span>
                <span className="text-on-surface-variant">Rol Asignado en el Sistema:</span>
                <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                  isAdmin ? 'bg-primary/10 text-primary border border-primary/20' : 'bg-secondary/10 text-secondary border border-secondary/20'
                }`}>
                  {isAdmin ? 'Ejecutivo de Marketing / Admin' : 'Asesor de Ventas'}
                </span>
              </div>
              <p className="text-[11px] text-on-surface-variant italic">
                * Los roles son otorgados únicamente por la dirección de administración.
              </p>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="bg-secondary hover:bg-secondary-hover text-on-secondary font-bold px-lg py-2.5 rounded-xl shadow-xs transition-colors flex items-center gap-2 text-xs cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">save</span>
                Guardar Cambios de Mi Perfil
              </button>
            </div>
          </form>
        </section>

        {/* NON-ADMIN RESTRICTION NOTICE */}
        {!isAdmin && (
          <div className="bg-slate-100 border-2 border-slate-300 rounded-2xl p-md flex items-start gap-md text-slate-800">
            <span className="material-symbols-outlined text-slate-600 text-[28px] shrink-0">lock</span>
            <div>
              <h4 className="font-bold text-title-sm text-slate-900">Ajustes Institucionales Restringidos</h4>
              <p className="text-body-sm text-slate-700 mt-0.5">
                La modificación del <strong>logotipo institucional, eslogan y permisos de módulos</strong> están reservados exclusivamente para los usuarios Administradores.
              </p>
            </div>
          </div>
        )}

        {/* ADMIN SECTIONS: LOGO & PERMISSIONS */}
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-lg ${!isAdmin ? 'opacity-60 pointer-events-none select-none' : ''}`}>
          {/* Section 1: Logo & Branding */}
          <section className="bg-surface-container-lowest rounded-2xl border border-quiet shadow-xs p-lg space-y-md">
            <div className="border-b border-quiet pb-sm flex justify-between items-center">
              <div>
                <h3 className="text-title-md font-bold text-primary flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">palette</span>
                  Definición de Logotipo Oficial y Estilos Predefinidos CAFI
                </h3>
                <p className="text-label-md text-on-surface-variant">
                  Configura los estilos de color del logo institucional o sube una imagen personalizada.
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-primary/10 text-primary uppercase tracking-wider">
                Solo Admin
              </span>
            </div>

            {/* Live Preview */}
            <div className="space-y-xs">
              <label className="block text-label-md font-bold text-on-surface">
                Vista Previa del Logotipo Seleccionado
              </label>
              <div
                className={`p-lg border border-dashed rounded-2xl flex items-center min-h-[110px] transition-all justify-start ${
                  localSettings.logoStyle === 'monochrome_white'
                    ? 'bg-slate-900 border-slate-700'
                    : 'bg-surface-subtle border-quiet'
                }`}
              >
                <CafiLogo
                  variant="full"
                  logoStyle={localSettings.logoStyle || 'default'}
                  size="lg"
                  customLogoUrl={localSettings.logoUrl}
                />
              </div>
            </div>

            {/* ESTILOS DE COLOR PREDEFINIDOS */}
            <div className="space-y-xs pt-xs">
              <label className="block text-label-md font-bold text-on-surface">
                Estilos de Color Predefinidos
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, logoStyle: 'default' })}
                  disabled={!isAdmin}
                  className={`p-sm border rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    (localSettings.logoStyle || 'default') === 'default'
                      ? 'border-primary bg-primary/5 ring-2 ring-primary/20 font-bold text-primary shadow-xs'
                      : 'border-quiet hover:bg-surface-subtle text-on-surface-variant'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#000B76] to-[#FF5000] shadow-xs"></div>
                  <span className="text-xs font-bold">Oficial Corporativo</span>
                  <span className="text-[10px] text-on-surface-variant">Azul Marino y Naranja</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, logoStyle: 'monochrome_dark' })}
                  disabled={!isAdmin}
                  className={`p-sm border rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    localSettings.logoStyle === 'monochrome_dark'
                      ? 'border-primary bg-primary/5 ring-2 ring-primary/20 font-bold text-primary shadow-xs'
                      : 'border-quiet hover:bg-surface-subtle text-on-surface-variant'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-slate-900 shadow-xs"></div>
                  <span className="text-xs font-bold">Monocromático Oscuro</span>
                  <span className="text-[10px] text-on-surface-variant">Negro Grafito Elegante</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, logoStyle: 'monochrome_white' })}
                  disabled={!isAdmin}
                  className={`p-sm border rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    localSettings.logoStyle === 'monochrome_white'
                      ? 'border-primary bg-primary/5 ring-2 ring-primary/20 font-bold text-primary shadow-xs'
                      : 'border-quiet hover:bg-surface-subtle text-on-surface-variant'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-white border border-slate-300 shadow-xs"></div>
                  <span className="text-xs font-bold">Monocromático Blanco</span>
                  <span className="text-[10px] text-on-surface-variant">Para Fondos Oscuros</span>
                </button>
              </div>
            </div>

            {/* Opcional: Cargar Imagen de Archivo */}
            <div className="space-y-xs pt-xs border-t border-quiet">
              <label className="block text-label-md font-bold text-on-surface">
                Opción de Carga de Archivo Externo
              </label>
              <label
                className={`border-2 border-dashed rounded-2xl p-sm flex flex-col items-center justify-center text-center transition-all ${
                  isAdmin
                    ? 'border-secondary/40 hover:border-secondary bg-secondary/5 hover:bg-secondary/10 cursor-pointer'
                    : 'border-quiet bg-surface-subtle opacity-60 cursor-not-allowed'
                }`}
              >
                <div className="w-8 h-8 rounded-full bg-secondary/10 text-secondary flex items-center justify-center mb-1">
                  <span className="material-symbols-outlined text-[20px]">cloud_upload</span>
                </div>
                <p className="text-xs font-bold text-primary">
                  {uploadedFileName
                    ? `Logotipo cargado: ${uploadedFileName}`
                    : 'Subir archivo de imagen (PNG, SVG, JPG, WebP)'}
                </p>
                <input
                  type="file"
                  accept="image/*"
                  disabled={!isAdmin}
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Restablecer Valores Oficiales */}
            <div className="pt-1 flex justify-between items-center">
              <button
                type="button"
                onClick={handleResetLogo}
                disabled={!isAdmin}
                className="text-xs font-bold text-secondary hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[14px]">restart_alt</span>
                Restablecer a Valores Oficiales CAFI
              </button>
            </div>
          </section>

          {/* Section 2: Permissions & Module Visibility */}
          <section className="bg-surface-container-lowest rounded-2xl border border-quiet shadow-xs p-lg space-y-md">
            <div className="border-b border-quiet pb-sm flex justify-between items-center">
              <div>
                <h3 className="text-title-md font-bold text-primary flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">visibility_off</span>
                  Permisos y Ocultación de Módulos
                </h3>
                <p className="text-label-md text-on-surface-variant">
                  Controla cuáles secciones del menú están disponibles para usuarios estándar.
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-primary/10 text-primary uppercase tracking-wider">
                Solo Admin
              </span>
            </div>

            {/* Permissions list */}
            <div className="space-y-md">
              {/* Module 1: Panel de KPIs */}
              <div className="p-md bg-surface-subtle border border-quiet rounded-xl flex items-center justify-between gap-md">
                <div className="flex items-center gap-md">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[22px]">analytics</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-body-md text-on-surface">Panel de KPIs</h4>
                      {localSettings.permissions.showKpis ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          Visible
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          Oculto
                        </span>
                      )}
                    </div>
                    <p className="text-label-md text-on-surface-variant">
                      Indicadores clave de rendimiento, métricas y gráficas.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleTogglePermission('showKpis')}
                  disabled={!isAdmin}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 cursor-pointer shrink-0 relative ${
                    localSettings.permissions.showKpis ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                      localSettings.permissions.showKpis ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Module 2: Gestión de Equipo */}
              <div className="p-md bg-surface-subtle border border-quiet rounded-xl flex items-center justify-between gap-md">
                <div className="flex items-center gap-md">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[22px]">group</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-body-md text-on-surface">Gestión de Equipo</h4>
                      {localSettings.permissions.showEquipo ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          Visible
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          Oculto
                        </span>
                      )}
                    </div>
                    <p className="text-label-md text-on-surface-variant">
                      Administración de asesores, diseñadores y directores.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleTogglePermission('showEquipo')}
                  disabled={!isAdmin}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 cursor-pointer shrink-0 relative ${
                    localSettings.permissions.showEquipo ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                      localSettings.permissions.showEquipo ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Module 3: Todas las Solicitudes */}
              <div className="p-md bg-surface-subtle border border-quiet rounded-xl flex items-center justify-between gap-md">
                <div className="flex items-center gap-md">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-[22px]">list_alt</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-body-md text-on-surface">Todas las Solicitudes</h4>
                      {localSettings.permissions.showDetalle ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          Visible
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          Oculto
                        </span>
                      )}
                    </div>
                    <p className="text-label-md text-on-surface-variant">
                      Acceso al listado global detallado de solicitudes.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleTogglePermission('showDetalle')}
                  disabled={!isAdmin}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 cursor-pointer shrink-0 relative ${
                    localSettings.permissions.showDetalle ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                      localSettings.permissions.showDetalle ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Sticky Save Bar for Administrator */}
        {isAdmin && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-primary text-on-primary shadow-2xl px-lg py-md rounded-2xl flex items-center gap-md border border-white/20 animate-slideUp">
            <div>
              <p className="font-bold text-body-md leading-tight">Guardar Cambios de Configuración</p>
              <p className="text-xs text-white/80">Aplica el nuevo logotipo y permisos del sistema.</p>
            </div>

            <button
              type="button"
              onClick={handleSaveAll}
              className="bg-secondary hover:bg-secondary-hover text-on-secondary font-bold py-2.5 px-lg rounded-xl transition-all cursor-pointer shadow-md flex items-center gap-1.5 text-sm"
            >
              <span className="material-symbols-outlined text-[18px]">save</span>
              Guardar Cambios
            </button>
          </div>
        )}
      </div>
    </main>
  );
};
