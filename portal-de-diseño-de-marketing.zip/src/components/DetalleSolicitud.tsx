import React, { useState, useMemo } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { AttachmentItem, RequestItem, ScreenType, TransitionType, UserRole } from '../types';

interface DetalleSolicitudProps {
  request: RequestItem;
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onAddComment?: (requestId: string, text: string) => void;
  currentUserRole?: UserRole;
  onUpdateStatus?: (
    requestId: string,
    newStatus: RequestItem['status'],
    note?: string,
    newAttachments?: AttachmentItem[]
  ) => void;
}

export const DetalleSolicitud: React.FC<DetalleSolicitudProps> = ({
  request,
  onNavigate,
  onAddComment,
  currentUserRole = 'admin',
  onUpdateStatus
}) => {
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState(request.comments || []);
  const [selectedStatus, setSelectedStatus] = useState<RequestItem['status']>(request.status);
  const [statusNote, setStatusNote] = useState('');
  const [showStatusSuccess, setShowStatusSuccess] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<AttachmentItem[]>([]);
  const [statusError, setStatusError] = useState<string | null>(null);

  const getFileTypeFromExtension = (filename: string): string => {
    const ext = filename.split('.').pop()?.toLowerCase() || '';
    if (['jpg', 'jpeg', 'png', 'gif'].includes(ext)) return 'imagen';
    if (['pdf'].includes(ext)) return 'pdf';
    if (['csv', 'xlsx', 'xls'].includes(ext)) return 'excel';
    if (['pptx', 'ptx', 'ppt'].includes(ext)) return 'powerpoint';
    if (['doc', 'docx'].includes(ext)) return 'doc';
    if (['mp3', 'wav', 'aac', 'ogg'].includes(ext)) return 'audio';
    if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(ext)) return 'video';
    return 'documento';
  };

  const getFileIcon = (typeOrExt: string) => {
    const lower = typeOrExt.toLowerCase();
    if (['imagen', 'jpg', 'jpeg', 'png', 'gif'].includes(lower)) return 'image';
    if (['pdf'].includes(lower)) return 'picture_as_pdf';
    if (['excel', 'csv', 'xlsx', 'xls'].includes(lower)) return 'table_view';
    if (['powerpoint', 'pptx', 'ptx', 'ppt'].includes(lower)) return 'slideshow';
    if (['doc', 'docx'].includes(lower)) return 'article';
    if (['audio', 'mp3', 'wav'].includes(lower)) return 'audiotrack';
    if (['video', 'mp4', 'mov', 'avi'].includes(lower)) return 'movie';
    return 'description';
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const filesArray: File[] = Array.from(e.target.files);
    const newItems: AttachmentItem[] = filesArray.map((file: File) => {
      const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
      const sizeStr = file.size > 1024 * 1024 ? `${sizeMb} MB` : `${Math.round(file.size / 1024)} KB`;
      return {
        name: file.name,
        type: getFileTypeFromExtension(file.name),
        url: URL.createObjectURL(file),
        size: sizeStr
      };
    });
    setPendingFiles((prev) => [...prev, ...newItems]);
    setStatusError(null);
    // Requirement 2: Upon attaching final file, automatically mark stage '3. Material Entregado'
    setSelectedStatus('Completado');
  };

  const handleRemovePendingFile = (index: number) => {
    setPendingFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const displayAttachments = useMemo(() => {
    const currentAtts = request.attachments || [];
    const hasBrief = currentAtts.some((a) => a.name.toLowerCase().includes('brief'));
    if (!hasBrief) {
      return [
        { name: 'Brief_Inicial_CAFI.pdf', type: 'pdf', size: 'PDF Oficial' },
        ...currentAtts
      ];
    }
    return currentAtts;
  }, [request.attachments]);

  const handleDownloadBrief = async () => {
    const dateStr = new Date().toLocaleDateString('es-MX', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    const timeStr = new Date().toLocaleTimeString('es-MX', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const commentsHtml =
      request.comments && request.comments.length > 0
        ? request.comments
            .map(
              (c) => `
          <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px 16px; margin-bottom:10px;">
            <div style="display:flex; justify-content:space-between; font-size:12px; font-weight:800; color:#000B76; margin-bottom:4px;">
              <span>${c.author}</span>
              <span style="color:#64748b; font-weight:normal;">${c.time}</span>
            </div>
            <div style="font-size:12px; color:#334155; line-height:1.5;">${c.text}</div>
          </div>
        `
            )
            .join('')
        : '<p style="font-size:13px; color:#94a3b8; font-style:italic;">No se han registrado comentarios adicionales.</p>';

    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.left = '-9999px';
    container.style.top = '-9999px';
    container.style.width = '750px';
    container.style.backgroundColor = '#ffffff';
    container.style.padding = '36px';
    container.style.fontFamily = "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif";
    container.style.color = '#0f172a';
    container.style.boxSizing = 'border-box';

    container.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid #000B76; padding-bottom:18px; margin-bottom:20px;">
        <div style="display:flex; align-items:center; gap:12px;">
          <svg width="44" height="44" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g transform="translate(50 50)">
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(0)" fill="#000B76"/>
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(60)" fill="#FF5500"/>
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(120)" fill="#000B76"/>
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(180)" fill="#FF5500"/>
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(240)" fill="#000B76"/>
              <rect x="-16" y="-42" width="32" height="32" rx="8" transform="rotate(300)" fill="#FF5500"/>
            </g>
          </svg>
          <div>
            <div style="font-size:28px; font-weight:900; color:#000B76; font-family:sans-serif; letter-spacing:-1px; line-height:1;">cafi</div>
            <div style="font-size:8px; font-weight:800; color:#FF5500; letter-spacing:2px; font-family:sans-serif; margin-top:2px;">TU CASA FINANCIERA</div>
          </div>
        </div>
        <div style="background:#000B76; color:#ffffff; font-size:10px; font-weight:800; padding:6px 14px; border-radius:16px; text-transform:uppercase; letter-spacing:1px;">
          BRIEF INICIAL EN PDF
        </div>
      </div>

      <div style="margin-bottom:20px; padding-bottom:12px; border-bottom:1px solid #f1f5f9;">
        <div style="font-size:10px; font-weight:800; color:#FF5500; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">
          Documento Oficial de Solicitud de Diseño
        </div>
        <h1 style="font-size:20px; font-weight:800; color:#000B76; margin:0; line-height:1.3;">
          ${request.title}
        </h1>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; background:#f8fafc; border:1px solid #e2e8f0; padding:16px; border-radius:12px; margin-bottom:20px;">
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Código ID Solicitud</div>
          <div style="font-size:13px; font-weight:800; color:#000B76; margin-top:2px;">${request.id}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Estado Actual</div>
          <div style="font-size:11px; font-weight:800; color:#3730a3; background:#e0e7ff; display:inline-block; padding:2px 8px; border-radius:8px; margin-top:2px;">${request.status}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Información del Solicitante</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.advisor}</div>
          <div style="font-size:10px; font-weight:700; color:#FF5500; margin-top:2px;">Región: ${request.region || 'Bajío'} • Plaza/Estado: ${request.state || 'Guanajuato'}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Área / Asignado a</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.designer || 'Área de Marketing'}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Fecha de Registro</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.date}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Fecha Límite Deseada</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.deadline}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Prioridad</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.priority}</div>
        </div>
        <div>
          <div style="font-size:9px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Tipo de Material</div>
          <div style="font-size:12px; font-weight:700; color:#0f172a; margin-top:2px;">${request.materialType || 'General'}</div>
        </div>
      </div>

      <div style="font-size:11px; font-weight:800; color:#000B76; text-transform:uppercase; letter-spacing:1px; border-bottom:2px solid #e2e8f0; padding-bottom:4px; margin-bottom:10px;">
        Especificaciones y Requerimientos del Brief
      </div>
      <div style="background:#fafafa; border:1px solid #cbd5e1; border-left:4px solid #FF5500; padding:16px; border-radius:8px; font-size:12px; line-height:1.6; color:#1e293b; margin-bottom:20px; white-space:pre-wrap;">${request.description || 'Sin descripción adicional.'}</div>

      <div style="font-size:11px; font-weight:800; color:#000B76; text-transform:uppercase; letter-spacing:1px; border-bottom:2px solid #e2e8f0; padding-bottom:4px; margin-bottom:10px;">
        Historial de Observaciones y Comentarios
      </div>
      <div style="margin-bottom:20px;">${commentsHtml}</div>

      <div style="margin-top:24px; padding-top:12px; border-top:1px solid #e2e8f0; display:flex; justify-content:space-between; font-size:9px; color:#64748b; font-weight:600;">
        <span>Portal de Gestión CAFI • Documento de Brief en PDF</span>
        <span>Generado el ${dateStr} a las ${timeStr}</span>
      </div>
    `;

    document.body.appendChild(container);

    try {
      const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`Brief_Inicial_${request.id}.pdf`);
    } catch (err) {
      console.error('Error generando el PDF:', err);
      alert('Ocurrió un error al generar el archivo PDF del Brief.');
    } finally {
      document.body.removeChild(container);
    }
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const newComment = {
      id: Date.now().toString(),
      author: currentUserRole === 'admin' ? 'Administrador CAFI' : 'Asesor (Tú)',
      initials: currentUserRole === 'admin' ? 'ADM' : 'JS',
      time: 'Hace un momento',
      text: commentText.trim()
    };

    setComments([...comments, newComment]);
    if (onAddComment) {
      onAddComment(request.id, commentText.trim());
    }
    setCommentText('');
  };

  const handleApplyStatusChange = (e: React.FormEvent) => {
    e.preventDefault();

    if (selectedStatus === 'Completado') {
      const hasFiles = pendingFiles.length > 0 || (displayAttachments && displayAttachments.length > 0);
      if (!hasFiles) {
        setStatusError('Error: No se ha adjuntado ningún archivo. Debe adjuntar al menos un archivo entregable antes de marcar la solicitud como Completada.');
        return;
      }
    }

    setStatusError(null);
    if (onUpdateStatus) {
      onUpdateStatus(
        request.id,
        selectedStatus,
        statusNote.trim() || undefined,
        pendingFiles.length > 0 ? pendingFiles : undefined
      );
      setStatusNote('');
      setPendingFiles([]);
      setShowStatusSuccess(true);
      setTimeout(() => setShowStatusSuccess(false), 3000);
    }
  };

  // Timeline step helper functions
  const STATUS_STAGES: { status: RequestItem['status']; label: string; sub: string; icon: string }[] = [
    { status: 'Pendiente', label: '1. Recepción de Brief', sub: 'Pendiente de asignación', icon: 'inbox' },
    { status: 'En Proceso', label: '2. Producción y Diseño', sub: 'En elaboración activa', icon: 'palette' },
    { status: 'Completado', label: '3. Material Entregado', sub: 'Aprobado y listo para uso', icon: 'verified' }
  ];

  const getStageIndex = (st: RequestItem['status']) => {
    switch (st) {
      case 'Pendiente':
        return 0;
      case 'En Proceso':
        return 1;
      case 'Completado':
        return 2;
      case 'Rechazado':
        return -1;
      default:
        return 0;
    }
  };

  const currentIndex = getStageIndex(request.status);

  if (request.id === 'CAFI-EMPTY') {
    return (
      <main className="flex-1 overflow-y-auto p-md md:p-lg bg-surface-subtle flex items-center justify-center">
        <div className="max-w-md w-full bg-surface-container-lowest p-xl rounded-2xl border border-quiet shadow-sm text-center space-y-md">
          <div className="w-16 h-16 rounded-full bg-secondary/10 text-secondary flex items-center justify-center mx-auto">
            <span className="material-symbols-outlined text-[36px]">inbox</span>
          </div>
          <div>
            <h3 className="text-title-lg font-bold text-on-surface">No hay solicitudes registradas</h3>
            <p className="text-body-md text-on-surface-variant mt-xs">
              Actualmente no existen solicitudes en el sistema. Puedes crear la primera solicitud utilizando el formulario.
            </p>
          </div>
          <button
            onClick={() => onNavigate('formulario', 'slide_up')}
            className="w-full py-sm px-md bg-secondary text-on-secondary font-bold rounded-xl shadow-xs hover:bg-secondary/90 transition-colors cursor-pointer flex items-center justify-center gap-xs"
          >
            <span className="material-symbols-outlined text-[20px]">add_circle</span>
            <span>Crear Nueva Solicitud</span>
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="flex-1 overflow-y-auto p-md md:p-lg bg-surface-subtle">
      <div className="max-w-container-max mx-auto space-y-lg">
        {/* Navigation Breadcrumb & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-md bg-surface-container-lowest p-md rounded-2xl border border-quiet shadow-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('asesor', 'push_back')}
              className="p-1.5 rounded-xl bg-surface-subtle hover:bg-surface-container text-on-surface-variant transition-colors cursor-pointer flex items-center justify-center"
              title="Volver al panel"
            >
              <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-secondary">{request.id}</span>
                <span className="text-xs text-on-surface-variant">•</span>
                <span className="text-xs text-on-surface-variant font-medium">Solicitud de Diseño</span>
              </div>
              <h2 className="text-headline-md font-bold text-on-background">{request.title}</h2>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleDownloadBrief}
              className="px-md py-2 bg-primary hover:bg-primary-hover text-on-primary rounded-xl font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
              title="Descargar Brief Inicial en PDF con logotipo CAFI"
            >
              <span className="material-symbols-outlined text-[18px]">picture_as_pdf</span>
              Descargar Brief Inicial (.pdf)
            </button>
            <button
              onClick={() => onNavigate('asesor', 'push_back')}
              className="px-md py-2 bg-surface border border-quiet hover:bg-surface-container text-on-surface rounded-xl font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">view_list</span>
              Volver a la Lista
            </button>
          </div>
        </div>

        {/* VISUAL TIMELINE PROGRESS STEPPER (LÍNEA DEL TIEMPO DE STATUS) */}
        <div className="bg-surface-container-lowest p-md md:p-lg rounded-2xl border border-quiet shadow-xs space-y-md">
          <div className="flex items-center justify-between border-b border-quiet pb-sm">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary">timeline</span>
              <h3 className="text-title-md font-bold text-on-background">
                Línea del Tiempo del Estado
              </h3>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-secondary/10 text-secondary border border-secondary/20">
              Estado Actual: <strong className="uppercase">{request.status}</strong>
            </span>
          </div>

          {request.status === 'Rechazado' ? (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-md flex items-start gap-3">
              <span className="material-symbols-outlined text-rose-600 text-[24px] shrink-0 mt-0.5">
                cancel
              </span>
              <div>
                <h4 className="text-sm font-bold text-rose-900">Solicitud Cancelada o Rechazada</h4>
                <p className="text-xs text-rose-700 mt-0.5">
                  Esta solicitud ha sido marcada como rechazada. Puedes cambiar el estado nuevamente desde el panel de administración si se requiere reactivar.
                </p>
              </div>
            </div>
          ) : (
            <div className="relative pt-2 pb-2">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-md relative z-10">
                {STATUS_STAGES.map((stage, idx) => {
                  const isDone = idx < currentIndex || (request.status === 'Completado' && idx <= currentIndex);
                  const isCurrent = idx === currentIndex && request.status !== 'Completado';
                  const isFuture = !isDone && !isCurrent;

                  return (
                    <div
                      key={stage.status}
                      className={`relative p-md rounded-2xl border transition-all flex items-start gap-3 ${
                        isCurrent
                          ? 'bg-primary/5 border-primary shadow-sm ring-2 ring-primary/20'
                          : isDone
                          ? 'bg-emerald-50/50 border-emerald-300 text-slate-800'
                          : 'bg-surface-subtle border-quiet text-on-surface-variant opacity-70'
                      }`}
                    >
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-bold ${
                          isDone
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : isCurrent
                            ? 'bg-primary text-on-primary shadow-md animate-pulse'
                            : 'bg-surface-container text-on-surface-variant'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[20px]">
                          {isDone ? 'check' : stage.icon}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p
                            className={`text-xs font-bold ${
                              isCurrent
                                ? 'text-primary'
                                : isDone
                                ? 'text-emerald-800'
                                : 'text-on-surface-variant'
                            }`}
                          >
                            {stage.label}
                          </p>
                          {isCurrent && (
                            <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.5 rounded bg-primary text-on-primary">
                              En Curso
                            </span>
                          )}
                          {isDone && (
                            <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-200 text-emerald-800">
                              Listo
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-on-surface-variant mt-0.5 leading-tight">
                          {stage.sub}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ADMINISTRATOR STATUS CHANGE PANEL */}
        {currentUserRole === 'admin' && (
          <div className="bg-surface-container-lowest border-2 border-primary/30 p-md md:p-lg rounded-2xl shadow-sm space-y-md">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-quiet pb-sm">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-primary/10 rounded-xl text-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-[20px]">admin_panel_settings</span>
                </div>
                <div>
                  <h3 className="text-title-md font-bold text-primary">
                    Panel de Administración: Cambiar Estado
                  </h3>
                  <p className="text-xs text-on-surface-variant">
                    Como Administrador CAFI puedes modificar el avance de esta solicitud en tiempo real.
                  </p>
                </div>
              </div>

              {showStatusSuccess && (
                <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 animate-fadeIn">
                  <span className="material-symbols-outlined text-[16px]">check_circle</span>
                  ¡Estado actualizado correctamente!
                </div>
              )}
            </div>

            <form onSubmit={handleApplyStatusChange} className="space-y-md">
              {statusError && (
                <div className="p-md bg-rose-50 border border-rose-300 text-rose-800 rounded-xl text-xs font-bold flex items-center gap-2 animate-fadeIn">
                  <span className="material-symbols-outlined text-rose-600 text-[20px]">error</span>
                  <span>{statusError}</span>
                </div>
              )}

              <div className="space-y-xs">
                <label className="block text-xs font-bold text-on-surface uppercase tracking-wider">
                  Seleccionar Nuevo Estado:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => { setSelectedStatus('Pendiente'); setStatusError(null); }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      selectedStatus === 'Pendiente'
                        ? 'bg-amber-50 border-amber-500 text-amber-900 shadow-xs ring-2 ring-amber-400/30'
                        : 'bg-surface border-quiet text-on-surface-variant hover:bg-surface-subtle'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    Pendiente
                  </button>

                  <button
                    type="button"
                    onClick={() => { setSelectedStatus('En Proceso'); setStatusError(null); }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      selectedStatus === 'En Proceso'
                        ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-xs ring-2 ring-blue-400/30'
                        : 'bg-surface border-quiet text-on-surface-variant hover:bg-surface-subtle'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                    En Proceso
                  </button>

                  <button
                    type="button"
                    onClick={() => { setSelectedStatus('Completado'); setStatusError(null); }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      selectedStatus === 'Completado'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs ring-2 ring-emerald-400/30'
                        : 'bg-surface border-quiet text-on-surface-variant hover:bg-surface-subtle'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    Completado
                  </button>

                  <button
                    type="button"
                    onClick={() => { setSelectedStatus('Rechazado'); setStatusError(null); }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      selectedStatus === 'Rechazado'
                        ? 'bg-rose-50 border-rose-500 text-rose-900 shadow-xs ring-2 ring-rose-400/30'
                        : 'bg-surface border-quiet text-on-surface-variant hover:bg-surface-subtle'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                    Rechazado
                  </button>
                </div>
              </div>

              {/* ATTACHMENT SECTION WHEN STATUS IS COMPLETADO */}
              {selectedStatus === 'Completado' && (
                <div className="p-md bg-emerald-50/80 border-2 border-emerald-300/80 rounded-2xl space-y-sm animate-fadeIn">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <div className="p-2 bg-emerald-600 text-white rounded-xl flex items-center justify-center shrink-0 shadow-xs">
                        <span className="material-symbols-outlined text-[20px]">cloud_upload</span>
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-emerald-950 uppercase tracking-wider flex items-center gap-1.5 flex-wrap">
                          Adjuntar Archivos / Entregables Finales
                          <span className="text-[10px] font-extrabold bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full">
                            Estado Completado
                          </span>
                        </h4>
                        <p className="text-[11px] text-emerald-800 mt-0.5">
                          Formatos permitidos: <strong className="font-semibold text-emerald-950">.JPG, .PNG, .GIF, .PPTX, .CSV, .PDF, .XLSX, .DOC, .MP3, .MP4</strong>
                        </p>
                      </div>
                    </div>

                    <label className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shrink-0">
                      <span className="material-symbols-outlined text-[18px]">attach_file</span>
                      Adjuntar Archivos
                      <input
                        type="file"
                        multiple
                        accept=".jpg,.jpeg,.png,.gif,.pptx,.ptx,.csv,.pdf,.xlsx,.xls,.doc,.docx,.mp3,.mp4,image/*,audio/*,video/*,application/pdf,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/csv,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* List of Pending Files */}
                  {pendingFiles.length > 0 ? (
                    <div className="space-y-1.5 pt-2 border-t border-emerald-200">
                      <p className="text-[11px] font-bold text-emerald-900 uppercase">
                        Archivos listos para adjuntar ({pendingFiles.length}):
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {pendingFiles.map((file, idx) => (
                          <div
                            key={idx}
                            className="bg-white border border-emerald-200 rounded-xl p-2.5 flex items-center justify-between shadow-xs gap-2"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                                <span className="material-symbols-outlined text-[18px]">
                                  {getFileIcon(file.type)}
                                </span>
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-on-surface truncate" title={file.name}>
                                  {file.name}
                                </p>
                                <p className="text-[10px] text-on-surface-variant font-mono">
                                  {file.type.toUpperCase()} • {file.size || 'Archivo'}
                                </p>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleRemovePendingFile(idx)}
                              className="p-1 rounded-lg text-rose-600 hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
                              title="Quitar archivo"
                            >
                              <span className="material-symbols-outlined text-[18px]">delete</span>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-3 bg-white/60 border border-dashed border-emerald-300 rounded-xl">
                      <p className="text-xs text-emerald-800">
                        Haz clic en <strong className="font-bold text-emerald-950">"Adjuntar Archivos"</strong> para subir los entregables finales (.JPG, .PNG, .GIF, .PPTX, .CSV, .PDF, .XLSX, .DOC, .MP3, .MP4).
                      </p>
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-xs">
                <label className="block text-xs font-bold text-on-surface uppercase tracking-wider">
                  Nota o Razón del Cambio (Opcional):
                </label>
                <input
                  type="text"
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  placeholder="Ej: Archivos gráficos subidos y compartidos por correo institucional..."
                  className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2 text-body-md focus:outline-none focus:border-primary text-on-surface"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-hover text-on-primary font-bold px-lg py-2.5 rounded-xl shadow-xs transition-colors flex items-center gap-2 text-xs cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">save</span>
                  Guardar y Actualizar Estado
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Bento Grid Details & Discussion */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-md md:gap-lg">
          {/* Left Column (Details & Discussion) */}
          <div className="lg:col-span-8 flex flex-col gap-md md:gap-lg">
            {/* Request Summary Card */}
            <div className="bg-surface-container-lowest rounded-xl border border-quiet shadow-sm overflow-hidden relative">
              <div
                className={`absolute top-0 left-0 w-full h-[4px] ${
                  request.status === 'Completado'
                    ? 'bg-emerald-500'
                    : request.status === 'En Proceso'
                    ? 'bg-blue-500'
                    : request.status === 'Rechazado'
                    ? 'bg-rose-500'
                    : 'bg-amber-500'
                }`}
              ></div>
              <div className="p-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-md">
                  <h3 className="text-title-md font-title-md text-on-background font-bold">
                    Detalles de la Solicitud
                  </h3>
                  <button
                    type="button"
                    onClick={handleDownloadBrief}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary-fixed-dim/20 hover:bg-primary-fixed-dim/40 text-primary font-bold text-xs transition-colors cursor-pointer self-start sm:self-auto"
                    title="Descargar documento de Brief Inicial en PDF con logotipo CAFI"
                  >
                    <span className="material-symbols-outlined text-[16px]">picture_as_pdf</span>
                    Descargar Brief Inicial (.pdf)
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-md gap-x-lg mb-lg">
                  <div className="sm:col-span-2 bg-surface-subtle border border-quiet p-md rounded-xl">
                    <p className="text-label-md font-label-md text-on-surface-variant mb-xs font-bold uppercase tracking-wider text-[11px]">
                      Información del Solicitante
                    </p>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-sm">
                        <div className="w-10 h-10 rounded-full bg-secondary/10 text-secondary flex items-center justify-center font-bold text-sm shrink-0">
                          {request.advisor ? request.advisor.substring(0, 2).toUpperCase() : 'AS'}
                        </div>
                        <div>
                          <p className="text-body-md font-body-md text-on-background font-bold text-sm">
                            {request.advisor}
                          </p>
                          <p className="text-xs text-on-surface-variant font-medium">
                            Solicitante Asesor
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-secondary/10 text-secondary font-bold text-xs border border-secondary/20">
                          <span className="material-symbols-outlined text-[16px]">map</span>
                          Región: {request.region || 'Bajío'}
                        </span>
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-surface-container-lowest text-on-surface font-semibold text-xs border border-quiet shadow-2xs">
                          <span className="material-symbols-outlined text-[16px]">location_on</span>
                          Plaza / Estado: {request.state || 'Guanajuato'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <p className="text-label-md font-label-md text-on-surface-variant mb-xs font-medium">
                      Diseñador Asignado
                    </p>
                    <div className="flex items-center gap-sm">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                        {request.designer ? request.designer.substring(0, 2).toUpperCase() : 'DIS'}
                      </div>
                      <p className="text-body-md font-body-md text-on-background font-medium">
                        {request.designer}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-label-md font-label-md text-on-surface-variant mb-xs">
                      Fecha Límite
                    </p>
                    <p className="text-body-md font-body-md text-on-background flex items-center gap-xs font-medium">
                      <span className="material-symbols-outlined text-outline" style={{ fontSize: '16px' }}>
                        calendar_today
                      </span>
                      {request.deadline}
                    </p>
                  </div>

                  <div>
                    <p className="text-label-md font-label-md text-on-surface-variant mb-xs">
                      Prioridad
                    </p>
                    <p className="text-body-md font-body-md text-status-pending font-medium">
                      {request.priority}
                    </p>
                  </div>
                </div>

                <div className="border-t border-quiet pt-md">
                  <p className="text-label-md font-label-md text-on-surface-variant mb-sm">
                    Descripción
                  </p>
                  <p className="text-body-md font-body-md text-on-background leading-relaxed">
                    {request.description}
                  </p>
                </div>

                {displayAttachments && displayAttachments.length > 0 && (
                  <div className="mt-md border-t border-quiet pt-md space-y-md">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <p className="text-label-md font-label-md text-on-surface-variant font-bold flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-[18px] text-secondary">folder_zip</span>
                        Archivos Entregables y Adjuntos ({displayAttachments.length})
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-sm">
                      {displayAttachments.map((att, idx) => (
                        <a
                          key={idx}
                          href={att.url || '#'}
                          target={att.url ? '_blank' : undefined}
                          rel="noreferrer"
                          onClick={(e) => {
                            if (!att.url || att.name.toLowerCase().includes('brief')) {
                              e.preventDefault();
                              handleDownloadBrief();
                            }
                          }}
                          className="flex items-center gap-2 py-2 px-md rounded-xl border border-quiet bg-surface hover:bg-surface-container transition-colors text-xs text-primary font-bold shadow-2xs group cursor-pointer"
                          title="Haz clic para ver/descargar este archivo / brief en PDF"
                        >
                          <span className="material-symbols-outlined text-secondary text-[18px] group-hover:scale-110 transition-transform">
                            {att.name.toLowerCase().includes('brief') ? 'picture_as_pdf' : getFileIcon(att.type || att.name)}
                          </span>
                          <span className="truncate max-w-[200px]">{att.name}</span>
                          {att.size && (
                            <span className="text-[10px] text-on-surface-variant font-normal bg-surface-subtle px-1.5 py-0.5 rounded">
                              {att.size}
                            </span>
                          )}
                          <span className="material-symbols-outlined text-[14px] text-primary font-bold">download</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Discussion Area */}
            <div className="bg-surface-container-lowest rounded-xl border border-quiet shadow-sm p-lg">
              <h3 className="text-title-md font-title-md text-on-background mb-lg flex items-center gap-sm font-bold">
                <span className="material-symbols-outlined text-on-surface-variant">forum</span>
                Discusión y Actividad
              </h3>

              <div className="space-y-lg mb-lg">
                {comments.length === 0 ? (
                  <p className="text-xs text-on-surface-variant italic">
                    No hay comentarios registrados aún en esta solicitud.
                  </p>
                ) : (
                  comments.map((comment) => (
                    <div key={comment.id} className="flex gap-md">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex-shrink-0 flex items-center justify-center text-primary font-bold text-xs">
                        {comment.initials || 'US'}
                      </div>
                      <div className="flex-1 bg-surface-subtle p-md rounded-xl rounded-tl-none border border-quiet">
                        <div className="flex justify-between items-center mb-xs">
                          <span className="font-title-md text-sm text-on-background font-semibold">
                            {comment.author}
                          </span>
                          <span className="text-label-md text-on-surface-variant">{comment.time}</span>
                        </div>
                        <p className="text-body-md font-body-md text-on-background">{comment.text}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Comment Input */}
              <form onSubmit={handlePostComment} className="flex gap-md">
                <div className="w-9 h-9 rounded-full bg-primary/20 flex-shrink-0 flex items-center justify-center text-primary font-bold text-xs">
                  {currentUserRole === 'admin' ? 'ADM' : 'AS'}
                </div>
                <div className="flex-1">
                  <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    rows={3}
                    placeholder="Añadir un comentario o nota de seguimiento..."
                    className="w-full bg-surface-container-lowest border border-quiet rounded-xl p-sm text-body-md font-body-md focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors resize-none"
                  />
                  <div className="flex justify-between items-center mt-sm">
                    <span className="text-[11px] text-on-surface-variant">
                      Visibilidad para el equipo de diseño y asesores.
                    </span>
                    <button
                      type="submit"
                      className="px-md py-sm bg-primary text-on-primary rounded-xl font-label-md text-label-md hover:bg-primary-hover transition-colors cursor-pointer shadow-xs font-semibold flex items-center gap-1.5"
                    >
                      <span className="material-symbols-outlined text-[16px]">send</span>
                      Publicar Comentario
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>

          {/* Right Column (History Timeline) */}
          <div className="lg:col-span-4">
            <div className="bg-surface-container-lowest rounded-xl border border-quiet shadow-sm p-lg sticky top-[90px]">
              <h3 className="text-title-md font-title-md text-on-background mb-lg flex items-center gap-sm font-bold">
                <span className="material-symbols-outlined text-secondary">history</span>
                Historial de Registro
              </h3>

              <div className="relative pl-sm">
                {/* Vertical Line Connector */}
                <div className="absolute left-[19px] top-2 bottom-2 w-[2px] bg-quiet"></div>

                {/* Timeline Nodes */}
                <div className="space-y-lg relative">
                  {request.history && request.history.length > 0 ? (
                    request.history.map((node) => {
                      const isCompleted = node.status === 'completed';
                      return (
                        <div key={node.id} className="flex gap-md relative z-10">
                          {isCompleted ? (
                            <div className="w-[22px] h-[22px] rounded-full bg-emerald-600 flex items-center justify-center border-[3px] border-surface-container-lowest shrink-0 mt-0.5 shadow-2xs">
                              <span
                                className="material-symbols-outlined text-white"
                                style={{ fontSize: '12px', fontWeight: 'bold' }}
                              >
                                check
                              </span>
                            </div>
                          ) : (
                            <div className="w-[22px] h-[22px] rounded-full bg-primary flex items-center justify-center border-[3px] border-surface-container-lowest shrink-0 mt-0.5 shadow-2xs">
                              <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                            </div>
                          )}

                          <div>
                            <p className="text-xs font-bold text-on-background">{node.title}</p>
                            <p className="text-[11px] text-on-surface-variant font-mono">{node.date}</p>
                            <p className="text-xs text-on-surface-variant mt-1 leading-snug">
                              {node.detail}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="flex gap-md relative z-10">
                      <div className="w-[22px] h-[22px] rounded-full bg-primary flex items-center justify-center border-[3px] border-surface-container-lowest shrink-0 mt-0.5">
                        <span
                          className="material-symbols-outlined text-white"
                          style={{ fontSize: '12px' }}
                        >
                          add
                        </span>
                      </div>
                      <div>
                        <p className="text-xs font-bold text-on-background">Solicitud Creada</p>
                        <p className="text-[11px] text-on-surface-variant font-mono">{request.date}</p>
                        <p className="text-xs text-on-surface-variant mt-1">
                          Registrada en el portal por {request.advisor}.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};
