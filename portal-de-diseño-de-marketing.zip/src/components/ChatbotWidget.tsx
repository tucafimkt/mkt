import React, { useState, useRef, useEffect } from 'react';
import { ScreenType, TransitionType, RequestItem } from '../types';
import { CafiLogo } from './CafiLogo';

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  actionButton?: {
    label: string;
    screen: ScreenType;
    transition?: TransitionType;
  };
}

interface ChatbotWidgetProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  requestsCount?: number;
  pendingCount?: number;
}

export const ChatbotWidget: React.FC<ChatbotWidgetProps> = ({
  onNavigate,
  requestsCount = 0,
  pendingCount = 0
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showTooltip, setShowTooltip] = useState(true);
  const [inputValue, setInputValue] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'bot',
      text: `Hola! 👋 ¡Bienvenido al Portal de Marketing de CAFI (Tu Casa Financiera)!  Soy tu asistente virtual. Estoy aquí para guiarte en la solicitud de material publicitario.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setShowTooltip(false);
    }
  }, [isOpen, messages]);

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputValue.trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputValue('');

    // Process bot reply
    setTimeout(() => {
      let botReplyText = '';
      let actionButton: ChatMessage['actionButton'] = undefined;

      const lower = text.toLowerCase();

      if (lower.includes('fuente') || lower.includes('inspiraci') || lower.includes('diseños hechos') || lower.includes('anterior')) {
        botReplyText = `🎨 **Fuentes de Inspiración & Galería de Diseños Anteriores:**\n\nAquí puedes revisar los estilos y ejemplos de materiales publicitarios realizados previamente para CAFI:\n\n1. 📱 **Publicaciones & Banners para Redes** (Historias y Post con ofertas de crédito)\n2. 📄 **Flyers Impresos & Volantes** (Formatos promocionales para sucursales)\n3. 🖥️ **Pantallas Digitales & Mupis** (Anuncios publicitarios de alta visibilidad)\n4. ✉️ **Plantillas Informativas & Mailing**\n\n¿Te gustaría usar una de estas fuentes como referencia para crear tu nuevo material publicitario?`;
        actionButton = {
          label: '➕ Crear Solicitud de Material',
          screen: 'formulario',
          transition: 'slide_up'
        };
      } else if (lower.includes('sla') || lower.includes('tiempo') || lower.includes('entrega') || lower.includes('plazo')) {
        botReplyText = `⏱️ **Tiempos Estándar de Entrega (SLAs):**\n\n• **Alta Prioridad**: 24 a 48 horas (piezas urgentes para campañas activas).\n• **Media Prioridad**: 3 a 5 días hábiles (material publicitario estándar).\n• **Baja Prioridad**: 5 a 7 días hábiles (diseños institucionales de largo plazo).`;
      } else if (lower.includes('status') || lower.includes('estado') || lower.includes('solicitud') || lower.includes('pendiente')) {
        botReplyText = `📊 **Status de tu Solicitud:**\n\nActualmente hay **${requestsCount} solicitudes** registradas en total (${pendingCount} pendientes de atención por el equipo de diseño). Puedes consultar el avance en tiempo real en tu panel.`;
        actionButton = {
          label: '📋 Consultar Mis Solicitudes',
          screen: 'asesor',
          transition: 'push_back'
        };
      } else {
        botReplyText = `Entendido. Como asesor, puedes enviar briefs para nuevas campañas o revisar el status de tus piezas solicitadas. ¿En qué más puedo ayudarte?`;
        actionButton = {
          label: '➕ Nueva Solicitud de Material',
          screen: 'formulario',
          transition: 'slide_up'
        };
      }

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: botReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actionButton
      };

      setMessages((prev) => [...prev, botMsg]);
    }, 600);
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      {/* Expanded Chat Box */}
      {isOpen ? (
        <div className="w-[360px] sm:w-[400px] h-[520px] max-h-[80vh] bg-surface-container-lowest rounded-2xl border border-quiet shadow-2xl flex flex-col overflow-hidden animate-scaleUp border-t-4 border-t-primary">
          {/* Header */}
          <div className="p-md bg-gradient-to-r from-primary to-[#001999] text-on-primary flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center border border-white/20 relative">
                <span className="material-symbols-outlined text-[20px] text-white">smart_toy</span>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-status-completed border-2 border-primary rounded-full"></span>
              </div>
              <div>
                <h4 className="text-title-sm font-bold leading-tight">Asistente CAFI Marketing</h4>
                <p className="text-[11px] text-white/80 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  En línea | Portal de Diseño
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsOpen(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                title="Minimizar"
              >
                <span className="material-symbols-outlined text-[20px]">remove</span>
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-md space-y-md bg-surface-subtle text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-end gap-1.5 max-w-[85%]">
                  {msg.sender === 'bot' && (
                    <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 mb-1">
                      <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                    </div>
                  )}

                  <div
                    className={`p-3 rounded-2xl shadow-xs whitespace-pre-wrap leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-secondary text-on-secondary rounded-br-none'
                        : 'bg-surface-container-lowest text-on-surface border border-quiet rounded-bl-none'
                    }`}
                  >
                    {msg.text}

                    {/* Optional Interactive Action Button inside message */}
                    {msg.actionButton && (
                      <div className="mt-3 pt-2 border-t border-quiet/50">
                        <button
                          onClick={() => {
                            if (msg.actionButton) {
                              onNavigate(msg.actionButton.screen, msg.actionButton.transition);
                              setIsOpen(false);
                            }
                          }}
                          className="w-full bg-primary text-on-primary hover:bg-primary-hover font-bold py-1.5 px-md rounded-lg transition-colors text-center text-xs flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                        >
                          {msg.actionButton.label}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <span className="text-[10px] text-on-surface-variant mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestions Chips */}
          <div className="p-xs bg-surface-container-lowest border-t border-quiet overflow-x-auto flex gap-1.5 no-scrollbar">
            <button
              onClick={() => handleSendMessage('Consultar Tiempos (SLAs)')}
              className="shrink-0 text-[11px] bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 px-2.5 py-1 rounded-full font-semibold transition-colors cursor-pointer"
            >
              ⏱️ Tiempos (SLAs)
            </button>
            <button
              onClick={() => handleSendMessage('Ver Fuentes de inspiración')}
              className="shrink-0 text-[11px] bg-secondary/10 hover:bg-secondary/20 text-secondary border border-secondary/20 px-2.5 py-1 rounded-full font-semibold transition-colors cursor-pointer"
            >
              💡 Fuentes de inspiración
            </button>
            <button
              onClick={() => handleSendMessage('Consultar Status de la solicitud')}
              className="shrink-0 text-[11px] bg-surface-container hover:bg-surface-container-high text-on-surface border border-quiet px-2.5 py-1 rounded-full font-semibold transition-colors cursor-pointer"
            >
              📊 Status de la solicitud
            </button>
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-sm bg-surface-container-lowest border-t border-quiet flex items-center gap-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Escribe tu mensaje o pregunta..."
              className="flex-1 bg-surface-subtle border border-quiet rounded-xl px-sm py-2 text-xs focus:outline-none focus:border-primary transition-colors text-on-surface"
            />
            <button
              type="submit"
              disabled={!inputValue.trim()}
              className="w-9 h-9 rounded-xl bg-primary hover:bg-primary-hover text-on-primary flex items-center justify-center disabled:opacity-40 transition-all cursor-pointer shrink-0 shadow-xs"
            >
              <span className="material-symbols-outlined text-[18px]">send</span>
            </button>
          </form>
        </div>
      ) : (
        /* Floating Trigger Button with Animated Orange Ring */
        <div className="relative flex items-center justify-center">
          {/* Animated pulsing orange halo */}
          <span className="absolute w-16 h-16 rounded-full bg-secondary/60 animate-ping opacity-75 pointer-events-none"></span>
          <span className="absolute w-16 h-16 rounded-full bg-secondary/30 animate-pulse pointer-events-none"></span>

          {/* Floating Trigger Button */}
          <button
            onClick={() => setIsOpen(true)}
            className="relative w-14 h-14 rounded-full bg-primary hover:bg-primary-hover text-on-primary shadow-2xl flex items-center justify-center transition-transform hover:scale-105 active:scale-95 cursor-pointer ring-4 ring-secondary"
            title="Abrir Asistente de Marketing CAFI"
          >
            <span className="material-symbols-outlined text-[28px]">smart_toy</span>
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-secondary text-on-secondary rounded-full text-[9px] font-bold flex items-center justify-center border-2 border-surface shadow-xs">
              1
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
