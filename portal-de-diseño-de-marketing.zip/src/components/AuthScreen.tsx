import React, { useState, useEffect } from 'react';
import { UserRole, PortalSettings } from '../types';

export interface RegisteredUser {
  name: string;
  email: string;
  password: string;
  role: UserRole;
  userRoleName?: string;
  region?: string;
  phone?: string;
}

export const REGION_OPTIONS = [
  'Bajío',
  'Centro',
  'Chiapas',
  'Golfo',
  'Península',
  'Norte',
  'Noroeste'
] as const;

export const ROL_OPTIONS = [
  'Asesor de Ventas',
  'Coordinador Regional',
  'Ejecutivo de Marketing'
] as const;

const DEFAULT_USERS: RegisteredUser[] = [
  {
    name: 'Administrador CAFI',
    email: 'admin.mkt@tucafi.com',
    password: 'admin123',
    role: 'admin',
    userRoleName: 'Ejecutivo de Marketing',
    region: 'Centro',
    phone: '+1 (555) 100-2000'
  },
  {
    name: 'Asesor de Ventas',
    email: 'asesor.ventas@tucafi.com',
    password: 'cafi2026',
    role: 'usuario',
    userRoleName: 'Asesor de Ventas',
    region: 'Bajío',
    phone: '+1 (555) 234-5678'
  }
];

interface AuthScreenProps {
  onLogin: (user: { name: string; email: string; role: UserRole; region?: string }) => void;
  settings?: PortalSettings;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, settings }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'verify_code' | 'otp_login'>('login');

  // Registered Users state persisted in localStorage
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>(() => {
    try {
      const saved = localStorage.getItem('cafi_registered_users');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return DEFAULT_USERS;
  });

  // Save registered users whenever changed
  useEffect(() => {
    try {
      localStorage.setItem('cafi_registered_users', JSON.stringify(registeredUsers));
    } catch {
      // Ignore storage errors
    }
  }, [registeredUsers]);

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('usuario');
  const [rememberMe, setRememberMe] = useState(true);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRegion, setRegRegion] = useState<string>('Bajío');
  const [regRoleName, setRegRoleName] = useState<string>('Asesor de Ventas');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(true);

  // Confirmation Code & Verification State
  const [pendingUser, setPendingUser] = useState<RegisteredUser | null>(null);
  const [verificationCode, setVerificationCode] = useState<string>('');
  const [inputCode, setInputCode] = useState<string>('');
  const [otpEmail, setOtpEmail] = useState<string>('');
  const [resendCountdown, setResendCountdown] = useState<number>(0);
  const [emailNotification, setEmailNotification] = useState<{
    to: string;
    subject: string;
    code: string;
    timestamp: string;
  } | null>(null);

  // UI States
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Countdown timer effect
  useEffect(() => {
    if (resendCountdown > 0) {
      const timer = setTimeout(() => setResendCountdown((prev) => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCountdown]);

  // Generate a random 6-digit confirmation code
  const generateCode = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  // Helper to send code to subscriber's email
  const sendCodeToSubscriberEmail = (targetEmail: string, isLoginOtp: boolean = false) => {
    const newCode = generateCode();
    setVerificationCode(newCode);
    setInputCode('');
    setResendCountdown(30);

    const notificationData = {
      to: targetEmail,
      subject: isLoginOtp
        ? 'Código de confirmación para inicio de sesión en CAFI'
        : 'Código de confirmación para suscripción y registro en CAFI',
      code: newCode,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setEmailNotification(notificationData);
    setSuccessMsg(`¡Código de confirmación enviado exitosamente al correo del suscriptor (${targetEmail})!`);
  };

  // Quick Demo Logins using registered credentials
  const handleFillDemoCredentials = (role: UserRole) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const demoUser = registeredUsers.find((u) => u.role === role) || (role === 'admin' ? DEFAULT_USERS[0] : DEFAULT_USERS[1]);
    setLoginEmail(demoUser.email);
    setLoginPassword(demoUser.password);
    setLoginRole(demoUser.role);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const emailTrimmed = loginEmail.trim().toLowerCase();
    const passwordTrimmed = loginPassword.trim();

    if (!emailTrimmed || !passwordTrimmed) {
      setErrorMsg('Por favor ingresa tu correo electrónico y contraseña.');
      return;
    }

    // Security check: Verify registered user
    const foundUser = registeredUsers.find((u) => u.email.toLowerCase() === emailTrimmed);

    if (!foundUser) {
      setErrorMsg('El correo ingresado no está registrado. Si eres un nuevo usuario, por favor ve a "Crear Cuenta".');
      return;
    }

    if (foundUser.password !== passwordTrimmed) {
      setErrorMsg('Contraseña incorrecta. Ingresa la contraseña exacta con la que registraste tu perfil.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin({
        name: foundUser.name,
        email: foundUser.email,
        role: foundUser.role,
        region: foundUser.region || 'Noreste'
      });
    }, 500);
  };

  // Register form submit: Sends confirmation code to email before activating account
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const emailTrimmed = regEmail.trim().toLowerCase();
    const nameTrimmed = regName.trim();
    const passwordTrimmed = regPassword.trim();

    if (!nameTrimmed || !emailTrimmed || !passwordTrimmed) {
      setErrorMsg('Por favor completa todos los campos requeridos (*).');
      return;
    }

    if (passwordTrimmed.length < 4) {
      setErrorMsg('La contraseña debe tener al menos 4 caracteres.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Las contraseñas no coinciden. Verifícalas e intenta nuevamente.');
      return;
    }

    if (!acceptTerms) {
      setErrorMsg('Debes aceptar las políticas de uso y privacidad del portal.');
      return;
    }

    // Check if email already registered
    const existing = registeredUsers.find((u) => u.email.toLowerCase() === emailTrimmed);
    if (existing) {
      setErrorMsg('Ya existe un perfil registrado con este correo. Por favor inicia sesión con tu contraseña.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const mappedRole: UserRole = regRoleName === 'Ejecutivo de Marketing' ? 'admin' : 'usuario';
      const newUser: RegisteredUser = {
        name: nameTrimmed,
        email: emailTrimmed,
        password: passwordTrimmed,
        role: mappedRole,
        userRoleName: regRoleName,
        region: regRegion,
        phone: regPhone.trim()
      };

      setPendingUser(newUser);
      sendCodeToSubscriberEmail(emailTrimmed, false);
      setMode('verify_code');
    }, 500);
  };

  // Request Code for Email OTP Login
  const handleRequestOtpLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const emailTrimmed = otpEmail.trim().toLowerCase();
    if (!emailTrimmed) {
      setErrorMsg('Por favor ingresa tu correo de suscriptor.');
      return;
    }

    const foundUser = registeredUsers.find((u) => u.email.toLowerCase() === emailTrimmed);
    if (!foundUser) {
      setErrorMsg('El correo ingresado no está registrado en la plataforma. Por favor regístrate primero.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      sendCodeToSubscriberEmail(emailTrimmed, true);
    }, 400);
  };

  // Verify entered 6-digit confirmation code
  const handleVerifyCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (inputCode.trim() !== verificationCode.trim()) {
      setErrorMsg('El código de confirmación ingresado es incorrecto. Verifícalo en la notificación e intenta de nuevo.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);

      if (pendingUser) {
        // Complete registration
        setRegisteredUsers((prev) => [...prev, pendingUser]);
        setSuccessMsg('¡Código verificado con éxito! Cuenta activada e ingresando...');

        setTimeout(() => {
          onLogin({
            name: pendingUser.name,
            email: pendingUser.email,
            role: pendingUser.role,
            region: pendingUser.region || 'Bajío'
          });
        }, 600);
      } else if (otpEmail) {
        // Complete OTP login
        const user = registeredUsers.find((u) => u.email.toLowerCase() === otpEmail.toLowerCase());
        if (user) {
          setSuccessMsg('¡Código verificado! Ingresando al portal...');
          setTimeout(() => {
            onLogin({
              name: user.name,
              email: user.email,
              role: user.role,
              region: user.region || 'Bajío'
            });
          }, 600);
        }
      }
    }, 500);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-primary/95 via-primary to-[#000a42] flex items-center justify-center p-md relative overflow-hidden font-sans">
      {/* Decorative background geometric accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-secondary/15 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary-container/20 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20"></div>

      {/* Main Container Card */}
      <div className="w-full max-w-[460px] bg-surface-container-lowest rounded-3xl shadow-2xl border border-white/20 overflow-hidden relative z-10 animate-scaleUp my-auto mx-auto">
        {/* Card Header with CAFI Branding */}
        <div className="p-lg bg-surface-bright border-b border-quiet text-center space-y-2">
          <p className="text-xs font-bold text-secondary uppercase tracking-widest pt-1">
            Portal Seguro de Marketing y Diseño
          </p>
          <p className="text-label-md text-on-surface-variant max-w-xs mx-auto">
            Ingreso protegido con contraseña requerida para todos los usuarios.
          </p>
        </div>

        {/* Tab Switcher: Login / Register */}
        <div className="flex border-b border-quiet bg-surface-subtle p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              mode === 'login'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">login</span>
            Iniciar Sesión
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              mode === 'register'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">person_add</span>
            Crear Cuenta
          </button>
        </div>

        {/* Form Area */}
        <div className="p-lg space-y-md">
          {/* Success Message Banner */}
          {successMsg && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-sm text-xs font-semibold flex items-center gap-2 animate-fadeIn">
              <span className="material-symbols-outlined text-[18px] text-emerald-600 shrink-0">
                check_circle
              </span>
              {successMsg}
            </div>
          )}

          {/* Error Message Banner */}
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 rounded-xl p-sm text-xs font-semibold flex items-center gap-2 animate-shake">
              <span className="material-symbols-outlined text-[18px] text-rose-600 shrink-0">
                error
              </span>
              {errorMsg}
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-md">
              {/* Email */}
              <div className="space-y-1">
                <label className="block text-label-md font-bold text-on-surface">
                  Correo Registrado *
                </label>
                <div className="relative">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">
                    mail
                  </span>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="usuario@tucafi.com"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl pl-10 pr-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface transition-colors"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="block text-label-md font-bold text-on-surface">
                    Contraseña Registrada *
                  </label>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setOtpEmail(loginEmail || '');
                      setMode('otp_login');
                      setErrorMsg(null);
                      setSuccessMsg(null);
                    }}
                    className="text-[11px] font-bold text-secondary hover:underline"
                  >
                    ¿Ingresar con código por correo?
                  </a>
                </div>
                <div className="relative">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">
                    lock
                  </span>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Contraseña del perfil"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl pl-10 pr-10 py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">
                      {showPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="remember"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-quiet text-primary focus:ring-primary w-4 h-4 cursor-pointer"
                />
                <label htmlFor="remember" className="text-xs text-on-surface-variant cursor-pointer font-medium">
                  Recordar mi sesión en este navegador
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary hover:bg-primary-hover text-on-primary font-bold py-3 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Verificando Contraseña...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[20px]">verified_user</span>
                    Ingresar con Contraseña
                  </>
                )}
              </button>

              <div className="pt-2 text-center border-t border-quiet">
                <button
                  type="button"
                  onClick={() => {
                    setOtpEmail(loginEmail || '');
                    setMode('otp_login');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-xs font-bold text-secondary hover:text-primary transition-colors inline-flex items-center gap-1 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">mark_email_read</span>
                  Solicitar Código de Confirmación a mi correo
                </button>
              </div>
            </form>
          )}

          {/* OTP LOGIN FORM */}
          {mode === 'otp_login' && (
            <form onSubmit={handleRequestOtpLogin} className="space-y-md animate-fadeIn">
              <div className="space-y-1">
                <label className="block text-label-md font-bold text-on-surface">
                  Correo del Suscriptor *
                </label>
                <div className="relative">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">
                    mail
                  </span>
                  <input
                    type="email"
                    required
                    value={otpEmail}
                    onChange={(e) => setOtpEmail(e.target.value)}
                    placeholder="suscriptor@tucafi.com"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl pl-10 pr-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  />
                </div>
                <p className="text-[11px] text-on-surface-variant mt-1">
                  Enviaremos un código de confirmación de 6 dígitos a la bandeja de entrada de este correo.
                </p>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-secondary hover:bg-secondary-hover text-on-secondary font-bold py-3 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Enviando Correo...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[20px]">send</span>
                    Enviar Código al Correo
                  </>
                )}
              </button>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-xs font-semibold text-on-surface-variant hover:text-primary"
                >
                  Volver al inicio con contraseña
                </button>
              </div>
            </form>
          )}

          {/* VERIFY CODE FORM (FOR REGISTER & OTP LOGIN) */}
          {mode === 'verify_code' && (
            <form onSubmit={handleVerifyCodeSubmit} className="space-y-md animate-fadeIn">
              {/* Email Notification Dispatch Card */}
              {emailNotification && (
                <div className="bg-primary/5 border border-primary/20 rounded-2xl p-md text-left space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-primary">
                    <span className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[18px]">mark_email_read</span>
                      Correo de Confirmación Enviado
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                      {emailNotification.timestamp}
                    </span>
                  </div>
                  <p className="text-xs text-on-surface-variant">
                    Hemos enviado el código de confirmación al correo del suscriptor:
                  </p>
                  <div className="bg-white border border-quiet rounded-xl p-2.5 flex items-center justify-between shadow-xs">
                    <span className="font-mono text-xs font-bold text-on-surface truncate">
                      {emailNotification.to}
                    </span>
                    <span className="font-mono text-base font-black text-secondary tracking-widest bg-secondary/10 px-2.5 py-1 rounded-lg">
                      {emailNotification.code}
                    </span>
                  </div>
                  <p className="text-[11px] text-outline italic">
                    Utiliza este código de 6 dígitos para verificar el correo y continuar.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <label className="block text-label-md font-bold text-on-surface text-center">
                  Ingresa el Código de Confirmación (6 Dígitos)
                </label>
                <div className="relative max-w-xs mx-auto">
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="w-full bg-surface-subtle border-2 border-primary/40 rounded-2xl py-3 text-center font-mono font-black text-headline-md tracking-[0.4em] text-primary focus:outline-none focus:border-primary shadow-inner"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || inputCode.length < 6}
                className="w-full bg-primary hover:bg-primary-hover text-on-primary font-bold py-3 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Verificando Código...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[20px]">verified</span>
                    Confirmar Código y Activar
                  </>
                )}
              </button>

              <div className="flex justify-between items-center text-xs pt-1">
                <button
                  type="button"
                  disabled={resendCountdown > 0}
                  onClick={() => {
                    const target = pendingUser?.email || otpEmail;
                    if (target) {
                      sendCodeToSubscriberEmail(target, !pendingUser);
                    }
                  }}
                  className="font-bold text-secondary hover:underline disabled:opacity-50 cursor-pointer"
                >
                  {resendCountdown > 0
                    ? `Reenviar correo en ${resendCountdown}s`
                    : 'Reenviar código por correo'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMode(pendingUser ? 'register' : 'login');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-on-surface-variant hover:text-on-surface cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            </form>
          )}

          {/* REGISTER FORM */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-md">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="block text-label-md font-bold text-on-surface">
                  Nombre Completo *
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="ej., Lic. Roberto Gómez"
                  className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                />
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Correo *
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="r.gomez@tucafi.com"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+1 (555) 123-4567"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  />
                </div>
              </div>

              {/* Region & Role */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Región
                  </label>
                  <select
                    value={regRegion}
                    onChange={(e) => setRegRegion(e.target.value)}
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  >
                    {REGION_OPTIONS.map((reg) => (
                      <option key={reg} value={reg}>
                        {reg}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Rol
                  </label>
                  <select
                    value={regRoleName}
                    onChange={(e) => setRegRoleName(e.target.value)}
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface font-semibold"
                  >
                    {ROL_OPTIONS.map((rol) => (
                      <option key={rol} value={rol}>
                        {rol}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Passwords */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Crea tu Contraseña *
                  </label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Mínimo 4 caracteres"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-label-md font-bold text-on-surface">
                    Confirma Contraseña *
                  </label>
                  <input
                    type="password"
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="Repetir contraseña"
                    className="w-full bg-surface-subtle border border-quiet rounded-xl px-sm py-2.5 text-body-md focus:outline-none focus:border-primary text-on-surface"
                  />
                </div>
              </div>

              {/* Terms Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="terms"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="rounded border-quiet text-primary focus:ring-primary w-4 h-4 cursor-pointer"
                />
                <label htmlFor="terms" className="text-xs text-on-surface-variant cursor-pointer font-medium">
                  Acepto las políticas de uso y confidencialidad del portal CAFI.
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-secondary hover:bg-secondary-hover text-on-secondary font-bold py-3 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Guardando Perfil...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[20px]">key</span>
                    Registrar Perfil con Contraseña
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Card Footer */}
        <div className="p-sm bg-surface-subtle border-t border-quiet text-center text-[11px] text-on-surface-variant">
          Portal Institucional CAFI — Tu Casa Financiera © {new Date().getFullYear()}
        </div>
      </div>
    </div>
  );
};

