import React, { useState } from 'react';
import { RequestItem, ScreenType, TransitionType } from '../types';
import { MexicoMap, MEXICAN_STATES_COORDS, StateData } from './MexicoMap';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  CartesianGrid
} from 'recharts';

interface KpiAdminPanelProps {
  requests?: RequestItem[];
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onSelectRequest?: (request: RequestItem) => void;
}

const REGION_COLORS: Record<string, string> = {
  'Región Chiapas': '#E11D48', // Rose / Red
  'Centro': '#000B76',         // Primary Dark Blue
  'Golfo': '#0284C7',          // Sky Blue
  'Península': '#0D9488',      // Teal
  'Bajío': '#FF5500',          // Secondary Orange
  'Norte': '#10B981',          // Emerald Green
  'Noroeste': '#8B5CF6',       // Purple
  'Occidente': '#3B82F6',      // Blue
  'Sur': '#F59E0B'             // Amber
};

export const KpiAdminPanel: React.FC<KpiAdminPanelProps> = ({
  requests = [],
  onNavigate,
  onSelectRequest
}) => {
  const [selectedMapState, setSelectedMapState] = useState<string | null>(null);

  const total = requests.length;
  const pending = requests.filter((r) => r.status === 'Pendiente').length;
  const inProcess = requests.filter((r) => r.status === 'En Proceso').length;
  const completed = requests.filter((r) => r.status === 'Completado').length;
  const rejected = requests.filter((r) => r.status === 'Rechazado').length;

  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;
  const pendingPct = total > 0 ? Math.round((pending / total) * 100) : 0;
  const inProcessPct = total > 0 ? Math.round((inProcess / total) * 100) : 0;
  const completedPct = total > 0 ? Math.round((completed / total) * 100) : 0;
  const rejectedPct = total > 0 ? Math.round((rejected / total) * 100) : 0;

  // 1. Regional Statistics Breakdown
  const regionMap: Record<
    string,
    { total: number; completed: number; inProcess: number; pending: number; states: Set<string> }
  > = {};

  // 2. State Statistics Breakdown
  const stateMap: Record<
    string,
    { region: string; total: number; completed: number; inProcess: number; pending: number }
  > = {};

  requests.forEach((r) => {
    // Region determination
    const reg = r.region || MEXICAN_STATES_COORDS[r.state || '']?.region || 'Bajío';
    // State determination
    const st = r.state || 'Guanajuato';

    // Region grouping
    if (!regionMap[reg]) {
      regionMap[reg] = { total: 0, completed: 0, inProcess: 0, pending: 0, states: new Set() };
    }
    regionMap[reg].total += 1;
    if (r.status === 'Completado') regionMap[reg].completed += 1;
    if (r.status === 'En Proceso') regionMap[reg].inProcess += 1;
    if (r.status === 'Pendiente') regionMap[reg].pending += 1;
    regionMap[reg].states.add(st);

    // State grouping
    if (!stateMap[st]) {
      stateMap[st] = { region: reg, total: 0, completed: 0, inProcess: 0, pending: 0 };
    }
    stateMap[st].total += 1;
    if (r.status === 'Completado') stateMap[st].completed += 1;
    if (r.status === 'En Proceso') stateMap[st].inProcess += 1;
    if (r.status === 'Pendiente') stateMap[st].pending += 1;
  });

  // Prepare data arrays for Recharts
  const regionChartData = Object.entries(regionMap).map(([name, data]) => ({
    name,
    value: data.total,
    percentage: total > 0 ? Math.round((data.total / total) * 100) : 0,
    completed: data.completed,
    inProcess: data.inProcess,
    pending: data.pending,
    statesCount: data.states.size,
    color: REGION_COLORS[name] || '#64748b'
  })).sort((a, b) => b.value - a.value);

  const stateChartData = Object.entries(stateMap).map(([name, data]) => ({
    state: name,
    region: data.region,
    total: data.total,
    Completado: data.completed,
    'En Proceso': data.inProcess,
    Pendiente: data.pending,
    code: MEXICAN_STATES_COORDS[name]?.code || 'MX'
  })).sort((a, b) => b.total - a.total);

  // Full state data for Mexico Map component
  const fullMexicoStateData: StateData[] = Object.entries(stateMap).map(([name, data]) => ({
    state: name,
    region: data.region,
    count: data.total,
    inProcess: data.inProcess,
    completed: data.completed,
    pending: data.pending,
    code: MEXICAN_STATES_COORDS[name]?.code || 'MX',
    x: MEXICAN_STATES_COORDS[name]?.x || 50,
    y: MEXICAN_STATES_COORDS[name]?.y || 50
  }));

  // Aggregate by Advisor
  const advisorMap: Record<
    string,
    { total: number; completed: number; inProcess: number; pending: number; region: string }
  > = {};

  requests.forEach((r) => {
    const name = r.advisor && r.advisor !== 'N/A' ? r.advisor : 'Sin Asesor Asignado';
    if (!advisorMap[name]) {
      advisorMap[name] = {
        total: 0,
        completed: 0,
        inProcess: 0,
        pending: 0,
        region: r.region || 'Bajío'
      };
    }
    advisorMap[name].total += 1;
    if (r.status === 'Completado') advisorMap[name].completed += 1;
    if (r.status === 'En Proceso') advisorMap[name].inProcess += 1;
    if (r.status === 'Pendiente') advisorMap[name].pending += 1;
  });

  const advisorList = Object.entries(advisorMap)
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.total - a.total);

  // Recent activity
  const recentActivities = requests
    .flatMap((req) =>
      (req.history || []).map((h) => ({
        id: h.id,
        title: h.title,
        date: h.date,
        detail: h.detail,
        reqId: req.id,
        reqTitle: req.title,
        request: req
      }))
    )
    .slice(0, 6);

  return (
    <main className="flex-1 overflow-y-auto p-md md:p-lg bg-surface-subtle">
      <div className="max-w-[1280px] mx-auto flex flex-col gap-lg pb-16">
        {/* Header Banner */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-sm bg-surface-container-lowest p-md rounded-2xl border border-quiet shadow-xs">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-7 rounded-full bg-secondary inline-block"></span>
              <h2 className="text-headline-md font-bold text-primary">
                Panel de Control de KPIs y Cobertura Nacional
              </h2>
            </div>
            <p className="text-body-md text-on-surface-variant mt-0.5">
              Estadísticas e indicadores en tiempo real de solicitudes por región, estado y estatus.
            </p>
          </div>
          <div className="flex gap-sm">
            <button
              onClick={() => alert('Generando informe completo de KPIs por Región y Estado en PDF...')}
              className="flex items-center gap-xs px-md py-2 border border-quiet rounded-xl text-xs font-bold text-primary hover:bg-surface-subtle transition-colors bg-surface-container-lowest shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">picture_as_pdf</span>
              Exportar PDF
            </button>
            <button
              onClick={() => alert('Exportando informe de KPIs por Región y Estado en Excel...')}
              className="flex items-center gap-xs px-md py-2 border border-quiet rounded-xl text-xs font-bold text-primary hover:bg-surface-subtle transition-colors bg-surface-container-lowest shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">table_view</span>
              Exportar Excel
            </button>
          </div>
        </div>

        {/* Executive KPI Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-md">
          {/* Total */}
          <div className="bg-surface-container-lowest border border-quiet rounded-2xl p-md shadow-xs relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-primary"></div>
            <div className="flex justify-between items-start mb-sm mt-xs">
              <span className="text-label-md font-bold text-on-surface-variant uppercase tracking-wider">
                Solicitudes Totales
              </span>
              <span className="material-symbols-outlined text-outline">description</span>
            </div>
            <div className="text-display font-black text-on-background mb-xs">
              {total}
            </div>
            <div className="text-xs text-on-surface-variant flex items-center gap-xs font-medium">
              <span className="material-symbols-outlined text-[16px] text-primary">public</span>
              <span>Distribuidas en {Object.keys(regionMap).length} regiones y {Object.keys(stateMap).length} estados</span>
            </div>
          </div>

          {/* Pending */}
          <div className="bg-surface-container-lowest border border-quiet rounded-2xl p-md shadow-xs relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-amber-500"></div>
            <div className="flex justify-between items-start mb-sm mt-xs">
              <span className="text-label-md font-bold text-on-surface-variant uppercase tracking-wider">
                Pendientes
              </span>
              <span className="material-symbols-outlined text-amber-600">hourglass_empty</span>
            </div>
            <div className="text-display font-black text-on-background mb-xs">
              {pending}
            </div>
            <div className="text-xs text-amber-700 font-medium">
              {pendingPct}% del total registrado
            </div>
          </div>

          {/* In Process */}
          <div className="bg-surface-container-lowest border border-quiet rounded-2xl p-md shadow-xs relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-blue-500"></div>
            <div className="flex justify-between items-start mb-sm mt-xs">
              <span className="text-label-md font-bold text-on-surface-variant uppercase tracking-wider">
                En Proceso
              </span>
              <span className="material-symbols-outlined text-blue-600">design_services</span>
            </div>
            <div className="text-display font-black text-on-background mb-xs">
              {inProcess}
            </div>
            <div className="text-xs text-blue-700 font-medium">
              {inProcessPct}% en producción activa
            </div>
          </div>

          {/* Completion Rate */}
          <div className="bg-surface-container-lowest border border-quiet rounded-2xl p-md shadow-xs relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
            <div className="flex justify-between items-start mb-sm mt-xs">
              <span className="text-label-md font-bold text-on-surface-variant uppercase tracking-wider">
                Tasa de Finalización
              </span>
              <span className="material-symbols-outlined text-emerald-600">check_circle</span>
            </div>
            <div className="text-display font-black text-on-background mb-xs">
              {completionRate}%
            </div>
            <div className="text-xs text-emerald-700 font-medium">
              {completed} completadas de {total} totales
            </div>
          </div>
        </div>

        {/* SECTION: Interactive Mexico Map */}
        <div className="bg-surface-container-lowest border border-quiet rounded-2xl p-md md:p-lg shadow-xs space-y-md">
          <MexicoMap
            stateData={fullMexicoStateData}
            selectedState={selectedMapState}
            onSelectState={(st) => setSelectedMapState(st === selectedMapState ? null : st)}
          />
        </div>

        {/* SECTION: Regional & State Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-md">
          {/* Chart 1: Pie Chart - Solicitudes por Región */}
          <div className="lg:col-span-5 bg-surface-container-lowest border border-quiet rounded-2xl p-md md:p-lg shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-quiet pb-sm mb-md">
                <h3 className="text-title-md text-primary font-bold flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">pie_chart</span>
                  Solicitud por Región (Gráfica de Pastel)
                </h3>
                <span className="text-[11px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                  {regionChartData.length} Regiones
                </span>
              </div>
              <p className="text-xs text-on-surface-variant mb-md">
                Porcentaje y proporción de solicitudes ingresadas según cada región geográfica.
              </p>
            </div>

            {total === 0 ? (
              <div className="py-12 text-center text-on-surface-variant">
                <span className="material-symbols-outlined text-[48px] text-slate-300">pie_chart</span>
                <p className="font-bold text-xs mt-2">Sin datos para mostrar gráfica</p>
              </div>
            ) : (
              <div className="w-full h-[260px] relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={regionChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {regionChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: number, name: string, props: any) => [
                        `${val} solicitud(es) (${props.payload.percentage}%)`,
                        `Región ${props.payload.name}`
                      ]}
                      contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', color: '#fff', fontSize: '12px', border: 'none' }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={36}
                      formatter={(value, entry: any) => (
                        <span className="text-xs font-bold text-on-surface px-1">
                          {value} ({entry.payload.percentage}%)
                        </span>
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Region Detail Cards List */}
            <div className="mt-md space-y-2 border-t border-quiet pt-md">
              {regionChartData.map((reg) => (
                <div key={reg.name} className="flex items-center justify-between p-2 bg-surface-subtle rounded-xl text-xs font-medium border border-quiet">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: reg.color }}></span>
                    <span className="font-bold text-on-surface">Región {reg.name}</span>
                    <span className="text-[10px] text-on-surface-variant">({reg.statesCount} estados)</span>
                  </div>
                  <div className="flex items-center gap-3 font-bold">
                    <span className="text-primary">{reg.value} pedidos</span>
                    <span className="text-secondary font-black bg-secondary/10 px-2 py-0.5 rounded-md text-[11px]">
                      {reg.percentage}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Chart 2: Bar Chart - Solicitud por Estado */}
          <div className="lg:col-span-7 bg-surface-container-lowest border border-quiet rounded-2xl p-md md:p-lg shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-quiet pb-sm mb-md">
                <h3 className="text-title-md text-primary font-bold flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">bar_chart</span>
                  Solicitud por Estado (Gráfica de Barras)
                </h3>
                <span className="text-[11px] font-bold bg-secondary/10 text-secondary px-2.5 py-0.5 rounded-full">
                  Top Estados Activos
                </span>
              </div>
              <p className="text-xs text-on-surface-variant mb-md">
                Desglose comparativo por estado mostrando el número de proyectos en cada estatus.
              </p>
            </div>

            {stateChartData.length === 0 ? (
              <div className="py-12 text-center text-on-surface-variant">
                <span className="material-symbols-outlined text-[48px] text-slate-300">bar_chart</span>
                <p className="font-bold text-xs mt-2">Sin solicitudes registradas por estado</p>
              </div>
            ) : (
              <div className="w-full h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stateChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis
                      dataKey="state"
                      tick={{ fontSize: 10, fontWeight: 'bold', fill: '#475569' }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis tick={{ fontSize: 10, fill: '#64748b' }} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', color: '#fff', fontSize: '12px', border: 'none' }}
                      cursor={{ fill: 'rgba(0, 11, 118, 0.05)' }}
                    />
                    <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                    <Bar dataKey="Pendiente" fill="#f59e0b" radius={[4, 4, 0, 0]} stackId="a" />
                    <Bar dataKey="En Proceso" fill="#3b82f6" radius={[4, 4, 0, 0]} stackId="a" />
                    <Bar dataKey="Completado" fill="#10b981" radius={[4, 4, 0, 0]} stackId="a" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* State Table Summary */}
            <div className="mt-md border-t border-quiet pt-md">
              <h4 className="text-xs font-bold text-primary uppercase tracking-wider mb-sm flex items-center justify-between">
                <span>Tabla de Cobertura por Estado</span>
                <span className="text-[10px] text-on-surface-variant font-normal">Mostrando los estados con mayor demanda</span>
              </h4>
              <div className="overflow-x-auto max-h-[180px] overflow-y-auto border border-quiet rounded-xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-surface-subtle border-b border-quiet font-bold text-on-surface-variant uppercase text-[10px]">
                      <th className="p-2">Estado</th>
                      <th className="p-2">Región</th>
                      <th className="p-2 text-center text-amber-700">Pend.</th>
                      <th className="p-2 text-center text-blue-700">Proc.</th>
                      <th className="p-2 text-center text-emerald-700">Comp.</th>
                      <th className="p-2 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stateChartData.map((st) => (
                      <tr key={st.state} className="border-b border-quiet hover:bg-surface-subtle transition-colors">
                        <td className="p-2 font-bold text-primary flex items-center gap-1.5">
                          <span className="w-5 h-5 rounded bg-primary/10 text-primary font-bold text-[9px] flex items-center justify-center">
                            {st.code}
                          </span>
                          {st.state}
                        </td>
                        <td className="p-2 text-on-surface-variant font-medium">{st.region}</td>
                        <td className="p-2 text-center font-bold text-amber-700">{st.Pendiente}</td>
                        <td className="p-2 text-center font-bold text-blue-700">{st['En Proceso']}</td>
                        <td className="p-2 text-center font-bold text-emerald-700">{st.Completado}</td>
                        <td className="p-2 text-right font-black text-on-surface">{st.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION: Advisor Breakdown & Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-md">
          {/* Table: Top Advisors */}
          <div className="lg:col-span-6 bg-surface-container-lowest border border-quiet rounded-2xl p-0 shadow-xs flex flex-col overflow-hidden">
            <div className="p-md border-b border-quiet flex justify-between items-center bg-surface-subtle">
              <h3 className="text-title-md font-bold text-primary flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary">badge</span>
                Resumen por Asesor Solicitante
              </h3>
              <span className="text-xs font-bold text-on-surface-variant">
                Total: {advisorList.length} asesores
              </span>
            </div>

            {advisorList.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-md text-center text-on-surface-variant">
                <span className="material-symbols-outlined text-[48px] text-slate-300 mb-2">person_off</span>
                <p className="font-bold text-body-md text-on-surface">No hay datos de asesores</p>
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-quiet bg-surface-container-lowest uppercase font-bold text-on-surface-variant text-[10px]">
                      <th className="p-sm">Asesor</th>
                      <th className="p-sm">Región</th>
                      <th className="p-sm text-center">En Proceso</th>
                      <th className="p-sm text-center">Completadas</th>
                      <th className="p-sm text-right">Total Pedidos</th>
                    </tr>
                  </thead>
                  <tbody className="text-on-surface">
                    {advisorList.map((adv, idx) => (
                      <tr key={idx} className="border-b border-quiet hover:bg-surface-subtle transition-colors">
                        <td className="p-sm font-bold text-primary flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-secondary/10 text-secondary flex items-center justify-center font-bold text-[11px]">
                            {adv.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()}
                          </div>
                          {adv.name}
                        </td>
                        <td className="p-sm text-on-surface-variant font-medium">{adv.region}</td>
                        <td className="p-sm text-center font-bold text-blue-700">{adv.inProcess}</td>
                        <td className="p-sm text-center font-bold text-emerald-700">{adv.completed}</td>
                        <td className="p-sm text-right font-black text-on-surface">{adv.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Activity Feed */}
          <div className="lg:col-span-6 bg-surface-container-lowest border border-quiet rounded-2xl p-lg shadow-xs flex flex-col">
            <h3 className="text-title-md font-bold text-primary mb-md border-b border-quiet pb-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary">history</span>
              Historial de Actividad Reciente
            </h3>

            {recentActivities.length === 0 ? (
              <div className="p-md text-center text-on-surface-variant">
                <p className="font-bold text-body-md text-on-surface">Sin registros de actividad reciente</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-sm">
                {recentActivities.map((act) => (
                  <div
                    key={act.id}
                    onClick={() => {
                      if (onSelectRequest && act.request) {
                        onSelectRequest(act.request);
                        onNavigate('detalle', 'push');
                      }
                    }}
                    className="p-sm bg-surface-subtle border border-quiet rounded-xl hover:border-primary/40 transition-all cursor-pointer space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-primary">
                      <span>{act.reqId}</span>
                      <span className="text-[10px] text-on-surface-variant font-normal">{act.date}</span>
                    </div>
                    <p className="text-body-sm font-bold text-on-surface line-clamp-1">{act.title}</p>
                    <p className="text-xs text-on-surface-variant line-clamp-1">{act.detail}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
};
