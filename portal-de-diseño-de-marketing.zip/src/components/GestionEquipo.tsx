import React, { useState } from 'react';
import { Advisor, ScreenType, TransitionType } from '../types';
import { REGION_OPTIONS, ROL_OPTIONS } from './AuthScreen';

interface GestionEquipoProps {
  advisors: Advisor[];
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onAddAdvisor: (newAdvisor: Advisor) => void;
  onEditAdvisor: (updatedAdvisor: Advisor) => void;
  onDeleteAdvisor: (advisorId: string) => void;
}

export const GestionEquipo: React.FC<GestionEquipoProps> = ({
  advisors,
  onNavigate,
  onAddAdvisor,
  onEditAdvisor,
  onDeleteAdvisor
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'Todos' | 'Activo' | 'Inactivo' | 'Pendiente'>('Todos');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [addModalStep, setAddModalStep] = useState<'form' | 'success'>('form');
  const [recentlyAddedAdvisor, setRecentlyAddedAdvisor] = useState<Advisor | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [editingAdvisor, setEditingAdvisor] = useState<Advisor | null>(null);
  const [deletingAdvisor, setDeletingAdvisor] = useState<Advisor | null>(null);

  // Form State for Add / Edit
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    region: 'Bajío',
    role: 'Asesor de Ventas',
    status: 'Activo' as 'Activo' | 'Inactivo' | 'Pendiente'
  });

  // Notification Banner State
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Filter Logic
  const filteredAdvisors = advisors.filter((adv) => {
    const matchesSearch =
      adv.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      adv.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      adv.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
      adv.role.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'Todos' || adv.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Stats
  const totalCount = advisors.length;
  const activeCount = advisors.filter((a) => a.status === 'Activo').length;
  const pendingCount = advisors.filter((a) => a.status === 'Pendiente').length;
  const totalActiveRequests = advisors.reduce((acc, curr) => acc + (curr.activeRequestsCount || 0), 0);

  // Open Add Modal
  const handleOpenAddModal = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      region: 'Bajío',
      role: 'Asesor de Ventas',
      status: 'Activo'
    });
    setAddModalStep('form');
    setRecentlyAddedAdvisor(null);
    setCopiedCode(false);
    setIsAddModalOpen(true);
  };

  // Submit Add Advisor
  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) return;

    const initials = formData.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase() || 'AS';

    const newAdv: Advisor = {
      id: `ADV-${Math.floor(Math.random() * 9000 + 1000)}`,
      name: formData.name.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim() || '+1 (555) 000-0000',
      region: formData.region,
      role: formData.role,
      status: formData.status,
      subscriptionDate: 'Hoy',
      initials,
      activeRequestsCount: 0
    };

    onAddAdvisor(newAdv);
    setRecentlyAddedAdvisor(newAdv);
    setAddModalStep('success');
    showNotification(`Asesor "${newAdv.name}" suscrito con éxito.`);
  };

  // Open Edit Modal
  const handleOpenEditModal = (adv: Advisor) => {
    setEditingAdvisor(adv);
    setFormData({
      name: adv.name,
      email: adv.email,
      phone: adv.phone,
      region: adv.region,
      role: adv.role,
      status: adv.status
    });
  };

  // Submit Edit Advisor
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdvisor) return;

    const initials = formData.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase() || editingAdvisor.initials;

    const updated: Advisor = {
      ...editingAdvisor,
      name: formData.name.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim(),
      region: formData.region,
      role: formData.role,
      status: formData.status,
      initials
    };

    onEditAdvisor(updated);
    setEditingAdvisor(null);
    showNotification(`Información de "${updated.name}" actualizada.`);
  };

  // Confirm Delete Advisor
  const handleConfirmDelete = () => {
    if (!deletingAdvisor) return;
    onDeleteAdvisor(deletingAdvisor.id);
    showNotification(`Asesor "${deletingAdvisor.name}" eliminado del equipo.`);
    setDeletingAdvisor(null);
  };

  const getStatusBadge = (status: Advisor['status']) => {
    switch (status) {
      case 'Activo':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-completed/10 text-status-completed border border-status-completed/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-completed"></span>
            Activo
          </span>
        );
      case 'Pendiente':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-pending/10 text-status-pending border border-status-pending/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-pending"></span>
            Pendiente
          </span>
        );
      case 'Inactivo':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-outline/10 text-outline border border-outline/20">
            <span className="w-1.5 h-1.5 rounded-full bg-outline"></span>
            Inactivo
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <main className="flex-1 overflow-y-auto p-md md:p-lg bg-surface-subtle relative">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 bg-primary text-on-primary px-lg py-sm rounded-xl shadow-lg flex items-center gap-sm animate-bounce">
          <span className="material-symbols-outlined text-[20px]">check_circle</span>
          <span className="font-body-md font-semibold text-sm">{notification}</span>
        </div>
      )}

      <div className="max-w-[1280px] mx-auto space-y-lg pb-xl">
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-md">
          <div>
            <div className="flex items-center gap-xs text-label-md text-on-surface-variant mb-xs">
              <button
                onClick={() => onNavigate('asesor', 'push_back')}
                className="hover:text-primary transition-colors cursor-pointer"
              >
                Panel de Control
              </button>
              <span>/</span>
              <span className="text-primary font-semibold">Gestión de Equipo</span>
            </div>
            <h2 className="text-headline-lg font-display font-bold text-on-background">
              Gestión de Equipo de Asesores
            </h2>
            <p className="text-body-md text-on-surface-variant">
              Administra la lista de asesores suscritos al portal de marketing, edita sus datos o revoca sus accesos.
            </p>
          </div>

          <button
            onClick={handleOpenAddModal}
            className="px-lg py-sm bg-primary text-on-primary font-title-md font-bold rounded-xl hover:bg-primary-container transition-all shadow-md flex items-center gap-xs cursor-pointer shrink-0"
          >
            <span className="material-symbols-outlined text-[20px]">person_add</span>
            Suscribir Asesor
          </button>
        </div>

        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-md">
          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between">
            <div>
              <p className="text-label-md text-on-surface-variant uppercase font-medium tracking-wider">
                Total Suscritos
              </p>
              <p className="text-headline-lg font-bold text-on-background mt-xs font-tabular-nums">
                {totalCount}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[26px]">group</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-status-completed">
            <div>
              <p className="text-label-md text-on-surface-variant uppercase font-medium tracking-wider">
                Asesores Activos
              </p>
              <p className="text-headline-lg font-bold text-status-completed mt-xs font-tabular-nums">
                {activeCount}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-status-completed/10 flex items-center justify-center text-status-completed">
              <span className="material-symbols-outlined text-[26px]">how_to_reg</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-status-pending">
            <div>
              <p className="text-label-md text-on-surface-variant uppercase font-medium tracking-wider">
                Suscripciones Pendientes
              </p>
              <p className="text-headline-lg font-bold text-status-pending mt-xs font-tabular-nums">
                {pendingCount}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-status-pending/10 flex items-center justify-center text-status-pending">
              <span className="material-symbols-outlined text-[26px]">pending</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-primary">
            <div>
              <p className="text-label-md text-on-surface-variant uppercase font-medium tracking-wider">
                Solicitudes Activas
              </p>
              <p className="text-headline-lg font-bold text-primary mt-xs font-tabular-nums">
                {totalActiveRequests}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary-container/20 flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[26px]">assignment_turned_in</span>
            </div>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex flex-col md:flex-row gap-md justify-between items-center">
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <span className="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline text-[20px]">
              search
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nombre, email o región..."
              className="w-full bg-surface-subtle border border-quiet rounded-lg pl-9 pr-sm py-2 text-body-md text-on-surface focus:outline-none focus:border-primary transition-colors"
            />
          </div>

          {/* Status Filter Tabs & Layout Toggle */}
          <div className="flex flex-wrap items-center gap-sm w-full md:w-auto justify-between md:justify-end">
            <div className="flex bg-surface-subtle border border-quiet rounded-lg p-1">
              {(['Todos', 'Activo', 'Pendiente', 'Inactivo'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-sm py-1 rounded-md text-label-md font-semibold transition-all cursor-pointer ${
                    statusFilter === status
                      ? 'bg-surface-container-lowest text-primary shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="flex bg-surface-subtle border border-quiet rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                title="Vista de Cuadrícula"
                className={`p-1.5 rounded-md transition-all cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-surface-container-lowest text-primary shadow-xs'
                    : 'text-outline hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">grid_view</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                title="Vista de Lista / Tabla"
                className={`p-1.5 rounded-md transition-all cursor-pointer ${
                  viewMode === 'table'
                    ? 'bg-surface-container-lowest text-primary shadow-xs'
                    : 'text-outline hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">view_list</span>
              </button>
            </div>
          </div>
        </div>

        {/* Advisors Display */}
        {filteredAdvisors.length === 0 ? (
          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-xl text-center space-y-sm">
            <div className="w-16 h-16 rounded-full bg-surface-container mx-auto flex items-center justify-center text-outline">
              <span className="material-symbols-outlined text-[32px]">person_off</span>
            </div>
            <h3 className="text-title-md font-bold text-on-background">No se encontraron asesores</h3>
            <p className="text-body-md text-on-surface-variant max-w-md mx-auto">
              No hay ningún asesor que coincida con la búsqueda "{searchTerm}" o el filtro seleccionado.
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('Todos');
              }}
              className="px-md py-xs bg-surface-container text-primary font-semibold rounded-lg hover:bg-surface-container-high transition-colors"
            >
              Limpiar Filtros
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          /* Cards Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-md">
            {filteredAdvisors.map((adv) => (
              <div
                key={adv.id}
                className="bg-surface-container-lowest border border-quiet rounded-xl p-lg shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative group"
              >
                <div>
                  <div className="flex justify-between items-start mb-md">
                    <div className="flex items-center gap-md">
                      {adv.avatar ? (
                        <img
                          src={adv.avatar}
                          alt={adv.name}
                          className="w-12 h-12 rounded-full object-cover border border-quiet"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container font-bold text-lg">
                          {adv.initials}
                        </div>
                      )}
                      <div>
                        <h3 className="text-title-md font-bold text-on-background group-hover:text-primary transition-colors">
                          {adv.name}
                        </h3>
                        <p className="text-label-md text-on-surface-variant">{adv.role}</p>
                      </div>
                    </div>
                    {getStatusBadge(adv.status)}
                  </div>

                  <div className="space-y-xs border-t border-quiet pt-md text-body-md text-on-surface-variant">
                    <div className="flex items-center gap-xs">
                      <span className="material-symbols-outlined text-outline text-[18px]">mail</span>
                      <span className="truncate">{adv.email}</span>
                    </div>
                    <div className="flex items-center gap-xs">
                      <span className="material-symbols-outlined text-outline text-[18px]">call</span>
                      <span>{adv.phone}</span>
                    </div>
                    <div className="flex justify-between items-center pt-xs text-xs font-medium">
                      <span className="inline-flex items-center gap-1 bg-surface-subtle px-2 py-0.5 rounded text-outline">
                        <span className="material-symbols-outlined text-[14px]">map</span>
                        {adv.region}
                      </span>
                      <span className="text-outline">
                        Suscrito: <strong className="text-on-background">{adv.subscriptionDate}</strong>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions Footer */}
                <div className="flex items-center justify-between border-t border-quiet pt-md mt-md">
                  <span className="text-xs font-semibold text-primary bg-primary-fixed/30 px-2 py-1 rounded">
                    {adv.activeRequestsCount} solicitud{adv.activeRequestsCount === 1 ? '' : 'es'} activa{adv.activeRequestsCount === 1 ? '' : 's'}
                  </span>

                  <div className="flex items-center gap-xs">
                    <button
                      onClick={() => handleOpenEditModal(adv)}
                      title="Editar Asesor"
                      className="p-2 text-on-surface-variant hover:text-primary hover:bg-surface-container rounded-lg transition-colors cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[20px]">edit</span>
                    </button>
                    <button
                      onClick={() => setDeletingAdvisor(adv)}
                      title="Eliminar Asesor"
                      className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-lg transition-colors cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[20px]">delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Table View */
          <div className="bg-surface-container-lowest border border-quiet rounded-xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-surface-subtle border-b border-quiet font-label-md text-on-surface-variant">
                    <th className="py-sm px-md font-semibold">Asesor</th>
                    <th className="py-sm px-md font-semibold">Contacto</th>
                    <th className="py-sm px-md font-semibold">Región / Rol</th>
                    <th className="py-sm px-md font-semibold">Estado</th>
                    <th className="py-sm px-md font-semibold text-center">Solicitudes</th>
                    <th className="py-sm px-md font-semibold text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-quiet text-body-md">
                  {filteredAdvisors.map((adv) => (
                    <tr key={adv.id} className="hover:bg-surface-subtle transition-colors">
                      <td className="py-sm px-md">
                        <div className="flex items-center gap-sm">
                          {adv.avatar ? (
                            <img
                              src={adv.avatar}
                              alt={adv.name}
                              className="w-9 h-9 rounded-full object-cover border border-quiet"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container font-bold text-xs">
                              {adv.initials}
                            </div>
                          )}
                          <div>
                            <p className="font-bold text-on-background">{adv.name}</p>
                            <p className="text-xs text-outline">{adv.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-sm px-md text-on-surface-variant">
                        <p>{adv.email}</p>
                        <p className="text-xs text-outline">{adv.phone}</p>
                      </td>
                      <td className="py-sm px-md">
                        <p className="font-medium text-on-background">{adv.role}</p>
                        <p className="text-xs text-outline">{adv.region}</p>
                      </td>
                      <td className="py-sm px-md">{getStatusBadge(adv.status)}</td>
                      <td className="py-sm px-md text-center font-bold text-primary font-tabular-nums">
                        {adv.activeRequestsCount}
                      </td>
                      <td className="py-sm px-md text-right">
                        <div className="flex items-center justify-end gap-xs">
                          <button
                            onClick={() => handleOpenEditModal(adv)}
                            title="Editar"
                            className="p-1.5 text-on-surface-variant hover:text-primary hover:bg-surface-container rounded-md transition-colors"
                          >
                            <span className="material-symbols-outlined text-[18px]">edit</span>
                          </button>
                          <button
                            onClick={() => setDeletingAdvisor(adv)}
                            title="Eliminar"
                            className="p-1.5 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-md transition-colors"
                          >
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Modal: Add Advisor */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-md backdrop-blur-xs">
          <div className="bg-surface-container-lowest rounded-3xl border border-quiet shadow-2xl max-w-lg w-full p-lg space-y-md animate-scaleUp overflow-hidden">
            
            {addModalStep === 'form' ? (
              <>
                <div className="flex justify-between items-center border-b border-quiet pb-sm">
                  <div>
                    <span className="text-[10px] font-bold text-secondary uppercase tracking-wider">
                      Paso 1 de 2 • Registro
                    </span>
                    <h3 className="text-headline-md font-bold text-on-background flex items-center gap-xs">
                      <span className="material-symbols-outlined text-primary">person_add</span>
                      Suscribir Nuevo Asesor
                    </h3>
                  </div>
                  <button
                    onClick={() => setIsAddModalOpen(false)}
                    className="text-outline hover:text-on-background p-1 rounded-full cursor-pointer"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <form onSubmit={handleSaveAdd} className="space-y-md">
                  <div>
                    <label className="block text-label-md font-bold text-on-surface mb-xs">
                      Nombre Completo *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="ej., Carlos Ramírez López"
                      className="w-full border border-quiet rounded-xl p-sm text-body-md focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                    <div>
                      <label className="block text-label-md font-bold text-on-surface mb-xs">
                        Correo Institucional *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="c.ramirez@tucafi.com"
                        className="w-full border border-quiet rounded-xl p-sm text-body-md focus:border-primary outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-label-md font-bold text-on-surface mb-xs">
                        Teléfono Móvil
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full border border-quiet rounded-xl p-sm text-body-md focus:border-primary outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                    <div>
                      <label className="block text-label-md font-bold text-on-surface mb-xs">
                        Región
                      </label>
                      <select
                        value={formData.region}
                        onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                        className="w-full border border-quiet rounded-xl p-sm text-body-md focus:border-primary outline-none"
                      >
                        {REGION_OPTIONS.map((reg) => (
                          <option key={reg} value={reg}>
                            {reg}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-label-md font-bold text-on-surface mb-xs">
                        Rol
                      </label>
                      <select
                        value={formData.role}
                        onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                        className="w-full border border-quiet rounded-xl p-sm text-body-md focus:border-primary outline-none font-medium"
                      >
                        {ROL_OPTIONS.map((rol) => (
                          <option key={rol} value={rol}>
                            {rol}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-label-md font-bold text-on-surface mb-xs">
                      Estado de la Suscripción
                    </label>
                    <div className="flex gap-md bg-surface-subtle p-sm rounded-xl border border-quiet">
                      {(['Activo', 'Pendiente', 'Inactivo'] as const).map((st) => (
                        <label key={st} className="flex items-center gap-xs cursor-pointer text-body-md font-medium">
                          <input
                            type="radio"
                            name="status"
                            checked={formData.status === st}
                            onChange={() => setFormData({ ...formData, status: st })}
                            className="text-primary focus:ring-primary"
                          />
                          {st}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-sm flex items-start gap-sm">
                    <span className="material-symbols-outlined text-primary text-[20px] mt-0.5 shrink-0">
                      mark_email_read
                    </span>
                    <p className="text-xs text-on-surface-variant leading-snug">
                      Al suscribir al asesor, el sistema enviará un correo de bienvenida automático con sus credenciales de acceso e instrucciones para ingresar al Portal CAFI.
                    </p>
                  </div>

                  <div className="flex justify-end gap-sm pt-md border-t border-quiet">
                    <button
                      type="button"
                      onClick={() => setIsAddModalOpen(false)}
                      className="px-md py-sm rounded-xl border border-quiet font-semibold text-on-surface hover:bg-surface-container cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-lg py-sm rounded-xl bg-primary hover:bg-primary-hover text-on-primary font-bold shadow-md flex items-center gap-xs cursor-pointer transition-all"
                    >
                      <span className="material-symbols-outlined text-[18px]">check_circle</span>
                      Guardar y Suscribir
                    </button>
                  </div>
                </form>
              </>
            ) : (
              /* PASO 2: SUCCESS SCREEN */
              <div className="text-center space-y-md py-xs animate-fadeIn">
                <div className="w-20 h-20 rounded-full bg-status-completed/15 text-status-completed mx-auto flex items-center justify-center ring-8 ring-status-completed/10 animate-bounce">
                  <span className="material-symbols-outlined text-[48px]">verified</span>
                </div>

                <div>
                  <span className="text-xs font-bold text-status-completed uppercase tracking-widest bg-status-completed/10 px-md py-0.5 rounded-full border border-status-completed/20">
                    Suscripción Completada
                  </span>
                  <h3 className="text-headline-md font-bold text-on-background mt-2">
                    ¡Asesor Suscrito Exitosamente!
                  </h3>
                  <p className="text-body-md text-on-surface-variant mt-1 max-w-sm mx-auto">
                    El asesor ya ha sido registrado formalmente en la plataforma y tiene acceso al portal de materiales publicitarios.
                  </p>
                </div>

                {/* Advisor Summary Card */}
                {recentlyAddedAdvisor && (
                  <div className="bg-surface-subtle border border-quiet rounded-2xl p-md text-left space-y-sm relative">
                    <div className="flex items-center gap-md">
                      <div className="w-12 h-12 rounded-full bg-primary text-on-primary font-bold text-lg flex items-center justify-center shrink-0 shadow-xs">
                        {recentlyAddedAdvisor.initials}
                      </div>
                      <div className="overflow-hidden">
                        <h4 className="font-bold text-on-background text-title-md truncate">
                          {recentlyAddedAdvisor.name}
                        </h4>
                        <p className="text-xs text-on-surface-variant truncate">
                          {recentlyAddedAdvisor.email} • {recentlyAddedAdvisor.phone}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[11px] font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-md">
                            {recentlyAddedAdvisor.role}
                          </span>
                          <span className="text-[11px] font-semibold bg-surface-container text-on-surface-variant px-2 py-0.5 rounded-md">
                            {recentlyAddedAdvisor.region}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Temporary Credentials / Invite Code Box */}
                    <div className="bg-white border border-secondary/30 rounded-xl p-sm space-y-1">
                      <div className="flex justify-between items-center text-xs text-on-surface-variant">
                        <span className="font-bold text-secondary flex items-center gap-1">
                          <span className="material-symbols-outlined text-[16px]">vpn_key</span>
                          Código Temporal de Activación:
                        </span>
                        <span className="font-mono text-[11px] text-outline">ID: {recentlyAddedAdvisor.id}</span>
                      </div>

                      <div className="flex items-center justify-between bg-surface-subtle p-2 rounded-lg border border-quiet">
                        <code className="font-mono font-bold text-primary text-sm tracking-wider">
                          CAFI-{recentlyAddedAdvisor.id.replace('ADV-', '')}-2026
                        </code>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`CAFI-${recentlyAddedAdvisor.id.replace('ADV-', '')}-2026`);
                            setCopiedCode(true);
                            setTimeout(() => setCopiedCode(false), 2500);
                          }}
                          className="px-2.5 py-1 bg-secondary text-on-secondary text-xs font-bold rounded-md hover:bg-secondary-hover transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[14px]">
                            {copiedCode ? 'done' : 'content_copy'}
                          </span>
                          {copiedCode ? '¡Copiado!' : 'Copiar'}
                        </button>
                      </div>
                    </div>

                    {/* Email confirmation note */}
                    <div className="flex items-center gap-2 text-xs text-status-completed font-semibold">
                      <span className="material-symbols-outlined text-[16px]">check_circle</span>
                      Notificación y guía de bienvenida enviadas por correo electrónico
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-sm pt-xs">
                  <button
                    type="button"
                    onClick={handleOpenAddModal}
                    className="flex-1 py-2.5 px-md rounded-xl border border-quiet font-bold text-primary hover:bg-surface-container cursor-pointer flex items-center justify-center gap-1 text-xs"
                  >
                    <span className="material-symbols-outlined text-[18px]">person_add</span>
                    Suscribir Otro Asesor
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 py-2.5 px-md rounded-xl bg-primary hover:bg-primary-hover text-on-primary font-bold shadow-md cursor-pointer flex items-center justify-center gap-1 text-xs"
                  >
                    <span className="material-symbols-outlined text-[18px]">done_all</span>
                    Finalizar y Ver Equipo
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* Modal: Edit Advisor */}
      {editingAdvisor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-md">
          <div className="bg-surface-container-lowest rounded-2xl border border-quiet shadow-2xl max-w-lg w-full p-lg space-y-md">
            <div className="flex justify-between items-center border-b border-quiet pb-sm">
              <h3 className="text-headline-md font-bold text-on-background flex items-center gap-xs">
                <span className="material-symbols-outlined text-primary">edit</span>
                Editar Asesor - {editingAdvisor.name}
              </h3>
              <button
                onClick={() => setEditingAdvisor(null)}
                className="text-outline hover:text-on-background p-1 rounded-full"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-md">
              <div>
                <label className="block text-label-md font-semibold text-on-surface mb-xs">
                  Nombre Completo *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border border-quiet rounded-lg p-sm text-body-md focus:border-primary outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                <div>
                  <label className="block text-label-md font-semibold text-on-surface mb-xs">
                    Correo Electrónico *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full border border-quiet rounded-lg p-sm text-body-md focus:border-primary outline-none"
                  />
                </div>
                <div>
                  <label className="block text-label-md font-semibold text-on-surface mb-xs">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full border border-quiet rounded-lg p-sm text-body-md focus:border-primary outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
                <div>
                  <label className="block text-label-md font-semibold text-on-surface mb-xs">
                    Región
                  </label>
                  <select
                    value={formData.region}
                    onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                    className="w-full border border-quiet rounded-lg p-sm text-body-md focus:border-primary outline-none"
                  >
                    {REGION_OPTIONS.map((reg) => (
                      <option key={reg} value={reg}>
                        {reg}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-label-md font-semibold text-on-surface mb-xs">
                    Rol
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full border border-quiet rounded-lg p-sm text-body-md focus:border-primary outline-none font-medium"
                  >
                    {ROL_OPTIONS.map((rol) => (
                      <option key={rol} value={rol}>
                        {rol}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-label-md font-semibold text-on-surface mb-xs">
                  Estado
                </label>
                <div className="flex gap-md">
                  {(['Activo', 'Pendiente', 'Inactivo'] as const).map((st) => (
                    <label key={st} className="flex items-center gap-xs cursor-pointer text-body-md">
                      <input
                        type="radio"
                        name="status_edit"
                        checked={formData.status === st}
                        onChange={() => setFormData({ ...formData, status: st })}
                        className="text-primary focus:ring-primary"
                      />
                      {st}
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-sm pt-md border-t border-quiet">
                <button
                  type="button"
                  onClick={() => setEditingAdvisor(null)}
                  className="px-md py-sm rounded-lg border border-quiet font-semibold text-on-surface hover:bg-surface-container"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-md py-sm rounded-lg bg-primary text-on-primary font-bold hover:bg-primary-container"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Confirm Delete Advisor */}
      {deletingAdvisor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-md">
          <div className="bg-surface-container-lowest rounded-2xl border border-quiet shadow-2xl max-w-md w-full p-lg space-y-md text-center">
            <div className="w-16 h-16 rounded-full bg-error-container/20 text-error mx-auto flex items-center justify-center">
              <span className="material-symbols-outlined text-[32px]">warning</span>
            </div>
            <h3 className="text-headline-md font-bold text-on-background">
              ¿Eliminar a {deletingAdvisor.name}?
            </h3>
            <p className="text-body-md text-on-surface-variant">
              Esta acción revocará la suscripción del asesor y sus permisos para enviar nuevas solicitudes de diseño. Esta acción no se puede deshacer.
            </p>
            <div className="flex justify-center gap-sm pt-sm">
              <button
                onClick={() => setDeletingAdvisor(null)}
                className="px-lg py-sm rounded-lg border border-quiet font-semibold text-on-surface hover:bg-surface-container cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-lg py-sm rounded-lg bg-error text-on-error font-bold hover:bg-error/90 cursor-pointer shadow-sm"
              >
                Sí, Eliminar Asesor
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};
