import React from 'react';
import { LogoStyle, LogoPosition } from '../types';

interface CafiLogoProps {
  variant?: 'full' | 'symbol' | 'isotipo' | 'white';
  logoStyle?: LogoStyle;
  logoPosition?: LogoPosition;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  customLogoUrl?: string | null;
  customTitle?: string;
  customSubTitle?: string;
}

export const CafiLogo: React.FC<CafiLogoProps> = ({
  variant = 'full',
  logoStyle = 'default',
  logoPosition = 'left',
  className = '',
  size = 'md',
  customLogoUrl,
  customTitle,
  customSubTitle
}) => {
  const symbolSize = size === 'sm' ? 32 : size === 'lg' ? 54 : 40;
  const isSymbolOnly = variant === 'symbol' || variant === 'isotipo';
  
  const effectiveStyle = variant === 'white' ? 'monochrome_white' : logoStyle;

  let blueColor = '#000B76';
  let orangeColor = '#FF5000';
  let textColor = '#000000';
  let subtextColor = '#555555';

  if (effectiveStyle === 'monochrome_dark') {
    blueColor = '#1E293B';
    orangeColor = '#475569';
    textColor = '#0F172A';
    subtextColor = '#64748B';
  } else if (effectiveStyle === 'monochrome_white') {
    blueColor = '#FFFFFF';
    orangeColor = '#E2E8F0';
    textColor = '#FFFFFF';
    subtextColor = 'rgba(255,255,255,0.85)';
  }

  const titleText = customTitle || 'cafi';
  const subtitleText = customSubTitle || 'TU CASA FINANCIERA';

  const positionClass = logoPosition === 'center' ? 'justify-center text-center' : 'justify-start';

  if (customLogoUrl && !isSymbolOnly) {
    return (
      <div className={`flex items-center gap-3 ${positionClass} ${className}`}>
        <img
          src={customLogoUrl}
          alt={titleText}
          className="object-contain"
          style={{
            height: size === 'sm' ? '32px' : size === 'lg' ? '54px' : '40px',
            maxWidth: '220px'
          }}
        />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 ${positionClass} ${className}`}>
      {/* Official 6-Petal CAFI Symbol */}
      <svg
        width={symbolSize}
        height={symbolSize}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <g transform="translate(50 50)">
          {/* Petal 1 - Top/12 o'clock (Blue) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(0)"
            fill={blueColor}
          />
          {/* Petal 2 - Top Right/2 o'clock (Orange) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(60)"
            fill={orangeColor}
          />
          {/* Petal 3 - Bottom Right/4 o'clock (Blue) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(120)"
            fill={blueColor}
          />
          {/* Petal 4 - Bottom/6 o'clock (Orange) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(180)"
            fill={orangeColor}
          />
          {/* Petal 5 - Bottom Left/8 o'clock (Blue) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(240)"
            fill={blueColor}
          />
          {/* Petal 6 - Top Left/10 o'clock (Orange) */}
          <rect
            x="-17"
            y="-43"
            width="34"
            height="34"
            rx="9"
            transform="rotate(300)"
            fill={orangeColor}
          />
        </g>
      </svg>

      {!isSymbolOnly && (
        <div className="flex flex-col justify-center leading-none">
          {/* Custom Stylized CAFI Wordmark */}
          <div className="flex items-center">
            {customTitle && customTitle !== 'cafi' ? (
              <span
                className="font-black tracking-tighter"
                style={{
                  color: textColor,
                  fontSize: size === 'sm' ? '1.3rem' : size === 'lg' ? '2.2rem' : '1.75rem',
                  fontFamily: 'system-ui, -apple-system, sans-serif'
                }}
              >
                {customTitle}
              </span>
            ) : (
              <svg
                height={size === 'sm' ? '22' : size === 'lg' ? '36' : '28'}
                viewBox="0 0 225 70"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="shrink-0"
              >
                {/* 'c' */}
                <path
                  d="M 22 0 C 8 0 0 10 0 24 L 0 46 C 0 60 8 70 22 70 L 55 70 L 55 48 L 30 48 C 24 48 22 44 22 38 L 22 32 C 22 26 24 22 30 22 L 55 22 L 55 0 Z"
                  fill={textColor}
                />
                {/* 'a' */}
                <path
                  d="M 82 0 C 68 0 62 10 62 24 L 62 46 C 62 60 70 70 85 70 L 122 70 L 122 0 Z M 84 22 L 100 22 C 104 22 106 24 106 28 L 106 42 C 106 46 104 48 100 48 L 84 48 C 80 48 78 46 78 42 L 78 28 C 78 24 80 22 84 22 Z"
                  fill={textColor}
                />
                {/* 'f' */}
                <path
                  d="M 132 24 C 132 10 142 0 160 0 L 182 0 L 182 22 L 162 22 C 158 22 156 24 156 28 L 156 70 L 132 70 Z"
                  fill={textColor}
                />
                {/* 'i' stem */}
                <path
                  d="M 194 26 L 218 26 L 218 70 L 194 70 Z"
                  fill={textColor}
                />
                {/* 'i' dot */}
                <circle
                  cx="210"
                  cy="9"
                  r="9"
                  fill={textColor}
                />
              </svg>
            )}
          </div>

          <span
            className="font-bold uppercase tracking-widest"
            style={{
              color: subtextColor,
              fontSize: size === 'sm' ? '0.55rem' : size === 'lg' ? '0.78rem' : '0.65rem',
              letterSpacing: '0.18em',
              fontFamily: 'system-ui, -apple-system, sans-serif',
              marginTop: '3px'
            }}
          >
            {subtitleText}
          </span>
        </div>
      )}
    </div>
  );
};

