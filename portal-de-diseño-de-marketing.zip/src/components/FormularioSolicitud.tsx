import React, { useState } from 'react';
import { RequestItem, ScreenType, TransitionType, UserProfile } from '../types';
import { STATE_REGION_MAP } from './MexicoMap';

interface FormularioSolicitudProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onSubmitRequest: (newReq: RequestItem) => void;
  currentUser?: UserProfile | null;
}

export const FormularioSolicitud: React.FC<FormularioSolicitudProps> = ({
  onNavigate,
  onSubmitRequest,
  currentUser
}) => {
  const [title, setTitle] = useState('');
  const [materialType, setMaterialType] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [files, setFiles] = useState<{ name: string; type: string }[]>([]);
  const [selectedState, setSelectedState] = useState('Guanajuato');
  const [fileError, setFileError] = useState<string | null>(null);

  const calculatedRegion = STATE_REGION_MAP[selectedState] || currentUser?.region || 'Bajío';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles = Array.from(e.target.files) as File[];
      const newFiles = selectedFiles.map((f) => ({
        name: f.name,
        type: f.name.endsWith('.pdf') ? 'pdf' : f.name.endsWith('.xlsx') ? 'excel' : 'doc'
      }));
      setFiles((prev) => [...prev, ...newFiles]);
      setFileError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (files.length === 0) {
      setFileError('Es obligatorio adjuntar al menos un archivo o documento para enviar la solicitud.');
      return;
    }

    const priorityLabel: RequestItem['priority'] =
      priority === 'high' ? 'Alta Prioridad' : priority === 'medium' ? 'Media Prioridad' : 'Baja Prioridad';

    const newReq: RequestItem = {
      id: `CAFI-2026-00${Math.floor(Math.random() * 900 + 100)}`,
      title: title.trim() || 'Nueva Solicitud de Campaña',
      date: 'Hoy',
      status: 'En Proceso',
      advisor: currentUser?.name || 'Asesor Registrado',
      designer: 'Área de Marketing',
      priority: priorityLabel,
      deadline: deadline || 'Oct 30, 2026',
      materialType: materialType,
      region: calculatedRegion,
      state: selectedState,
      description: description.trim() || 'Sin descripción adicional.',
      attachments: files.length > 0 ? files : [{ name: 'Brief_Inicial_CAFI.pdf', type: 'pdf' }],
      comments: [
        {
          id: 'c1',
          author: 'Área de Marketing',
          avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmlSLmSHTm3W2RNG3ycDcHCCcGFz4zb0fFCgCuFRC5lfOjGwJ3NHdGboTv0IDFDVLmt5TodI3GECJUR8OuUGoOFTiQFyPY8OpHS7HL6dzgckBXxBTwAkTtmrb3upzFXM5b6h4SsajWZi0uFk_GLm0UL9RxUQSnyevOzLEE8KX27pJdJFhXLawAkMUgCDcEN2qTLfinZ5m_fP-kvIjmhwt48zf96FPyl5R_A0k2P1jmUsLnaKQg_t8',
          time: 'Hace un momento',
          text: 'Solicitud recibida. Revisando los requerimientos de diseño.'
        }
      ],
      history: [
        {
          id: 'h1',
          title: 'Solicitud Enviada',
          date: 'Hoy • Reciente',
          status: 'completed',
          detail: `Enviado por ${currentUser?.name || 'Asesor'} vía Portal.`
        },
        {
          id: 'h2',
          title: 'Recibida y Triada',
          date: 'Hoy • Reciente',
          status: 'completed',
          detail: 'Prioridad asignada.'
        },
        {
          id: 'h3',
          title: 'En Proceso',
          date: 'Hoy • Reciente',
          status: 'active',
          detail: 'Asignado a Área de Marketing. Fase de diseño iniciada.'
        },
        {
          id: 'h4',
          title: 'En Revisión',
          date: 'Pendiente',
          status: 'future',
          detail: 'Esperando primera entrega.'
        },
        {
          id: 'h5',
          title: 'Completado',
          date: 'Pendiente',
          status: 'future',
          detail: 'Aprobación final.'
        }
      ]
    };

    onSubmitRequest(newReq);
    onNavigate('detalle', 'push');
  };

  return (
    <main className="flex-1 flex flex-col h-full min-w-0 bg-surface-subtle overflow-y-auto">
      <div className="p-md md:p-xl">
        <div className="max-w-4xl mx-auto w-full pb-xl">
          {/* Page Header */}
          <div className="mb-lg">
            <h2 className="text-headline-lg font-headline-lg text-on-background mb-xs font-bold">
              Enviar Nueva Solicitud de Diseño
            </h2>
            <p className="text-body-lg font-body-lg text-on-surface-variant">
              Proporcione los detalles necesarios para que nuestro equipo de diseño comience su solicitud. Los campos marcados con asterisco (*) son obligatorios.
            </p>
          </div>

          {/* Form Container */}
          <form onSubmit={handleSubmit} className="space-y-lg">
            {/* Card 1: User Info (Pre-filled dynamically) */}
            <div className="bg-surface-container-lowest border border-quiet rounded-xl shadow-sm p-lg relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-primary-fixed-dim"></div>
              <h3 className="text-title-md font-title-md text-on-background flex items-center gap-xs mb-md font-bold">
                <span className="material-symbols-outlined text-outline">person</span>
                Información del Solicitante
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-md">
                <div>
                  <label className="text-label-md font-label-md text-on-surface-variant block mb-xs">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentUser?.name || 'Asesor Registrado'}
                    className="w-full bg-surface-subtle border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface font-bold cursor-not-allowed opacity-90"
                  />
                </div>
                <div>
                  <label className="text-label-md font-label-md text-on-surface-variant block mb-xs">
                    Correo Corporativo
                  </label>
                  <input
                    type="email"
                    disabled
                    value={currentUser?.email || 'asesor@tucafi.com'}
                    className="w-full bg-surface-subtle border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface cursor-not-allowed opacity-90"
                  />
                </div>
                <div>
                  <label className="text-label-md font-label-md text-on-surface-variant block mb-xs">
                    Número de Teléfono
                  </label>
                  <input
                    type="tel"
                    disabled
                    value={currentUser?.phone || '+52 (55) 1234-5678'}
                    className="w-full bg-surface-subtle border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface cursor-not-allowed opacity-90"
                  />
                </div>
              </div>
              <p className="text-label-md font-label-md text-outline mt-sm flex items-center gap-xs">
                <span className="material-symbols-outlined text-[16px]">info</span>
                Campos completados automáticamente con los datos del asesor registrado. Para actualizar, visite la sección Mi Perfil en Configuración.
              </p>
            </div>

            {/* Card 2: Request Details */}
            <div className="bg-surface-container-lowest border border-quiet rounded-xl shadow-sm p-lg relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-status-in-process"></div>
              <h3 className="text-title-md font-title-md text-on-background flex items-center gap-xs mb-md font-bold">
                <span className="material-symbols-outlined text-status-in-process">design_services</span>
                Detalles de la solicitud
              </h3>
              <div className="space-y-md">
                <div>
                  <label htmlFor="project-title" className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                    Título / Nombre de la Solicitud *
                  </label>
                  <input
                    id="project-title"
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="ej., Actualización del Pitch Deck de Inversores del Q3"
                    className="w-full bg-surface-container-lowest border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-md">
                  <div>
                    <label className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                      Región Geográfica (Asignación Automática)
                    </label>
                    <div className="bg-surface-subtle border border-quiet rounded-lg px-md py-sm flex items-center justify-between min-h-[42px]">
                      <span className="text-body-md font-bold text-primary">
                        {calculatedRegion}
                      </span>
                    </div>
                    <p className="text-[11px] text-on-surface-variant mt-1 font-medium">
                      Determinado por el perfil del solicitante y la plaza seleccionada.
                    </p>
                  </div>

                  <div>
                    <label htmlFor="request-state" className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                      Estado / Plaza de la República *
                    </label>
                    <div className="relative">
                      <select
                        id="request-state"
                        required
                        value={selectedState}
                        onChange={(e) => setSelectedState(e.target.value)}
                        className="w-full bg-surface-container-lowest border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors appearance-none cursor-pointer font-bold"
                      >
                        <optgroup label="Región Chiapas">
                          <option value="Chiapas">Chiapas</option>
                        </optgroup>
                        <optgroup label="Centro">
                          <option value="Puebla">Puebla</option>
                          <option value="Hidalgo">Hidalgo</option>
                          <option value="Cuernavaca">Cuernavaca</option>
                          <option value="Toluca">Toluca</option>
                        </optgroup>
                        <optgroup label="Golfo">
                          <option value="Veracruz">Veracruz</option>
                          <option value="Tampico">Tampico</option>
                          <option value="Oaxaca">Oaxaca</option>
                        </optgroup>
                        <optgroup label="Península">
                          <option value="Yucatán">Yucatán</option>
                          <option value="Cancún">Cancún</option>
                          <option value="Tabasco">Tabasco</option>
                          <option value="Campeche">Campeche</option>
                        </optgroup>
                        <optgroup label="Bajío">
                          <option value="Querétaro">Querétaro</option>
                          <option value="Aguascalientes">Aguascalientes</option>
                          <option value="San Luis Potosí">San Luis Potosí</option>
                          <option value="Guanajuato">Guanajuato</option>
                          <option value="Zacatecas">Zacatecas</option>
                          <option value="Guadalajara">Guadalajara</option>
                          <option value="Morelia">Morelia</option>
                        </optgroup>
                        <optgroup label="Norte">
                          <option value="Monterrey">Monterrey</option>
                          <option value="Saltillo">Saltillo</option>
                          <option value="Durango">Durango</option>
                          <option value="Torreón">Torreón</option>
                        </optgroup>
                        <optgroup label="Noroeste">
                          <option value="Baja California Sur">Baja California Sur</option>
                          <option value="Baja California Norte">Baja California Norte</option>
                          <option value="Sonora">Sonora</option>
                          <option value="Chihuahua">Chihuahua</option>
                        </optgroup>
                      </select>
                      <span className="material-symbols-outlined absolute right-sm top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                        expand_more
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-md">
                  <div>
                    <label htmlFor="material-type" className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                      Tipo de Material *
                    </label>
                    <div className="relative">
                      <select
                        id="material-type"
                        required
                        value={materialType}
                        onChange={(e) => setMaterialType(e.target.value)}
                        className="w-full bg-surface-container-lowest border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors appearance-none cursor-pointer"
                      >
                        <option value="" disabled>
                          Seleccione un tipo de material...
                        </option>
                        <option value="graphic">Diseño Gráfico (Redes, Banners)</option>
                        <option value="presentation">Presentación (PPT, Keynote)</option>
                        <option value="advertising">Material Publicitario (Impresión, Anuncios Digitales)</option>
                        <option value="other">Otro / Personalizado</option>
                      </select>
                      <span className="material-symbols-outlined absolute right-sm top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                        expand_more
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                      Nivel de Prioridad *
                    </label>
                    <div className="flex gap-sm h-[44px] items-center">
                      <label className="flex-1 cursor-pointer">
                        <input
                          type="radio"
                          name="priority"
                          value="low"
                          checked={priority === 'low'}
                          onChange={() => setPriority('low')}
                          className="peer sr-only"
                        />
                        <div className="w-full h-full flex items-center justify-center rounded-lg border border-quiet bg-surface-container-lowest text-body-md font-body-md text-on-surface-variant peer-checked:bg-surface-container-highest peer-checked:border-outline peer-checked:text-on-background peer-checked:font-medium transition-all">
                          Baja
                        </div>
                      </label>

                      <label className="flex-1 cursor-pointer">
                        <input
                          type="radio"
                          name="priority"
                          value="medium"
                          checked={priority === 'medium'}
                          onChange={() => setPriority('medium')}
                          className="peer sr-only"
                        />
                        <div className="w-full h-full flex items-center justify-center rounded-lg border border-quiet bg-surface-container-lowest text-body-md font-body-md text-on-surface-variant peer-checked:bg-status-pending peer-checked:border-status-pending peer-checked:text-white peer-checked:font-medium transition-all">
                          Media
                        </div>
                      </label>

                      <label className="flex-1 cursor-pointer">
                        <input
                          type="radio"
                          name="priority"
                          value="high"
                          checked={priority === 'high'}
                          onChange={() => setPriority('high')}
                          className="peer sr-only"
                        />
                        <div className="w-full h-full flex items-center justify-center rounded-lg border border-quiet bg-surface-container-lowest text-body-md font-body-md text-on-surface-variant peer-checked:bg-status-rejected peer-checked:border-status-rejected peer-checked:text-white peer-checked:font-medium transition-all">
                          Alta
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Card 3: Requirements & Timeline */}
            <div className="bg-surface-container-lowest border border-quiet rounded-xl shadow-sm p-lg relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-surface-variant"></div>
              <h3 className="text-title-md font-title-md text-on-background flex items-center gap-xs mb-md font-bold">
                <span className="material-symbols-outlined text-outline">subject</span>
                Comentarios adicionales
              </h3>
              <div className="space-y-md">
                <div>
                  <label htmlFor="description" className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                    Descripción Detallada *
                  </label>
                  <textarea
                    id="description"
                    required
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Por favor, describa el propósito, público objetivo, mensaje clave y cualquier preferencia específica de diseño..."
                    className="w-full bg-surface-container-lowest border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors resize-y"
                  />
                </div>

                <div className="w-full md:w-1/2">
                  <label htmlFor="deadline" className="text-label-md font-label-md text-on-surface-variant block mb-xs font-semibold">
                    Fecha Límite Deseada *
                  </label>
                  <div className="relative">
                    <input
                      id="deadline"
                      type="date"
                      required
                      value={deadline}
                      onChange={(e) => setDeadline(e.target.value)}
                      className="w-full bg-surface-container-lowest border border-quiet rounded-lg px-md py-sm text-body-md font-body-md text-on-surface focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors appearance-none cursor-pointer"
                    />
                    <span className="material-symbols-outlined absolute right-sm top-1/2 -translate-y-1/2 text-outline pointer-events-none">
                      calendar_today
                    </span>
                  </div>
                  <p className="text-label-md font-label-md text-outline mt-xs">
                    El SLA estándar es de 1 a 3 días hábiles.
                  </p>
                </div>
              </div>
            </div>

            {/* Card 4: Attachments */}
            <div className={`bg-surface-container-lowest border rounded-xl shadow-sm p-lg relative overflow-hidden transition-colors ${fileError ? 'border-rose-400 ring-2 ring-rose-200' : 'border-quiet'}`}>
              <div className="absolute top-0 left-0 w-full h-1 bg-surface-variant"></div>
              <div className="flex justify-between items-start mb-md">
                <h3 className="text-title-md font-title-md text-on-background flex items-center gap-xs font-bold">
                  <span className="material-symbols-outlined text-outline">attachment</span>
                  Adjuntos
                </h3>
                <span className="text-label-md font-label-md text-rose-800 bg-rose-100 font-bold px-2 py-1 rounded">
                  Obligatorio *
                </span>
              </div>
              <p className="text-body-md font-body-md text-on-surface-variant mb-md">
                Sube logotipos, pautas de marca, documentos de texto o ejemplos visuales.
              </p>

              {fileError && (
                <div className="mb-md p-md bg-rose-50 border border-rose-300 rounded-xl text-rose-800 font-bold text-xs flex items-center gap-2 animate-fadeIn">
                  <span className="material-symbols-outlined text-rose-600 text-[20px]">error</span>
                  <span>{fileError}</span>
                </div>
              )}

              <label className={`border-2 border-dashed ${fileError ? 'border-rose-400 bg-rose-50/20' : 'border-outline-variant hover:border-primary bg-surface-subtle hover:bg-surface-container-low'} transition-colors rounded-xl p-xl flex flex-col items-center justify-center text-center cursor-pointer group block`}>
                <div className="w-12 h-12 rounded-full bg-surface-container-highest flex items-center justify-center mb-sm group-hover:bg-primary-fixed-dim transition-colors mx-auto">
                  <span className="material-symbols-outlined text-primary text-[28px]">
                    cloud_upload
                  </span>
                </div>
                <h4 className="text-title-md font-title-md text-on-background mb-xs font-semibold">
                  Haz clic para subir o arrastra y suelta
                </h4>
                <p className="text-body-md font-body-md text-on-surface-variant">
                  SVG, PNG, JPG, PDF o DOCX (máx. 20MB)
                </p>
                <input
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>

              {files.length > 0 && (
                <div className="mt-md flex flex-wrap gap-sm">
                  {files.map((file, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-xs px-md py-xs bg-surface-container rounded-lg text-body-md font-medium text-primary"
                    >
                      <span className="material-symbols-outlined text-sm">description</span>
                      {file.name}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Automatic Email Notice Banner */}
            <div className="bg-primary-fixed-dim/15 border border-primary/20 rounded-xl p-md flex items-start gap-3 text-xs text-primary font-medium">
              <span className="material-symbols-outlined text-[20px] text-secondary flex-shrink-0 mt-0.5">mark_email_read</span>
              <div>
                <p className="font-bold text-on-surface">Notificación por Correo Electrónico Automática</p>
                <p className="text-on-surface-variant text-[11px] mt-0.5 leading-normal">
                  Al enviar la solicitud, se generará una notificación en la campanita del portal y se enviará un correo electrónico despachado con el asunto <strong className="text-secondary">"Nueva Solicitud"</strong> a <strong className="text-primary font-bold">mkt@tucafi.com</strong> y a tu correo corporativo (<strong className="text-primary font-bold">{currentUser?.email || 'asesor@tucafi.com'}</strong>).
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col-reverse sm:flex-row justify-end gap-sm pt-md border-t border-quiet">
              <button
                type="button"
                onClick={() => onNavigate('asesor', 'push_back')}
                className="px-lg py-sm min-h-[44px] rounded-lg font-title-md text-title-md text-primary hover:bg-surface-container transition-colors focus:ring-2 focus:ring-primary focus:ring-offset-2 outline-none cursor-pointer font-semibold"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-lg py-sm min-h-[44px] rounded-lg font-title-md text-title-md bg-primary text-on-primary hover:bg-primary-container transition-colors shadow-sm focus:ring-2 focus:ring-primary focus:ring-offset-2 outline-none flex justify-center items-center gap-xs cursor-pointer font-bold"
              >
                <span className="material-symbols-outlined text-[20px]">send</span>
                Enviar Solicitud
              </button>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
};
