import React, { useState, useRef, useEffect } from 'react';
import { ScreenType, TransitionType, PortalSettings, UserRole, UserProfile, NotificationItem } from '../types';
import { CafiLogo } from './CafiLogo';

interface TopNavBarProps {
  currentScreen: ScreenType;
  onOpenMobileMenu?: () => void;
  onNavigate?: (screen: ScreenType, transition?: TransitionType) => void;
  currentUserRole?: UserRole;
  settings?: PortalSettings;
  currentUser?: UserProfile | null;
  onLogout?: () => void;
  notifications?: NotificationItem[];
  onMarkAllNotificationsRead?: () => void;
  onMarkNotificationRead?: (id: string) => void;
  onSelectNotification?: (notification: NotificationItem) => void;
  onClearNotifications?: () => void;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  currentScreen,
  onOpenMobileMenu,
  onNavigate,
  currentUserRole = 'admin',
  settings,
  currentUser,
  onLogout,
  notifications = [],
  onMarkAllNotificationsRead,
  onMarkNotificationRead,
  onSelectNotification,
  onClearNotifications
}) => {
  const isAdmin = currentUserRole === 'admin';
  const [isOpen, setIsOpen] = useState(false);
  const [selectedEmailNotification, setSelectedEmailNotification] = useState<NotificationItem | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNotificationClick = (item: NotificationItem) => {
    if (onMarkNotificationRead) {
      onMarkNotificationRead(item.id);
    }
    if (onSelectNotification) {
      onSelectNotification(item);
    }
    setIsOpen(false);
  };

  return (
    <header className="flex justify-between items-center w-full px-lg py-sm sticky top-0 z-40 bg-surface-bright border-b border-quiet shadow-xs">
      <div className="flex items-center gap-md">
        <button
          onClick={onOpenMobileMenu}
          className="md:hidden text-on-surface-variant p-xs rounded-full hover:bg-surface-container cursor-pointer"
        >
          <span className="material-symbols-outlined">menu</span>
        </button>

        <div className="md:hidden">
          <CafiLogo
            variant={settings?.logoVariant || 'full'}
            logoStyle={settings?.logoStyle || 'default'}
            logoPosition={settings?.logoPosition || 'left'}
            size="sm"
            customLogoUrl={settings?.logoUrl}
          />
        </div>

        <div className="hidden md:flex items-center gap-sm">
          <h2 className="text-title-lg font-bold text-primary truncate">
            Portal de Solicitudes y Diseño
          </h2>
          <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${
            isAdmin ? 'bg-primary/10 text-primary border-primary/20' : 'bg-secondary/10 text-secondary border-secondary/20'
          }`}>
            {isAdmin ? 'Modo Administrador' : 'Modo Asesor'}
          </span>
        </div>
      </div>

      {(currentScreen === 'detalle' || currentScreen === 'formulario') && (
        <div className="hidden md:flex relative text-on-surface-variant focus-within:text-primary max-w-xs w-full mx-md">
          <span
            className="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 pointer-events-none"
            style={{ fontSize: '20px' }}
          >
            search
          </span>
          <input
            type="text"
            placeholder="Buscar solicitudes..."
            className="bg-surface-container-lowest border border-quiet rounded-full py-xs pl-[36px] pr-sm text-body-md font-body-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-all w-full"
          />
        </div>
      )}

      <div className="flex items-center gap-sm">
        {onNavigate && (
          <button
            onClick={() => onNavigate('configuracion', 'push')}
            title="Configuración del Portal"
            className={`p-2 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
              currentScreen === 'configuracion'
                ? 'bg-primary text-on-primary'
                : 'text-on-surface-variant hover:text-primary hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-[20px]">settings</span>
            <span className="text-xs font-bold hidden sm:inline">Configuración</span>
          </button>
        )}

        {/* Notification Bell Menu Container */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsOpen((prev) => !prev)}
            title="Centro de Notificaciones y Correos Despachados"
            className={`transition-all p-2 rounded-xl flex items-center justify-center cursor-pointer relative ${
              isOpen
                ? 'bg-primary text-on-primary shadow-xs'
                : 'text-on-surface-variant hover:text-primary hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-[22px]">notifications</span>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-secondary text-on-secondary font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-surface-bright shadow-xs animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Popover Dropdown */}
          {isOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-surface dark:bg-inverse-surface border border-quiet rounded-2xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              {/* Dropdown Header */}
              <div className="bg-surface-container/60 p-md border-b border-quiet flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[20px]">mark_email_unread</span>
                  <div>
                    <h3 className="text-body-md font-bold text-on-surface leading-tight">
                      Notificaciones
                    </h3>
                    <p className="text-[11px] text-on-surface-variant font-medium">
                      {unreadCount} sin leer • Notificaciones enviadas al correo
                    </p>
                  </div>
                </div>
                {unreadCount > 0 && onMarkAllNotificationsRead && (
                  <button
                    onClick={onMarkAllNotificationsRead}
                    className="text-[11px] font-bold text-primary hover:underline cursor-pointer bg-primary/10 px-2 py-1 rounded-lg"
                  >
                    Leídas
                  </button>
                )}
              </div>

              {/* Email Notification Dispatch Status Banner */}
              <div className="bg-primary/5 px-md py-2.5 border-b border-quiet/60 flex items-center gap-2 text-xs text-primary font-semibold">
                <span className="material-symbols-outlined text-[16px] text-secondary">mail</span>
                <span>Asunto de correos automáticos: <strong className="text-secondary">"Nueva Solicitud"</strong></span>
              </div>

              {/* Notification List */}
              <div className="max-h-80 overflow-y-auto divide-y divide-quiet/40">
                {notifications.length === 0 ? (
                  <div className="p-xl text-center text-on-surface-variant">
                    <span className="material-symbols-outlined text-[36px] text-outline mb-1">notifications_off</span>
                    <p className="text-body-sm font-semibold">No tienes notificaciones pendientes</p>
                  </div>
                ) : (
                  notifications.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => handleNotificationClick(item)}
                      className={`p-md hover:bg-surface-container/60 transition-colors cursor-pointer flex gap-3 relative group ${
                        !item.read ? 'bg-primary-fixed-dim/10' : ''
                      }`}
                    >
                      {!item.read && (
                        <span className="w-2.5 h-2.5 rounded-full bg-secondary absolute left-2 top-4"></span>
                      )}

                      <div className="pl-2 flex-1">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[10px] font-extrabold uppercase tracking-wider bg-secondary/15 text-secondary px-2 py-0.5 rounded-md">
                            Asunto: {item.subject}
                          </span>
                          <span className="text-[10px] text-outline font-medium">{item.time}</span>
                        </div>

                        <h4 className="text-xs font-bold text-on-surface line-clamp-1 group-hover:text-primary transition-colors">
                          {item.title}
                        </h4>

                        <p className="text-[11px] text-on-surface-variant line-clamp-2 mt-0.5 leading-relaxed">
                          {item.message}
                        </p>

                        {item.emailSentTo && (
                          <div className="mt-2 flex items-center justify-between pt-1 border-t border-quiet/30 text-[10px]">
                            <span className="text-primary font-bold flex items-center gap-1">
                              <span className="material-symbols-outlined text-[12px]">send</span>
                              Correo despachado
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedEmailNotification(item);
                              }}
                              className="text-secondary font-bold hover:underline cursor-pointer flex items-center gap-0.5"
                            >
                              Ver correo
                              <span className="material-symbols-outlined text-[12px]">open_in_new</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Dropdown Footer */}
              <div className="p-sm bg-surface-container/30 border-t border-quiet flex justify-between items-center text-xs">
                {onClearNotifications && notifications.length > 0 && (
                  <button
                    onClick={onClearNotifications}
                    className="text-on-surface-variant hover:text-rose-600 font-semibold text-[11px] px-2 py-1 rounded cursor-pointer"
                  >
                    Limpiar lista
                  </button>
                )}
                {onNavigate && (
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      onNavigate('detalle', 'push');
                    }}
                    className="text-primary font-bold hover:underline ml-auto cursor-pointer flex items-center gap-1 text-[11px]"
                  >
                    Ver todas las solicitudes
                    <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="h-6 w-px bg-quiet mx-xs hidden sm:block"></div>

        <div className="flex items-center gap-sm">
          <div
            onClick={() => onNavigate && onNavigate('configuracion', 'push')}
            className="flex items-center gap-xs cursor-pointer rounded-full p-xs hover:bg-surface-container transition-colors"
            title="Ver perfil y rol de usuario"
          >
            <div className="hidden lg:block text-right mr-xs">
              <p className="text-body-sm font-bold text-primary leading-tight">
                {currentUser?.name || (isAdmin ? 'Administrador CAFI' : 'Asesor de Ventas')}
              </p>
              <p className="text-[10px] text-on-surface-variant font-semibold">
                {currentUser?.email || (isAdmin ? 'mkt@tucafi.com' : 'asesor@tucafi.com')}
              </p>
            </div>
            <div className={`w-8 h-8 rounded-full overflow-hidden border-2 flex items-center justify-center font-bold text-xs ${
              isAdmin ? 'border-primary bg-primary text-on-primary' : 'border-secondary bg-secondary text-on-secondary'
            }`}>
              {currentUser?.avatarUrl ? (
                <img src={currentUser.avatarUrl} alt={currentUser.name} className="w-full h-full object-cover" />
              ) : currentUser?.name ? (
                currentUser.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()
              ) : (isAdmin ? 'AD' : 'AS')}
            </div>
          </div>

          {onLogout && (
            <button
              onClick={onLogout}
              title="Cerrar Sesión"
              className="p-2 text-on-surface-variant hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer flex items-center gap-1 border border-quiet"
            >
              <span className="material-symbols-outlined text-[20px]">logout</span>
              <span className="text-xs font-bold hidden md:inline">Salir</span>
            </button>
          )}
        </div>
      </div>

      {/* Email Notification Preview Modal */}
      {selectedEmailNotification && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-md animate-in fade-in duration-200">
          <div className="bg-surface dark:bg-inverse-surface border border-quiet rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="bg-primary text-on-primary p-md flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[22px]">mark_email_read</span>
                <div>
                  <h3 className="text-title-sm font-bold leading-tight">
                    Vista Previa de Correo Enviado
                  </h3>
                  <p className="text-[11px] opacity-80">Notificación oficial por correo electrónico</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedEmailNotification(null)}
                className="text-on-primary hover:bg-white/20 rounded-full p-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            {/* Email Header Envelope */}
            <div className="p-md bg-surface-container/50 border-b border-quiet space-y-1.5 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-on-surface-variant w-16">De:</span>
                <span className="text-on-surface font-medium">Sistema CAFI &lt;notificaciones@tucafi.com&gt;</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-on-surface-variant w-16">Para:</span>
                <span className="text-on-surface font-semibold">{selectedEmailNotification.emailSentTo || 'mkt@tucafi.com'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-on-surface-variant w-16">Asunto:</span>
                <span className="bg-secondary/20 text-secondary font-black px-2 py-0.5 rounded text-xs">
                  {selectedEmailNotification.subject}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-on-surface-variant w-16">Fecha:</span>
                <span className="text-outline font-medium">{selectedEmailNotification.time}</span>
              </div>
            </div>

            {/* Email Body Content */}
            <div className="p-lg space-y-md text-xs text-on-surface overflow-y-auto max-h-96">
              <div className="border-b border-quiet pb-3 flex items-center justify-between">
                <CafiLogo variant="full" size="sm" />
                <span className="text-[10px] font-bold text-secondary uppercase tracking-widest bg-secondary/10 px-2 py-1 rounded">
                  Notificación Automática
                </span>
              </div>

              <h4 className="text-body-md font-bold text-primary">
                {selectedEmailNotification.title}
              </h4>

              <p className="text-on-surface-variant leading-relaxed font-normal">
                {selectedEmailNotification.message}
              </p>

              <div className="bg-surface-subtle border border-quiet p-md rounded-xl space-y-2 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-outline">ID Solicitud:</span>
                  <span className="font-bold text-primary">{selectedEmailNotification.requestId || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-outline">Estado del Correo:</span>
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">check_circle</span> Entregado
                  </span>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-outline text-center font-medium border-t border-quiet/60">
                Tu Casa Financiera • Portal de Marketing y Solicitudes
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-md bg-surface-container/30 border-t border-quiet flex justify-end gap-2">
              <button
                onClick={() => setSelectedEmailNotification(null)}
                className="px-md py-2 bg-primary text-on-primary rounded-xl font-bold text-xs hover:bg-primary-hover cursor-pointer"
              >
                Cerrar Vista Previa
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
