import React, { useState } from 'react';
import { RequestItem, ScreenType, TransitionType, UserRole, UserProfile } from '../types';

interface AsesorPanelProps {
  requests: RequestItem[];
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onSelectRequest: (request: RequestItem) => void;
  onDeleteRequest?: (requestId: string) => void;
  onClearAllRequests?: () => void;
  onResetData?: () => void;
  currentUserRole?: UserRole;
  currentUser?: UserProfile | null;
  onUpdateStatus?: (requestId: string, newStatus: RequestItem['status'], note?: string) => void;
}

export const AsesorPanel: React.FC<AsesorPanelProps> = ({
  requests,
  onNavigate,
  onSelectRequest,
  onDeleteRequest,
  onClearAllRequests,
  onResetData,
  currentUserRole = 'admin',
  currentUser,
  onUpdateStatus
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('Todos');

  const isAdmin = currentUserRole === 'admin';

  // Filter requests strictly for the active advisor in advisor mode
  const advisorRequests = isAdmin
    ? requests
    : requests.filter((r) => {
        if (!currentUser?.name) return true;
        const normAdvisor = r.advisor.toLowerCase().trim();
        const normUser = currentUser.name.toLowerCase().trim();
        // Match user's name or fallback demo advisor name
        return (
          normAdvisor.includes(normUser) ||
          normUser.includes(normAdvisor) ||
          r.advisor === 'N/A' ||
          r.advisor === 'Alexander Wright'
        );
      });

  // Dynamic calculations specifically for advisor's requests when in advisor mode
  const totalRequests = advisorRequests.length;
  const pendingRequests = advisorRequests.filter((r) => r.status === 'Pendiente').length;
  const inProcessRequests = advisorRequests.filter((r) => r.status === 'En Proceso').length;
  const completedRequests = advisorRequests.filter((r) => r.status === 'Completado').length;

  const filteredRequests = advisorRequests.filter((req) => {
    const matchesSearch =
      req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.advisor.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'Todos' || req.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: RequestItem['status']) => {
    switch (status) {
      case 'Pendiente':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-pending/10 text-status-pending border border-status-pending/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-pending"></span>
            Pendiente
          </span>
        );
      case 'En Proceso':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-in-process/10 text-status-in-process border border-status-in-process/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-in-process"></span>
            En Proceso
          </span>
        );
      case 'Completado':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-completed/10 text-status-completed border border-status-completed/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-completed"></span>
            Completado
          </span>
        );
      case 'Rechazado':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-status-rejected/10 text-status-rejected border border-status-rejected/20">
            <span className="w-1.5 h-1.5 rounded-full bg-status-rejected"></span>
            Rechazado
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <main className="flex-1 overflow-y-auto p-md md:p-lg lg:px-xl bg-surface-subtle">
      <div className="max-w-container-max mx-auto space-y-lg pb-xl">
        {/* Top Header & Actions Bar */}
        <section className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-md bg-surface-container-lowest p-md md:p-lg rounded-2xl border border-quiet shadow-xs">
          <div>
            <h2 className="text-headline-md font-bold text-primary flex items-center gap-2">
              <span className="w-2.5 h-7 rounded-full bg-secondary inline-block"></span>
              {isAdmin ? 'Panel de Control de Marketing' : 'Panel de Control de Mis Pedidos'}
            </h2>
            <p className="text-body-md text-on-surface-variant mt-0.5">
              {isAdmin
                ? 'Administración de briefs, solicitudes y flujo de diseño para CAFI - Tu Casa Financiera.'
                : `Estadísticas y seguimiento exclusivo de tus pedidos (${currentUser?.name || 'Asesor de Ventas'}).`}
            </p>
          </div>

          <div className="flex items-center gap-xs w-full sm:w-auto">
            <button
              onClick={() => onNavigate('formulario', 'slide_up')}
              className="flex-1 sm:flex-initial bg-secondary hover:bg-secondary-hover text-on-secondary font-bold py-2.5 px-lg rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 text-sm cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">add_circle</span>
              Nueva Solicitud
            </button>
            {isAdmin && (
              <button
                onClick={() => onNavigate('equipo', 'push')}
                className="bg-surface-container hover:bg-surface-container-high text-primary font-semibold py-2.5 px-md rounded-xl transition-colors text-sm cursor-pointer border border-quiet flex items-center gap-1"
              >
                <span className="material-symbols-outlined text-[20px]">group</span>
                Equipo
              </button>
            )}
          </div>
        </section>

        {/* Dynamic Quick Stats */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-md">
          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between">
            <div>
              <p className="text-label-md font-label-md text-on-surface-variant uppercase tracking-wider font-semibold">
                Total Solicitudes
              </p>
              <p className="text-headline-lg font-headline-lg text-on-surface mt-xs font-bold font-tabular-nums">
                {totalRequests}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[26px]">inventory_2</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-status-pending">
            <div>
              <p className="text-label-md font-label-md text-on-surface-variant uppercase tracking-wider font-semibold">
                Pendientes
              </p>
              <p className="text-headline-lg font-headline-lg text-status-pending mt-xs font-bold font-tabular-nums">
                {pendingRequests}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-status-pending/10 flex items-center justify-center text-status-pending">
              <span className="material-symbols-outlined text-[26px]">hourglass_empty</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-status-in-process">
            <div>
              <p className="text-label-md font-label-md text-on-surface-variant uppercase tracking-wider font-semibold">
                En Proceso
              </p>
              <p className="text-headline-lg font-headline-lg text-status-in-process mt-xs font-bold font-tabular-nums">
                {inProcessRequests}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-status-in-process/10 flex items-center justify-center text-status-in-process">
              <span className="material-symbols-outlined text-[26px]">autorenew</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest border border-quiet rounded-xl p-md shadow-sm flex items-center justify-between border-t-4 border-t-status-completed">
            <div>
              <p className="text-label-md font-label-md text-on-surface-variant uppercase tracking-wider font-semibold">
                Completadas
              </p>
              <p className="text-headline-lg font-headline-lg text-status-completed mt-xs font-bold font-tabular-nums">
                {completedRequests}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-status-completed/10 flex items-center justify-center text-status-completed">
              <span className="material-symbols-outlined text-[26px]">check_circle</span>
            </div>
          </div>
        </section>

        {/* Requests Management Panel */}
        <section className="bg-surface-container-lowest rounded-xl border border-quiet shadow-sm overflow-hidden">
          {/* Header Controls */}
          <div className="p-md border-b border-quiet flex flex-col sm:flex-row justify-between items-start sm:items-center gap-md bg-surface-subtle">
            <div>
              <h3 className="text-title-md font-bold text-primary">Listado de Solicitudes</h3>
              <p className="text-label-md text-on-surface-variant">
                Mostrando {filteredRequests.length} de {requests.length} solicitudes registradas
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-xs">
              {onClearAllRequests && requests.length > 0 && (
                <button
                  onClick={onClearAllRequests}
                  title="Vaciar todas las solicitudes"
                  className="px-3 py-1.5 border border-quiet rounded-lg text-xs font-semibold text-error hover:bg-error-container/20 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">cleaning_services</span>
                  Limpiar Lista
                </button>
              )}
              {onResetData && (
                <button
                  onClick={onResetData}
                  title="Restablecer datos de ejemplo"
                  className="px-3 py-1.5 border border-quiet rounded-lg text-xs font-semibold text-primary hover:bg-surface-container transition-colors flex items-center gap-1 cursor-pointer bg-surface-container-lowest"
                >
                  <span className="material-symbols-outlined text-[16px]">refresh</span>
                  Restablecer
                </button>
              )}
            </div>
          </div>

          {/* Search & Filter bar */}
          <div className="p-md border-b border-quiet flex flex-col md:flex-row gap-md justify-between items-center bg-surface-container-lowest">
            <div className="relative w-full md:w-80">
              <span className="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline text-[20px]">
                search
              </span>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por código, título o asesor..."
                className="w-full bg-surface-subtle border border-quiet rounded-lg pl-9 pr-sm py-2 text-body-md text-on-surface focus:outline-none focus:border-primary transition-colors"
              />
            </div>

            <div className="flex flex-wrap gap-xs w-full md:w-auto">
              {['Todos', 'Pendiente', 'En Proceso', 'Completado', 'Rechazado'].map((status) => (
                <button
                  key={status}
                  onClick={() => setSelectedStatus(status)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    selectedStatus === status
                      ? 'bg-primary text-on-primary shadow-xs'
                      : 'bg-surface-subtle border border-quiet text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          {/* Table View */}
          {filteredRequests.length === 0 ? (
            <div className="p-xl text-center space-y-sm">
              <div className="w-12 h-12 rounded-full bg-surface-container mx-auto flex items-center justify-center text-outline">
                <span className="material-symbols-outlined text-[28px]">inbox</span>
              </div>
              <p className="text-body-md font-semibold text-on-background">No hay solicitudes registradas</p>
              <p className="text-label-md text-on-surface-variant">
                {requests.length === 0
                  ? 'La lista de solicitudes está limpia. Envía una nueva solicitud o restablece los datos.'
                  : 'Ninguna solicitud coincide con tu filtro actual.'}
              </p>
              <div className="flex justify-center gap-sm pt-xs">
                <button
                  onClick={() => onNavigate('formulario', 'slide_up')}
                  className="px-md py-xs bg-primary text-on-primary font-bold text-xs rounded-lg hover:bg-primary-container cursor-pointer"
                >
                  + Nueva Solicitud
                </button>
                {onResetData && (
                  <button
                    onClick={onResetData}
                    className="px-md py-xs border border-quiet text-primary font-semibold text-xs rounded-lg hover:bg-surface-container cursor-pointer"
                  >
                    Restablecer Datos
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-surface-subtle border-b border-quiet">
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium">
                      Código ID
                    </th>
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium">
                      Título / Nombre de la Solicitud
                    </th>
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium">
                      Asesor / Solicitante
                    </th>
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium">
                      Fecha Límite
                    </th>
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium">
                      Estado
                    </th>
                    <th className="py-sm px-md text-label-md font-label-md text-on-surface-variant font-medium text-right">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="text-body-md font-body-md divide-y divide-quiet">
                  {filteredRequests.map((req) => (
                    <tr
                      key={req.id}
                      className="hover:bg-surface-subtle transition-colors group cursor-pointer"
                      onClick={() => {
                        onSelectRequest(req);
                        onNavigate('detalle', 'push');
                      }}
                    >
                      <td className="py-sm px-md font-tabular-nums text-primary font-bold">
                        {req.id}
                      </td>
                      <td className="py-sm px-md text-on-surface font-semibold max-w-xs truncate">
                        {req.title}
                      </td>
                      <td className="py-sm px-md text-on-surface-variant text-sm">
                        {req.advisor}
                      </td>
                      <td className="py-sm px-md text-on-surface-variant font-tabular-nums text-sm">
                        {req.deadline || req.date}
                      </td>
                      <td className="py-sm px-md" onClick={(e) => e.stopPropagation()}>
                        {currentUserRole === 'admin' && onUpdateStatus ? (
                          <select
                            value={req.status}
                            onChange={(e) =>
                              onUpdateStatus(req.id, e.target.value as RequestItem['status'])
                            }
                            className={`text-xs font-bold rounded-lg px-2 py-1 border cursor-pointer focus:outline-none transition-all ${
                              req.status === 'Pendiente'
                                ? 'bg-amber-50 text-amber-800 border-amber-300'
                                : req.status === 'En Proceso'
                                ? 'bg-blue-50 text-blue-800 border-blue-300'
                                : req.status === 'Completado'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                : 'bg-rose-50 text-rose-800 border-rose-300'
                            }`}
                          >
                            <option value="Pendiente">🟡 Pendiente</option>
                            <option value="En Proceso">🔵 En Proceso</option>
                            <option value="Completado">🟢 Completado</option>
                            <option value="Rechazado">🔴 Rechazado</option>
                          </select>
                        ) : (
                          getStatusBadge(req.status)
                        )}
                      </td>
                      <td className="py-sm px-md text-right">
                        <div className="flex items-center justify-end gap-xs" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => {
                              onSelectRequest(req);
                              onNavigate('detalle', 'push');
                            }}
                            title="Ver Detalle"
                            className="text-primary hover:bg-surface-container p-1.5 rounded-lg transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[18px]">visibility</span>
                          </button>
                          {onDeleteRequest && (
                            <button
                              onClick={() => onDeleteRequest(req.id)}
                              title="Eliminar Solicitud"
                              className="text-on-surface-variant hover:text-error hover:bg-error-container/20 p-1.5 rounded-lg transition-colors cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-[18px]">delete</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
};
