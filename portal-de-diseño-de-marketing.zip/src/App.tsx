/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { INITIAL_REQUESTS, INITIAL_ADVISORS, INITIAL_NOTIFICATIONS } from './data';
import { RequestItem, Advisor, ScreenType, TransitionType, UserRole, PortalSettings, UserProfile, AttachmentItem, NotificationItem } from './types';
import { SideNavBar } from './components/SideNavBar';
import { TopNavBar } from './components/TopNavBar';
import { AsesorPanel } from './components/AsesorPanel';
import { DetalleSolicitud } from './components/DetalleSolicitud';
import { KpiAdminPanel } from './components/KpiAdminPanel';
import { FormularioSolicitud } from './components/FormularioSolicitud';
import { GestionEquipo } from './components/GestionEquipo';
import { ConfiguracionPanel } from './components/ConfiguracionPanel';
import { ChatbotWidget } from './components/ChatbotWidget';
import { CafiLogo } from './components/CafiLogo';
import { AuthScreen } from './components/AuthScreen';
import { ToastContainer, ToastMessage } from './components/ToastContainer';

export default function App() {
  const [requests, setRequests] = useState<RequestItem[]>(INITIAL_REQUESTS);
  const [advisors, setAdvisors] = useState<Advisor[]>(INITIAL_ADVISORS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('admin');

  // Notifications Handlers
  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleMarkNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const handleSelectNotification = (notif: NotificationItem) => {
    handleMarkNotificationRead(notif.id);
    if (notif.requestId) {
      const targetReq = requests.find((r) => r.id === notif.requestId);
      if (targetReq) {
        setSelectedRequest(targetReq);
        handleNavigate('detalle', 'push');
      }
    }
  };

  const handleClearNotifications = () => {
    setNotifications([]);
  };

  // Toasts Notification State
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success', title?: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { id, message, type, title };
    setToasts((prev) => [newToast, ...prev].slice(0, 5));

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const handleLogin = (user: UserProfile) => {
    setCurrentUser(user);
    setCurrentUserRole(user.role);
    setIsAuthenticated(true);
    showToast(`¡Bienvenido al Portal CAFI, ${user.name}!`, 'success', 'Sesión Iniciada');
  };

  const handleUpdateUserProfile = (updatedProfile: Partial<UserProfile>) => {
    setCurrentUser((prev) => (prev ? { ...prev, ...updatedProfile } : null));
    showToast('Tu perfil de usuario ha sido actualizado con éxito.', 'success', 'Perfil Actualizado');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    showToast('Has cerrado sesión correctamente.', 'info', 'Sesión Finalizada');
  };

  const [settings, setSettings] = useState<PortalSettings>({
    logoUrl: null,
    logoVariant: 'full',
    logoPosition: 'left',
    logoStyle: 'default',
    permissions: {
      showKpis: true,
      showEquipo: true,
      showDetalle: true
    }
  });

  const [selectedRequest, setSelectedRequest] = useState<RequestItem>(
    INITIAL_REQUESTS[0] || {
      id: 'CAFI-EMPTY',
      title: 'Sin Solicitud',
      date: 'Hoy',
      status: 'Pendiente',
      advisor: 'N/A',
      designer: 'N/A',
      priority: 'Baja Prioridad',
      description: 'No hay solicitud seleccionada.',
      deadline: 'N/A',
      attachments: [],
      comments: [],
      history: []
    }
  );
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('asesor');
  const [transition, setTransition] = useState<TransitionType>('none');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavigate = (targetScreen: ScreenType, transitionType: TransitionType = 'none') => {
    setTransition(transitionType);
    setCurrentScreen(targetScreen);
    setIsMobileMenuOpen(false);
  };

  // Request handlers
  const handleAddRequest = (newReq: RequestItem) => {
    setRequests((prev) => [newReq, ...prev]);
    setSelectedRequest(newReq);

    const timeNow = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
    const advisorEmail = currentUser?.email || 'asesor@tucafi.com';
    const emailRecipients = `mkt@tucafi.com, ${advisorEmail}`;

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `Nueva Solicitud: ${newReq.title}`,
      subject: 'Nueva Solicitud',
      message: `Solicitud ${newReq.id} registrada por ${newReq.advisor}. Correo electrónico despachado automáticamente con el asunto "Nueva Solicitud" dirigido a mkt@tucafi.com y ${advisorEmail}.`,
      time: `Hoy ${timeNow}`,
      read: false,
      type: 'new_request',
      requestId: newReq.id,
      emailSentTo: emailRecipients
    };

    setNotifications((prev) => [newNotif, ...prev]);

    showToast(
      `📧 Correo despachado con asunto "Nueva Solicitud" a mkt@tucafi.com y ${advisorEmail}`,
      'success',
      'Solicitud y Correo Registrados'
    );
  };

  const handleUpdateStatus = (
    requestId: string,
    newStatus: RequestItem['status'],
    note?: string,
    newAttachments?: AttachmentItem[]
  ) => {
    const dateStr = new Date().toLocaleDateString('es-MX', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    const hasNewAtts = newAttachments && newAttachments.length > 0;
    const attNoteText = hasNewAtts ? ` (Se adjuntaron ${newAttachments.length} archivo(s) final(es))` : '';
    const detailText = (note || `Estatus actualizado a "${newStatus}" por el Administrador.`) + attNoteText;

    setRequests((prev) =>
      prev.map((r) => {
        if (r.id !== requestId) return r;

        const mergedAttachments = hasNewAtts
          ? [...(r.attachments || []), ...newAttachments]
          : r.attachments;

        const newHistoryItem = {
          id: `h-${Date.now()}`,
          title: `Estado cambiado a ${newStatus}`,
          date: dateStr,
          status: newStatus === 'Completado' ? ('completed' as const) : ('active' as const),
          detail: detailText
        };

        return {
          ...r,
          status: newStatus,
          attachments: mergedAttachments,
          history: [newHistoryItem, ...(r.history || [])]
        };
      })
    );

    setSelectedRequest((prev) => {
      if (!prev || prev.id !== requestId) return prev;

      const mergedAttachments = hasNewAtts
        ? [...(prev.attachments || []), ...newAttachments]
        : prev.attachments;

      const newHistoryItem = {
        id: `h-${Date.now()}`,
        title: `Estado cambiado a ${newStatus}`,
        date: dateStr,
        status: newStatus === 'Completado' ? ('completed' as const) : ('active' as const),
        detail: detailText
      };

      return {
        ...prev,
        status: newStatus,
        attachments: mergedAttachments,
        history: [newHistoryItem, ...(prev.history || [])]
      };
    });

    showToast(
      `Estado de la solicitud actualizado a "${newStatus}"${hasNewAtts ? ' con archivos entregables.' : '.'}`,
      'success',
      'Estado Actualizado'
    );
  };

  const handleDeleteRequest = (requestId: string) => {
    setRequests((prev) => prev.filter((r) => r.id !== requestId));
    showToast('La solicitud ha sido eliminada.', 'info', 'Solicitud Eliminada');
  };

  const handleClearAllRequests = () => {
    setRequests([]);
    showToast('Todas las solicitudes han sido removidas.', 'info', 'Listado Limpio');
  };

  const handleResetData = () => {
    setRequests(INITIAL_REQUESTS);
    setAdvisors(INITIAL_ADVISORS);
    if (INITIAL_REQUESTS.length > 0) {
      setSelectedRequest(INITIAL_REQUESTS[0]);
    }
    showToast('Se han restaurado los datos iniciales del sistema.', 'info', 'Datos Restaurados');
  };

  // Advisor handlers
  const handleAddAdvisor = (newAdv: Advisor) => {
    setAdvisors((prev) => [newAdv, ...prev]);
    showToast(`Asesor "${newAdv.name}" agregado al equipo.`, 'success', 'Asesor Agregado');
  };

  const handleEditAdvisor = (updatedAdv: Advisor) => {
    setAdvisors((prev) => prev.map((a) => (a.id === updatedAdv.id ? updatedAdv : a)));
    showToast(`Perfil de "${updatedAdv.name}" actualizado correctamente.`, 'success', 'Perfil Actualizado');
  };

  const handleDeleteAdvisor = (advisorId: string) => {
    setAdvisors((prev) => prev.filter((a) => a.id !== advisorId));
    showToast('El asesor ha sido eliminado del equipo.', 'info', 'Asesor Removido');
  };

  const handleUpdateSettings = (newSettings: PortalSettings) => {
    setSettings(newSettings);
    showToast('La configuración y logotipo del portal han sido guardados.', 'success', 'Cambios Guardados');
  };

  const getTransitionVariants = () => {
    switch (transition) {
      case 'slide_up':
        return {
          initial: { y: '100%', opacity: 0 },
          animate: { y: 0, opacity: 1 },
          exit: { y: '100%', opacity: 0 },
          transition: { duration: 0.35, ease: 'easeOut' }
        };
      case 'push':
        return {
          initial: { x: '100%', opacity: 0 },
          animate: { x: 0, opacity: 1 },
          exit: { x: '-20%', opacity: 0 },
          transition: { duration: 0.3, ease: 'easeInOut' }
        };
      case 'push_back':
        return {
          initial: { x: '-100%', opacity: 0 },
          animate: { x: 0, opacity: 1 },
          exit: { x: '20%', opacity: 0 },
          transition: { duration: 0.3, ease: 'easeInOut' }
        };
      case 'none':
      default:
        return {
          initial: { opacity: 1 },
          animate: { opacity: 1 },
          exit: { opacity: 1 },
          transition: { duration: 0 }
        };
    }
  };

  const transitionProps = getTransitionVariants();

  const isAdmin = currentUserRole === 'admin';
  const showKpis = isAdmin || settings.permissions.showKpis;
  const showEquipo = isAdmin || settings.permissions.showEquipo;
  const showDetalle = isAdmin || settings.permissions.showDetalle;

  if (!isAuthenticated) {
    return <AuthScreen onLogin={handleLogin} settings={settings} />;
  }

  return (
    <div className="bg-background text-on-surface font-sans h-screen flex overflow-hidden">
      {/* Desktop Navigation Sidebar */}
      <SideNavBar
        currentScreen={currentScreen}
        onNavigate={handleNavigate}
        currentUserRole={currentUserRole}
        settings={settings}
        onLogout={handleLogout}
      />

      {/* Mobile Navigation Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setIsMobileMenuOpen(false)}
          ></div>
          <div className="relative flex-1 max-w-xs w-full bg-surface dark:bg-inverse-surface h-full flex flex-col z-10 shadow-xl">
            <div className="p-lg border-b border-quiet flex justify-between items-center">
              <div>
                <CafiLogo
                  variant="full"
                  size="sm"
                  customLogoUrl={settings.logoUrl}
                  customTitle={settings.customTitle}
                  customSubTitle={settings.customSubTitle}
                />
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-on-surface-variant p-1 rounded-full hover:bg-surface-container cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="p-md">
              <button
                onClick={() => handleNavigate('formulario', 'slide_up')}
                className="w-full bg-secondary text-on-secondary font-bold py-sm rounded-lg flex items-center justify-center gap-xs cursor-pointer shadow-xs"
              >
                <span className="material-symbols-outlined">add_circle</span>
                Nueva Solicitud
              </button>
            </div>
            <div className="flex-1 px-md space-y-sm overflow-y-auto">
              <button
                onClick={() => handleNavigate('asesor', 'push_back')}
                className={`w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer ${
                  currentScreen === 'asesor' ? 'text-primary bg-surface-container' : 'text-on-surface-variant'
                }`}
              >
                <span className="material-symbols-outlined">dashboard</span>
                Panel de Control
              </button>

              {showEquipo && (
                <button
                  onClick={() => handleNavigate('equipo', 'push')}
                  className={`w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer ${
                    currentScreen === 'equipo' ? 'text-primary bg-surface-container' : 'text-on-surface-variant'
                  }`}
                >
                  <span className="material-symbols-outlined">group</span>
                  Gestión de Equipo
                </button>
              )}

              {showKpis && (
                <button
                  onClick={() => handleNavigate('kpis', 'push')}
                  className={`w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer ${
                    currentScreen === 'kpis' ? 'text-primary bg-surface-container' : 'text-on-surface-variant'
                  }`}
                >
                  <span className="material-symbols-outlined">analytics</span>
                  Panel de KPIs
                </button>
              )}

              {showDetalle && (
                <button
                  onClick={() => handleNavigate('detalle', 'push')}
                  className={`w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer ${
                    currentScreen === 'detalle' ? 'text-primary bg-surface-container' : 'text-on-surface-variant'
                  }`}
                >
                  <span className="material-symbols-outlined">list_alt</span>
                  Todas las Solicitudes
                </button>
              )}

              <button
                onClick={() => handleNavigate('configuracion', 'push')}
                className={`w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer ${
                  currentScreen === 'configuracion' ? 'text-primary bg-surface-container' : 'text-on-surface-variant'
                }`}
              >
                <span className="material-symbols-outlined">settings</span>
                Configuración
              </button>

              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleLogout();
                }}
                className="w-full text-left px-md py-sm rounded-lg font-bold flex items-center gap-sm cursor-pointer text-rose-600 hover:bg-rose-50 border-t border-quiet mt-md pt-md"
              >
                <span className="material-symbols-outlined">logout</span>
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        <TopNavBar
          currentScreen={currentScreen}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onNavigate={handleNavigate}
          currentUserRole={currentUserRole}
          settings={settings}
          currentUser={currentUser}
          onLogout={handleLogout}
          notifications={notifications}
          onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
          onMarkNotificationRead={handleMarkNotificationRead}
          onSelectNotification={handleSelectNotification}
          onClearNotifications={handleClearNotifications}
        />

        {/* Dynamic Screen View Container with Motion Transitions */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentScreen}
              initial={transitionProps.initial}
              animate={transitionProps.animate}
              exit={transitionProps.exit}
              transition={transitionProps.transition}
              className="w-full h-full flex flex-col overflow-hidden"
            >
              {currentScreen === 'asesor' && (
                <AsesorPanel
                  requests={requests}
                  onNavigate={handleNavigate}
                  onSelectRequest={setSelectedRequest}
                  onDeleteRequest={handleDeleteRequest}
                  onClearAllRequests={handleClearAllRequests}
                  onResetData={handleResetData}
                  currentUserRole={currentUserRole}
                  currentUser={currentUser}
                  onUpdateStatus={handleUpdateStatus}
                />
              )}

              {currentScreen === 'equipo' && (
                <GestionEquipo
                  advisors={advisors}
                  onNavigate={handleNavigate}
                  onAddAdvisor={handleAddAdvisor}
                  onEditAdvisor={handleEditAdvisor}
                  onDeleteAdvisor={handleDeleteAdvisor}
                />
              )}

              {currentScreen === 'detalle' && selectedRequest && (
                <DetalleSolicitud
                  request={selectedRequest}
                  onNavigate={handleNavigate}
                  currentUserRole={currentUserRole}
                  onUpdateStatus={handleUpdateStatus}
                />
              )}

              {currentScreen === 'kpis' && (
                <KpiAdminPanel
                  requests={requests}
                  onNavigate={handleNavigate}
                  onSelectRequest={setSelectedRequest}
                />
              )}

              {currentScreen === 'formulario' && (
                <FormularioSolicitud
                  onNavigate={handleNavigate}
                  onSubmitRequest={handleAddRequest}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'configuracion' && (
                <ConfiguracionPanel
                  onNavigate={handleNavigate}
                  currentUserRole={currentUserRole}
                  currentUser={currentUser}
                  onUpdateUserProfile={handleUpdateUserProfile}
                  onToggleUserRole={
                    currentUserRole === 'admin'
                      ? (role) => {
                          setCurrentUserRole(role);
                          showToast(
                            `Vista cambiada a ${role === 'admin' ? 'Administrador CAFI' : 'Usuario / Asesor'}.`,
                            'info',
                            'Rol Actualizado'
                          );
                        }
                      : undefined
                  }
                  settings={settings}
                  onUpdateSettings={handleUpdateSettings}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />

      {/* Floating Chatbot Assistant in Bottom Right Corner */}
      <ChatbotWidget
        onNavigate={handleNavigate}
        requestsCount={requests.length}
        pendingCount={requests.filter((r) => r.status === 'Pendiente').length}
      />
    </div>
  );
}
