export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  region?: string;
  phone?: string;
  avatarUrl?: string;
}

export type ScreenType = 'asesor' | 'detalle' | 'kpis' | 'formulario' | 'equipo' | 'configuracion';

export type UserRole = 'admin' | 'usuario';

export type LogoVariant = 'full' | 'isotipo';
export type LogoPosition = 'left' | 'center';
export type LogoStyle = 'default' | 'monochrome_dark' | 'monochrome_white';

export interface ModulePermissions {
  showKpis: boolean;
  showEquipo: boolean;
  showDetalle: boolean;
}

export interface PortalSettings {
  logoUrl: string | null;
  logoVariant: LogoVariant;
  logoPosition: LogoPosition;
  logoStyle: LogoStyle;
  customTitle?: string;
  customSubTitle?: string;
  permissions: ModulePermissions;
}

export type TransitionType = 'slide_up' | 'push' | 'push_back' | 'none';

export interface Advisor {
  id: string;
  name: string;
  email: string;
  phone: string;
  region: string;
  role: string;
  status: 'Activo' | 'Inactivo' | 'Pendiente';
  subscriptionDate: string;
  avatar?: string;
  initials: string;
  activeRequestsCount: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  subject: string;
  message: string;
  time: string;
  read: boolean;
  type: 'new_request' | 'status_change' | 'system';
  requestId?: string;
  emailSentTo?: string;
}

export interface AttachmentItem {
  name: string;
  type: string;
  url?: string;
  size?: string;
}

export interface RequestItem {
  id: string;
  title: string;
  date: string;
  status: 'Pendiente' | 'En Proceso' | 'Completado' | 'Rechazado';
  advisor: string;
  designer: string;
  priority: 'Baja Prioridad' | 'Media Prioridad' | 'Alta Prioridad';
  description: string;
  deadline: string;
  materialType?: string;
  region?: string;
  state?: string;
  attachments: AttachmentItem[];
  comments: {
    id: string;
    author: string;
    avatar?: string;
    initials?: string;
    time: string;
    text: string;
  }[];
  history: {
    id: string;
    title: string;
    date: string;
    status: 'completed' | 'active' | 'future';
    detail: string;
  }[];
}
