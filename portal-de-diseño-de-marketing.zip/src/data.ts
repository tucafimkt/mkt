import { RequestItem, Advisor, NotificationItem } from './types';

export const INITIAL_ADVISORS: Advisor[] = [];

export const INITIAL_REQUESTS: RequestItem[] = [];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [];

